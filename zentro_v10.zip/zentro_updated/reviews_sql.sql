-- ══════════════════════════════════════════════════════════════════
--  Zentro – Reviews & Ratings SQL
--  Run this in your Supabase SQL Editor
-- ══════════════════════════════════════════════════════════════════

-- 1. Create the reviews table (skip if already exists)
CREATE TABLE IF NOT EXISTS reviews (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  shop_id      UUID NOT NULL REFERENCES shops(id)    ON DELETE CASCADE,
  customer_id  UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  rating       SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment      TEXT,
  created_at   TIMESTAMPTZ DEFAULT now(),
  updated_at   TIMESTAMPTZ DEFAULT now(),

  -- One review per customer per shop
  UNIQUE (shop_id, customer_id)
);

-- 2. Index for fast shop-level lookups
CREATE INDEX IF NOT EXISTS idx_reviews_shop_id ON reviews (shop_id);
CREATE INDEX IF NOT EXISTS idx_reviews_customer_id ON reviews (customer_id);

-- 3. Auto-update updated_at on edit
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS reviews_updated_at ON reviews;
CREATE TRIGGER reviews_updated_at
  BEFORE UPDATE ON reviews
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ──────────────────────────────────────────────────────────────────
-- 4. Auto-sync shops.rating whenever a review is inserted/updated/deleted
-- ──────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION sync_shop_rating()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  v_shop_id UUID;
BEGIN
  -- Works for INSERT, UPDATE, DELETE
  v_shop_id := COALESCE(NEW.shop_id, OLD.shop_id);

  UPDATE shops
  SET rating = (
    SELECT ROUND(AVG(rating)::numeric, 1)
    FROM reviews
    WHERE shop_id = v_shop_id
  )
  WHERE id = v_shop_id;

  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_shop_rating ON reviews;
CREATE TRIGGER trg_sync_shop_rating
  AFTER INSERT OR UPDATE OR DELETE ON reviews
  FOR EACH ROW EXECUTE FUNCTION sync_shop_rating();

-- ──────────────────────────────────────────────────────────────────
-- 5. Row Level Security
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Anyone can read reviews
DROP POLICY IF EXISTS "reviews_select" ON reviews;
CREATE POLICY "reviews_select"
  ON reviews FOR SELECT USING (true);

-- Only the customer who wrote it can insert their own review
DROP POLICY IF EXISTS "reviews_insert" ON reviews;
CREATE POLICY "reviews_insert"
  ON reviews FOR INSERT
  WITH CHECK (auth.uid() = customer_id);

-- Only the author can update their own review
DROP POLICY IF EXISTS "reviews_update" ON reviews;
CREATE POLICY "reviews_update"
  ON reviews FOR UPDATE
  USING (auth.uid() = customer_id);

-- Only the author can delete their own review
DROP POLICY IF EXISTS "reviews_delete" ON reviews;
CREATE POLICY "reviews_delete"
  ON reviews FOR DELETE
  USING (auth.uid() = customer_id);

-- ──────────────────────────────────────────────────────────────────
-- 6. Add rating column to shops if it doesn't already exist
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE shops ADD COLUMN IF NOT EXISTS rating NUMERIC(3,1);

-- 7. Backfill existing shops with current average (safe to run any time)
UPDATE shops s
SET rating = (
  SELECT ROUND(AVG(r.rating)::numeric, 1)
  FROM reviews r
  WHERE r.shop_id = s.id
);

-- ══════════════════════════════════════════════════════════════════
--  Done! The trigger keeps shops.rating in sync automatically.
-- ══════════════════════════════════════════════════════════════════
