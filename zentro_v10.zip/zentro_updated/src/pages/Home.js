import { useEffect, useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

// ── Plan config defaults (mirrors usePlanPerks) ───────────────────────────────
const PLAN_DEFAULTS = {
  basic:   { name: 'Basic',   price: 999,  photos: 3,  qr: false, badge: false, priority: false },
  pro:     { name: 'Pro',     price: 2499, photos: 10, qr: true,  badge: false, priority: true  },
  premium: { name: 'Premium', price: 4999, photos: 30, qr: true,  badge: true,  priority: true  },
};

async function fetchPlansConfig() {
  const { data } = await supabase
    .from('app_settings')
    .select('value')
    .eq('key', 'plans_config')
    .maybeSingle();
  if (data?.value) {
    try {
      const parsed = JSON.parse(data.value);
      const merged = {};
      for (const t of ['basic', 'pro', 'premium']) {
        merged[t] = { ...PLAN_DEFAULTS[t], ...(parsed[t] || {}) };
      }
      return merged;
    } catch {}
  }
  return PLAN_DEFAULTS;
}

// ── Haversine distance (km) ───────────────────────────────────────────────────
function distanceKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

// ── QR Icon ───────────────────────────────────────────────────────────────────
function QRScanIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 9V5a2 2 0 0 1 2-2h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M15 3h4a2 2 0 0 1 2 2v4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M21 15v4a2 2 0 0 1-2 2h-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M9 21H5a2 2 0 0 1-2-2v-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <line x1="3" y1="12" x2="21" y2="12" stroke="var(--brand)" strokeWidth="1.5" strokeLinecap="round" strokeDasharray="3 2"/>
      <circle cx="12" cy="12" r="1.5" fill="var(--brand)"/>
    </svg>
  );
}

// ── QR Scanner Modal ──────────────────────────────────────────────────────────
function QRScannerModal({ onClose, onResult }) {
  const videoRef = useRef(null);
  const [status, setStatus] = useState('loading');
  const [error, setError]   = useState('');
  const streamRef = useRef(null);
  const animRef   = useRef(null);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []); // eslint-disable-line

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setStatus('scanning');
        requestAnimationFrame(scanLoop);
      }
    } catch (err) {
      setError(err.name === 'NotAllowedError' ? 'Camera permission denied. Allow camera access and try again.' : 'Camera unavailable on this device.');
      setStatus('error');
    }
  };

  const stopCamera = () => {
    if (animRef.current) cancelAnimationFrame(animRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
  };

  const scanLoop = () => {
    const video = videoRef.current;
    if (!video || video.readyState < 2) { animRef.current = requestAnimationFrame(scanLoop); return; }
    const canvas = document.createElement('canvas');
    canvas.width  = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    if ('BarcodeDetector' in window) {
      const detector = new window.BarcodeDetector({ formats: ['qr_code'] });
      detector.detect(canvas).then(codes => {
        if (codes.length > 0) {
          const raw = codes[0].rawValue;
          stopCamera();
          const match = raw.match(/\/shop\/([a-f0-9-]{36})/i);
          if (match) onResult({ type: 'shop', id: match[1] });
          else onResult({ type: 'url', url: raw });
        } else {
          animRef.current = requestAnimationFrame(scanLoop);
        }
      }).catch(() => { animRef.current = requestAnimationFrame(scanLoop); });
    } else {
      setStatus('no-api');
    }
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 2000,
      background: 'rgba(6,14,30,0.92)', backdropFilter: 'blur(4px)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)', width: '100%', maxWidth: 480,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 20px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: '#fff' }}>
          Zen<span style={{ color: 'var(--brand)' }}>tro</span>
        </div>
        <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.2)',
          borderRadius: '50%', width: 36, height: 36, cursor: 'pointer', color: '#fff', fontSize: 18,
          display: 'flex', alignItems: 'center', justifyContent: 'center' }}>×</button>
      </div>

      <div style={{ position: 'relative', width: 260, height: 260 }}>
        {['tl','tr','bl','br'].map(corner => (
          <div key={corner} style={{
            position: 'absolute',
            top:    corner.includes('t') ? 0 : 'auto',
            bottom: corner.includes('b') ? 0 : 'auto',
            left:   corner.includes('l') ? 0 : 'auto',
            right:  corner.includes('r') ? 0 : 'auto',
            width: 28, height: 28,
            borderTop:    corner.includes('t') ? '3px solid var(--brand)' : 'none',
            borderBottom: corner.includes('b') ? '3px solid var(--brand)' : 'none',
            borderLeft:   corner.includes('l') ? '3px solid var(--brand)' : 'none',
            borderRight:  corner.includes('r') ? '3px solid var(--brand)' : 'none',
            borderTopLeftRadius:     corner === 'tl' ? 6 : 0,
            borderTopRightRadius:    corner === 'tr' ? 6 : 0,
            borderBottomLeftRadius:  corner === 'bl' ? 6 : 0,
            borderBottomRightRadius: corner === 'br' ? 6 : 0,
            zIndex: 2,
          }} />
        ))}

        {(status === 'loading' || status === 'scanning') && (
          <video ref={videoRef} playsInline muted
            style={{ width: 260, height: 260, objectFit: 'cover', borderRadius: 16, display: 'block' }} />
        )}

        {status === 'scanning' && (
          <div style={{
            position: 'absolute', left: 8, right: 8, height: 2,
            background: 'linear-gradient(90deg, transparent, var(--brand), transparent)',
            borderRadius: 1, zIndex: 3,
            animation: 'scanline 2s linear infinite',
          }} />
        )}

        {status === 'loading' && (
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: 'rgba(6,14,30,0.5)', borderRadius: 16 }}>
            <div className="spinner" />
          </div>
        )}

        {(status === 'error' || status === 'no-api') && (
          <div style={{ width: 260, height: 260, borderRadius: 16, background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)', display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', gap: 10, padding: 20, textAlign: 'center' }}>
            <span style={{ fontSize: 36 }}>📷</span>
            <p style={{ color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>
              {status === 'no-api' ? 'QR scanning not supported on this browser' : error}
            </p>
            {status === 'no-api' && <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>Try Chrome on Android or use the share link</p>}
          </div>
        )}
      </div>

      <p style={{ color: 'rgba(255,255,255,0.7)', fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, marginTop: 20 }}>
        {status === 'scanning' ? 'Point at a Zentro shop QR code' : ''}
      </p>

      <style>{`@keyframes scanline { 0% { top: 8px; } 50% { top: calc(100% - 10px); } 100% { top: 8px; } }`}</style>
    </div>
  );
}

// ── Main Home Page ────────────────────────────────────────────────────────────
export default function Home() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [shops, setShops]         = useState([]);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');
  const [showQRScan, setShowQR]   = useState(false);
  const [userLoc, setUserLoc]     = useState(null);
  const [locStatus, setLocStatus] = useState('idle');
  const [plansConfig, setPlansConfig] = useState(PLAN_DEFAULTS);

  useEffect(() => {
    fetchShops();
    requestLocation();
    fetchPlansConfig().then(setPlansConfig);
  }, []);

  const fetchShops = async () => {
    const { data } = await supabase
      .from('shops')
      .select('id, name, city, address, images, rating, subscription_tier, lat, lng')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(50);
    setShops(data || []);
    setLoading(false);
  };

  const requestLocation = () => {
    if (!navigator.geolocation) return;
    setLocStatus('requesting');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocStatus('granted');
      },
      () => setLocStatus('denied'),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleQRResult = ({ type, id, url }) => {
    setShowQR(false);
    if (type === 'shop') navigate(`/shop/${id}`);
    else if (url) window.open(url, '_blank');
  };

  // ── Priority sort: only boost tier if that tier has priority enabled ──────
  const tierWeight = (tier) => {
    const cfg = plansConfig[tier];
    if (!cfg || !cfg.priority) return 2; // treat as basic (no boost)
    if (tier === 'premium') return 0;
    if (tier === 'pro') return 1;
    return 2;
  };

  const filtered = shops
    .filter(s =>
      !search ||
      s.name?.toLowerCase().includes(search.toLowerCase()) ||
      s.city?.toLowerCase().includes(search.toLowerCase())
    )
    .map(s => ({
      ...s,
      distance: (userLoc && s.lat && s.lng)
        ? distanceKm(userLoc.lat, userLoc.lng, s.lat, s.lng)
        : null,
    }))
    .sort((a, b) => {
      const tierDiff = tierWeight(a.subscription_tier) - tierWeight(b.subscription_tier);
      if (tierDiff !== 0) return tierDiff;
      if (a.distance !== null && b.distance !== null) return a.distance - b.distance;
      if (a.distance !== null) return -1;
      if (b.distance !== null) return 1;
      return 0;
    });

  const nearbyCount = filtered.filter(s => s.distance !== null && s.distance <= 10).length;

  return (
    <div className="page">
      {showQRScan && <QRScannerModal onClose={() => setShowQR(false)} onResult={handleQRResult} />}

      {/* ── Top Nav ── */}
      <div className="topnav">
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22, letterSpacing: '-0.5px', display: 'flex', alignItems: 'baseline' }}>
          <span style={{ color: 'var(--text-1)' }}>Zen</span>
          <span style={{ color: 'var(--brand)' }}>tro</span>
        </div>
        {!user ? (
          <Link to="/login" className="btn btn-primary btn-sm" style={{ minWidth: 80 }}>Sign In</Link>
        ) : (
          <Link to="/account">
            <div style={{
              width: 36, height: 36, borderRadius: '50%',
              background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font-display)', fontWeight: 800, color: '#fff', fontSize: 15,
              boxShadow: '0 2px 8px var(--brand-glow)',
            }}>
              {profile?.full_name?.[0]?.toUpperCase() || '?'}
            </div>
          </Link>
        )}
      </div>

      <div style={{ padding: '20px 20px 0' }}>

        {/* Location status banner */}
        {locStatus === 'granted' && userLoc && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14,
            padding: '9px 14px', borderRadius: 'var(--radius-sm)',
            background: 'var(--brand-glow)', border: '1px solid var(--border-brand)',
          }}>
            <span style={{ fontSize: 14 }}>📍</span>
            <span style={{ fontSize: 12, color: 'var(--brand)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
              {nearbyCount > 0
                ? `${nearbyCount} shop${nearbyCount !== 1 ? 's' : ''} near you — sorted by distance`
                : 'Location active — showing all shops'}
            </span>
          </div>
        )}

        {locStatus === 'denied' && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14,
            padding: '9px 14px', borderRadius: 'var(--radius-sm)',
            background: 'rgba(255,149,0,0.1)', border: '1px solid rgba(255,149,0,0.25)',
          }}>
            <span style={{ fontSize: 14 }}>🔒</span>
            <div style={{ flex: 1 }}>
              <span style={{ fontSize: 12, color: 'var(--warning)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
                Location off — showing all shops
              </span>
            </div>
            <button onClick={requestLocation}
              style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 11,
                color: 'var(--warning)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
              Allow
            </button>
          </div>
        )}

        <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 18 }}>
          {profile?.role === 'barber' ? (
            <span>Barber account — <Link to="/account" style={{ color: 'var(--brand)', fontWeight: 700 }}>Go to Dashboard ›</Link></span>
          ) : (
            <span>Book your next cut ✂️</span>
          )}
        </p>

        {/* ── Search + QR ── */}
        <div style={{ position: 'relative', marginBottom: 28 }}>
          <svg style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}
            width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            className="input"
            placeholder="Search shops or city..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ paddingLeft: 42, paddingRight: 52, marginBottom: 0 }}
          />
          <button
            onClick={() => setShowQR(true)}
            title="Scan shop QR code"
            style={{
              position: 'absolute', right: 6, top: '50%', transform: 'translateY(-50%)',
              width: 38, height: 38, borderRadius: 10,
              background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
              border: 'none', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', boxShadow: '0 2px 8px var(--brand-glow)',
            }}
            onMouseDown={e => e.currentTarget.style.transform = 'translateY(-50%) scale(0.92)'}
            onMouseUp={e => e.currentTarget.style.transform = 'translateY(-50%) scale(1)'}
          >
            <QRScanIcon />
          </button>
        </div>

        <p className="section-label">
          {search ? `Results for "${search}"` : locStatus === 'granted' ? 'Nearby Shops' : 'All Shops'}
        </p>
        <div className="accent-line" />

        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[1,2,3].map(i => <div key={i} className="skeleton" style={{ height: 220, borderRadius: 'var(--radius)' }} />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">✂️</div>
            <div className="empty-title">No shops found</div>
            <div className="empty-sub">Try a different search or check back later</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {filtered.map((shop, i) => (
              <div key={shop.id} className="fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
                <ShopCard shop={shop} plansConfig={plansConfig} onClick={() => navigate(`/shop/${shop.id}`)} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

const TIER_STYLE = {
  premium: { border: '1.5px solid rgba(255,184,0,0.55)', boxShadow: '0 2px 18px rgba(255,184,0,0.13)', dot: '#FFB800', label: 'Premium' },
  pro:     { border: '1.5px solid rgba(0,128,255,0.30)', boxShadow: '0 2px 14px rgba(0,128,255,0.10)', dot: '#0080FF', label: 'Pro' },
  basic:   { border: null, boxShadow: null, dot: null, label: null },
};

function ShopCard({ shop, plansConfig, onClick }) {
  const img  = shop.images?.[0];
  const tier = TIER_STYLE[shop.subscription_tier] || TIER_STYLE.basic;
  // ── Badge: only show if admin has enabled badge for this tier ──────────────
  const showBadge = tier.label && plansConfig[shop.subscription_tier]?.badge === true;

  return (
    <div
      className="shop-card"
      onClick={onClick}
      style={{
        border:     tier.border     || undefined,
        boxShadow:  tier.boxShadow  || undefined,
      }}
    >
      {img ? (
        <img src={img} alt={shop.name} className="shop-card-img" />
      ) : (
        <div className="shop-card-img" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 48, background: 'var(--bg-input)' }}>✂️</div>
      )}
      <div className="shop-card-body">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
          <div className="shop-card-name">{shop.name}</div>
          {showBadge && (
            <span style={{
              fontSize: 10, fontWeight: 800, fontFamily: 'var(--font-display)',
              padding: '3px 8px', borderRadius: 20,
              background: shop.subscription_tier === 'premium' ? 'rgba(255,184,0,0.12)' : 'var(--brand-glow)',
              color: tier.dot,
              border: `1px solid ${shop.subscription_tier === 'premium' ? 'rgba(255,184,0,0.35)' : 'var(--border-brand)'}`,
              display: 'flex', alignItems: 'center', gap: 4,
            }}>
              <span style={{ width: 5, height: 5, borderRadius: '50%', background: tier.dot, display: 'inline-block' }} />
              {tier.label}
            </span>
          )}
        </div>
        <div className="shop-card-meta">
          <span>📍 {shop.city || shop.address}</span>
          {shop.distance !== null && (
            <span style={{ color: 'var(--brand)', fontWeight: 700 }}>
              {shop.distance < 1 ? `${Math.round(shop.distance * 1000)}m` : `${shop.distance.toFixed(1)}km`} away
            </span>
          )}
          {shop.rating ? <span>⭐ {shop.rating.toFixed(1)}</span> : null}
        </div>
      </div>
    </div>
  );
}
