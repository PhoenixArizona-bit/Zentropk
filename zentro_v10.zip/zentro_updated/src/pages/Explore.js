import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';

// Fix leaflet default icon paths broken by webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// ── Plan config defaults ──────────────────────────────────────────────────────
const PLAN_DEFAULTS = {
  basic:   { name: 'Basic',   price: 999,  photos: 3,  qr: false, badge: false, priority: false },
  pro:     { name: 'Pro',     price: 2499, photos: 10, qr: true,  badge: false, priority: true  },
  premium: { name: 'Premium', price: 4999, photos: 30, qr: true,  badge: true,  priority: true  },
};

async function fetchPlansConfig() {
  const { data } = await supabase
    .from('app_settings')
    .select('value')
    .eq('key', 'plans_config')
    .maybeSingle();
  if (data?.value) {
    try {
      const parsed = JSON.parse(data.value);
      const merged = {};
      for (const t of ['basic', 'pro', 'premium']) {
        merged[t] = { ...PLAN_DEFAULTS[t], ...(parsed[t] || {}) };
      }
      return merged;
    } catch {}
  }
  return PLAN_DEFAULTS;
}

// Custom brand pin for barber shops
function makeBrandPin(active = false) {
  return L.divIcon({
    className: '',
    iconSize:  [36, 44],
    iconAnchor:[18, 44],
    popupAnchor:[0, -44],
    html: `<svg width="36" height="44" viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg">
      <filter id="s" x="-50%" y="-50%" width="200%" height="200%">
        <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="${active ? '#0080FF' : '#0050C8'}" flood-opacity="0.45"/>
      </filter>
      <path d="M18 2C9.16 2 2 9.16 2 18c0 12 16 24 16 24S34 30 34 18C34 9.16 26.84 2 18 2z"
        fill="${active ? '#00B4FF' : '#0080FF'}" filter="url(#s)"/>
      <circle cx="18" cy="18" r="8" fill="white" opacity="0.95"/>
      <text x="18" y="22" text-anchor="middle" font-family="Sora,sans-serif" font-weight="900" font-size="11" fill="${active ? '#00B4FF' : '#0080FF'}">✂</text>
    </svg>`,
  });
}

// Map recenter helper
function MapRecenter({ center, zoom }) {
  const map = useMap();
  useEffect(() => { if (center) map.flyTo(center, zoom || 14, { duration: 1.2 }); }, [center, zoom, map]); // eslint-disable-line
  return null;
}

// User location blue dot
function UserDot({ position }) {
  const icon = L.divIcon({
    className: '',
    iconSize: [20, 20],
    iconAnchor: [10, 10],
    html: `<div style="width:20px;height:20px;border-radius:50%;background:#4A90E2;border:3px solid #fff;box-shadow:0 0 0 5px rgba(74,144,226,0.22),0 2px 8px rgba(0,0,0,0.4)"></div>`,
  });
  return <Marker position={position} icon={icon} interactive={false} />;
}

export default function Explore() {
  const navigate    = useNavigate();
  const [shops, setShops]           = useState([]);
  const [loading, setLoading]       = useState(true);
  const [search, setSearch]         = useState('');
  const [view, setView]             = useState('list');
  const [activeShop, setActive]     = useState(null);
  const [mapCenter, setCenter]      = useState([30.3753, 69.3451]);
  const [mapZoom, setMapZoom]       = useState(6);
  const [userLoc, setUserLoc]       = useState(null);
  const [plansConfig, setPlansConfig] = useState(PLAN_DEFAULTS);
  const listRef = useRef(null);

  useEffect(() => {
    fetchPlansConfig().then(setPlansConfig);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const loc = [pos.coords.latitude, pos.coords.longitude];
          setUserLoc(loc);
          setCenter(loc);
          setMapZoom(13);
        },
        () => {},
        { enableHighAccuracy: true, timeout: 8000 }
      );
    }

    supabase
      .from('shops')
      .select('id, name, city, address, images, subscription_tier, rating, lat, lng')
      .eq('is_active', true)
      .then(async ({ data }) => {
        const shops = data || [];
        const geocodeCache = {};
        const geocode = async (query) => {
          if (geocodeCache[query]) return geocodeCache[query];
          try {
            const res = await fetch(
              `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query + ', Pakistan')}&format=json&limit=1&addressdetails=1`,
              { headers: { 'Accept-Language': 'en' } }
            );
            const json = await res.json();
            if (json?.[0]) {
              const coords = { lat: parseFloat(json[0].lat), lng: parseFloat(json[0].lon) };
              geocodeCache[query] = coords;
              return coords;
            }
          } catch {}
          return null;
        };

        const enriched = await Promise.all(shops.map(async (s) => {
          if (s.lat && s.lng) return s;
          // Use full "address, city" for precision; fall back to city only
          const fullQuery = [s.address, s.city].filter(Boolean).join(', ');
          const cityQuery = s.city || s.address;
          if (!fullQuery) return s;
          const coords = await geocode(fullQuery) || await geocode(cityQuery);
          return coords ? { ...s, lat: coords.lat, lng: coords.lng, _geocoded: true } : s;
        }));

        setShops(enriched);
        setLoading(false);
      });
  }, []);

  // ── Priority sort: only boost tier if admin enabled priority for that tier ──
  const tierWeight = (tier) => {
    const cfg = plansConfig[tier];
    if (!cfg || !cfg.priority) return 2;
    if (tier === 'premium') return 0;
    if (tier === 'pro') return 1;
    return 2;
  };

  const filtered = shops
    .filter(s =>
      !search ||
      s.name?.toLowerCase().includes(search.toLowerCase()) ||
      s.city?.toLowerCase().includes(search.toLowerCase()) ||
      s.address?.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => tierWeight(a.subscription_tier) - tierWeight(b.subscription_tier));

  const mapShops = filtered.filter(s => s.lat && s.lng);

  const focusShop = (shop) => {
    setActive(shop.id);
    if (shop.lat && shop.lng) setCenter([shop.lat, shop.lng]);
    if (view === 'list') {
      setView('map');
    }
  };

  const selectFromMap = (shop) => {
    setActive(shop.id);
    const el = listRef.current?.querySelector(`[data-shopid="${shop.id}"]`);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  };

  return (
    <div className="page" style={{ paddingBottom: 0 }}>
      {/* ── Top bar ── */}
      <div className="topnav">
        <div className="topnav-logo">Zen<span style={{ color: 'var(--brand)' }}>tro</span></div>
        <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Explore</span>
      </div>

      {/* ── Search + toggle ── */}
      <div style={{ padding: '14px 16px 0', background: 'var(--bg-nav)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 60, zIndex: 90 }}>
        <div style={{ position: 'relative', marginBottom: 12 }}>
          <svg style={{ position: 'absolute', left: 13, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}
            width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            className="input"
            placeholder="Search by name or city..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ paddingLeft: 40, marginBottom: 0, paddingRight: search ? 38 : 14 }}
          />
          {search && (
            <button onClick={() => setSearch('')}
              style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
                background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-3)', fontSize: 18, lineHeight: 1 }}>
              ×
            </button>
          )}
        </div>

        {/* View toggle */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
          {[
            { id: 'list', label: 'List', icon: (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/>
                <circle cx="3" cy="6" r="1.5" fill="currentColor"/><circle cx="3" cy="12" r="1.5" fill="currentColor"/><circle cx="3" cy="18" r="1.5" fill="currentColor"/>
              </svg>
            )},
            { id: 'map', label: 'Map', icon: (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/>
                <line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/>
              </svg>
            )},
            { id: 'split', label: 'Split', icon: (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <rect x="3" y="3" width="7" height="18" rx="1"/><rect x="14" y="3" width="7" height="18" rx="1"/>
              </svg>
            )},
          ].map(v => (
            <button key={v.id} onClick={() => setView(v.id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '7px 14px', borderRadius: 100,
                border: `1.5px solid ${view === v.id ? 'var(--brand)' : 'var(--border)'}`,
                background: view === v.id ? 'var(--brand-glow)' : 'var(--bg-input)',
                color: view === v.id ? 'var(--brand)' : 'var(--text-2)',
                fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12,
                cursor: 'pointer', transition: 'all 0.18s',
                flex: 1, justifyContent: 'center',
              }}>
              {v.icon} {v.label}
            </button>
          ))}
        </div>

        <p style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 10, fontFamily: 'var(--font-display)' }}>
          {loading ? 'Loading...' : `${filtered.length} shop${filtered.length !== 1 ? 's' : ''}${search ? ` for "${search}"` : ''}`}
        </p>
      </div>

      {/* ── Content area ── */}
      {loading ? (
        <div style={{ padding: '20px 16px' }}>
          {[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: 76, borderRadius: 'var(--radius)', marginBottom: 10 }} />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🗺️</div>
          <div className="empty-title">No shops found</div>
          <div className="empty-sub">Try a different search term</div>
        </div>
      ) : (
        <>
          {/* LIST ONLY */}
          {view === 'list' && (
            <div style={{ padding: '12px 16px', paddingBottom: 'calc(var(--bottom-h) + 24px)' }}>
              {filtered.map((s, i) => (
                <ShopRow key={s.id} shop={s} plansConfig={plansConfig} active={activeShop === s.id}
                  onClick={() => navigate(`/shop/${s.id}`)}
                  onMapPin={s.lat && s.lng ? () => focusShop(s) : null}
                  animDelay={i * 0.04} />
              ))}
            </div>
          )}

          {/* MAP ONLY */}
          {view === 'map' && (
            <div style={{ height: 'calc(100dvh - 190px)', position: 'relative' }}>
              <ExploreMap
                shops={mapShops} allShops={filtered}
                center={mapCenter} zoom={mapZoom} userLoc={userLoc} activeShop={activeShop}
                onSelect={s => { setActive(s.id); navigate(`/shop/${s.id}`); }}
              />
              {mapShops.length < filtered.length && (
                <div style={{
                  position: 'absolute', bottom: 16, left: '50%', transform: 'translateX(-50%)',
                  background: 'rgba(6,14,30,0.78)', backdropFilter: 'blur(8px)',
                  color: '#fff', fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700,
                  padding: '8px 16px', borderRadius: 100,
                  border: '1px solid rgba(255,255,255,0.15)',
                }}>
                  {filtered.length - mapShops.length} shop{filtered.length - mapShops.length !== 1 ? 's' : ''} have no location — switch to List
                </div>
              )}
            </div>
          )}

          {/* SPLIT */}
          {view === 'split' && (
            <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100dvh - 190px)' }}>
              <div style={{ flex: '0 0 42%', position: 'relative' }}>
                <ExploreMap
                  shops={mapShops} allShops={filtered}
                  center={mapCenter} zoom={mapZoom} userLoc={userLoc} activeShop={activeShop}
                  onSelect={s => selectFromMap(s)}
                />
              </div>

              <div ref={listRef} style={{
                flex: 1, overflowY: 'auto', padding: '10px 16px',
                paddingBottom: 'calc(var(--bottom-h) + 16px)',
                borderTop: '1px solid var(--border)',
                background: 'var(--bg)',
              }}>
                {filtered.map((s, i) => (
                  <ShopRow key={s.id} shop={s} plansConfig={plansConfig} active={activeShop === s.id}
                    onClick={() => navigate(`/shop/${s.id}`)}
                    onMapPin={s.lat && s.lng ? () => { setActive(s.id); setCenter([s.lat, s.lng]); } : null}
                    animDelay={i * 0.03}
                    data-shopid={s.id}
                  />
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

const TIER_STYLE = {
  premium: { border: 'rgba(255,184,0,0.50)', dot: '#FFB800', label: 'Premium' },
  pro:     { border: 'rgba(0,128,255,0.28)', dot: '#0080FF', label: 'Pro' },
  basic:   { border: null, dot: null, label: null },
};

// ── Shop row card ──────────────────────────────────────────────────────────────
function ShopRow({ shop: s, plansConfig, active, onClick, onMapPin, animDelay, ...rest }) {
  const tier = TIER_STYLE[s.subscription_tier] || TIER_STYLE.basic;
  // ── Badge: only show if admin has enabled badge for this tier ──────────────
  const showBadge = tier.label && plansConfig[s.subscription_tier]?.badge === true;

  return (
    <div
      {...rest}
      data-shopid={s.id}
      className="fade-up"
      style={{
        display: 'flex', gap: 12, alignItems: 'center',
        padding: '12px 14px', marginBottom: 8,
        background: active ? 'var(--brand-glow2)' : 'var(--bg-card)',
        border: `1.5px solid ${active ? 'var(--border-brand)' : (tier.border || 'var(--border)')}`,
        borderRadius: 'var(--radius)',
        cursor: 'pointer', transition: 'all 0.18s',
        boxShadow: active ? 'var(--shadow-brand)' : 'var(--shadow-card)',
        animationDelay: `${animDelay}s`,
      }}
      onClick={onClick}
    >
      {/* Thumbnail */}
      <div style={{
        width: 52, height: 52, borderRadius: 12, flexShrink: 0,
        background: 'var(--bg-input)', overflow: 'hidden',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 22, border: '1px solid var(--border)',
      }}>
        {s.images?.[0]
          ? <img src={s.images[0]} alt={s.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          : <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/></svg>}
      </div>

      {/* Info */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, marginBottom: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {s.name}
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-2)', display: 'flex', gap: 8, alignItems: 'center' }}>
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          <span>{s.city || s.address}</span>
          {s.rating && (
            <>
              <span style={{ color: 'var(--border)' }}>·</span>
              <svg width="11" height="11" viewBox="0 0 24 24" fill="var(--brand)" stroke="var(--brand)" strokeWidth="1"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              <span style={{ color: 'var(--brand)', fontWeight: 700 }}>{s.rating.toFixed(1)}</span>
            </>
          )}
        </div>
      </div>

      {/* Right side */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6, flexShrink: 0 }}>
        {showBadge && (
          <span style={{
            fontSize: 10, fontWeight: 800, fontFamily: 'var(--font-display)',
            padding: '2px 7px', borderRadius: 20,
            background: s.subscription_tier === 'premium' ? 'rgba(255,184,0,0.12)' : 'var(--brand-glow)',
            color: tier.dot,
            border: `1px solid ${s.subscription_tier === 'premium' ? 'rgba(255,184,0,0.35)' : 'var(--border-brand)'}`,
            display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <span style={{ width: 5, height: 5, borderRadius: '50%', background: tier.dot, display: 'inline-block' }} />
            {tier.label}
          </span>
        )}
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {onMapPin && (
            <button
              onClick={e => { e.stopPropagation(); onMapPin(); }}
              style={{
                background: 'var(--brand-glow)', border: '1px solid var(--border-brand)',
                borderRadius: 8, padding: '4px 8px', cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 4,
                fontSize: 11, fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--brand)',
              }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/>
              </svg>
              Map
            </button>
          )}
          <span style={{ color: 'var(--text-3)', fontSize: 16 }}>›</span>
        </div>
      </div>
    </div>
  );
}

// ── Leaflet Map component ──────────────────────────────────────────────────────
function ExploreMap({ shops, center, zoom, userLoc, activeShop, onSelect }) {
  return (
    <MapContainer
      center={center}
      zoom={zoom || 6}
      style={{ width: '100%', height: '100%' }}
      zoomControl={false}
      attributionControl={false}
    >
      <TileLayer
        url="https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png"
        attribution='&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>'
      />
      <MapRecenter center={center} zoom={zoom} />
      {userLoc && <UserDot position={userLoc} />}
      {shops.map(s => (
        <Marker
          key={s.id}
          position={[s.lat, s.lng]}
          icon={makeBrandPin(activeShop === s.id)}
          eventHandlers={{ click: () => onSelect(s) }}
        >
          <Popup>
            <div style={{
              fontFamily: 'Sora, sans-serif', minWidth: 160,
              background: '#141A26', borderRadius: 12, padding: '14px 14px 10px',
              color: '#fff', boxShadow: '0 4px 24px rgba(0,0,0,0.5)',
            }}>
              <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 4, color: '#fff' }}>{s.name}</div>
              <div style={{ fontSize: 11, color: '#8A9BBE', marginBottom: 8 }}>{s.city || s.address}</div>
              {s.rating && (
                <div style={{ fontSize: 12, color: '#FFB800', fontWeight: 700, marginBottom: 10 }}>
                  ★ {s.rating.toFixed(1)}
                </div>
              )}
              <button
                onClick={() => onSelect(s)}
                style={{
                  width: '100%', padding: '8px 12px',
                  background: 'linear-gradient(135deg, #0080FF, #00B4FF)',
                  color: '#fff', border: 'none', borderRadius: 8,
                  fontFamily: 'Sora, sans-serif', fontWeight: 700, fontSize: 12, cursor: 'pointer',
                  letterSpacing: '0.02em',
                }}>
                View Shop →
              </button>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
