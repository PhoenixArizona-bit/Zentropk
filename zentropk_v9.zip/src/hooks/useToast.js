import { useState, useCallback } from 'react';

export function useToast() {
  const [toast, setToast] = useState(null);

  const showToast = useCallback((type, text, duration = 3000) => {
    setToast({ type, text });
    setTimeout(() => setToast(null), duration);
  }, []);

  const ToastEl = toast ? (
    <div className={`toast toast-${toast.type}`}>
      {toast.type === 'success' ? '✓' : toast.type === 'error' ? '✕' : 'ℹ'} {toast.text}
    </div>
  ) : null;

  return { showToast, ToastEl };
}
