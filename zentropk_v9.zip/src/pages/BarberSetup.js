import { useEffect, useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { uploadShopImage, deleteImage } from '../lib/imageUpload';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';

// Fix leaflet icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// ── Default plans (fallback if DB has no plans_config yet) ───────────────────
const DEFAULT_PLANS = {
  basic:   { name: 'Basic',   price: 999,  photos: 3,  qr: false, badge: false, priority: false },
  pro:     { name: 'Pro',     price: 2499, photos: 10, qr: true,  badge: false, priority: true  },
  premium: { name: 'Premium', price: 4999, photos: 30, qr: true,  badge: true,  priority: true  },
};

function makeBrandPin() {
  return L.divIcon({
    className: '',
    iconSize:  [36, 44],
    iconAnchor:[18, 44],
    html: `<svg width="36" height="44" viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg">
      <filter id="s"><feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#0080FF" flood-opacity="0.45"/></filter>
      <path d="M18 2C9.16 2 2 9.16 2 18c0 12 16 24 16 24S34 30 34 18C34 9.16 26.84 2 18 2z"
        fill="#0080FF" filter="url(#s)"/>
      <circle cx="18" cy="18" r="8" fill="white" opacity="0.95"/>
      <text x="18" y="22" text-anchor="middle" font-family="Sora,sans-serif" font-weight="900" font-size="11" fill="#0080FF">✂</text>
    </svg>`,
  });
}

function LocationPicker({ position, onPick }) {
  useMapEvents({ click(e) { onPick([e.latlng.lat, e.latlng.lng]); } });
  return position ? <Marker position={position} icon={makeBrandPin()} /> : null;
}

function MapSearch({ onResult }) {
  const map = useRef(null);
  const leafletMap = useMapEvents({});
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);

  const search = async () => {
    if (!query.trim()) return;
    setSearching(true);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query + ', Pakistan')}&format=json&limit=5&addressdetails=1`,
        { headers: { 'Accept-Language': 'en' } }
      );
      const json = await res.json();
      setResults(json || []);
    } catch {}
    setSearching(false);
  };

  const pick = (r) => {
    const lat = parseFloat(r.lat);
    const lng = parseFloat(r.lon);
    leafletMap.flyTo([lat, lng], 17, { duration: 1 });
    onResult(lat, lng);
    setResults([]);
    setQuery(r.display_name.split(',')[0]);
  };

  return (
    <div style={{
      position: 'absolute', top: 12, left: 12, right: 12, zIndex: 1000,
    }}>
      <div style={{ display: 'flex', gap: 8 }}>
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && search()}
          placeholder="Search address or area..."
          style={{
            flex: 1, padding: '10px 14px', borderRadius: 12,
            border: '1.5px solid var(--border-brand)',
            background: 'var(--bg-nav)', color: 'var(--text-1)',
            fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600,
            boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
            outline: 'none',
          }}
        />
        <button
          onClick={search}
          disabled={searching}
          style={{
            background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
            border: 'none', borderRadius: 12, padding: '0 16px',
            color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700,
            fontSize: 13, cursor: 'pointer', whiteSpace: 'nowrap',
            boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
          }}>
          {searching ? '...' : 'Go'}
        </button>
      </div>
      {results.length > 0 && (
        <div style={{
          marginTop: 6, background: 'var(--bg-nav)', borderRadius: 12,
          border: '1px solid var(--border)', overflow: 'hidden',
          boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
        }}>
          {results.map((r, i) => (
            <div key={i}
              onClick={() => pick(r)}
              style={{
                padding: '11px 14px', cursor: 'pointer', fontSize: 13,
                color: 'var(--text-1)', fontFamily: 'var(--font-display)', fontWeight: 600,
                borderBottom: i < results.length - 1 ? '1px solid var(--border)' : 'none',
              }}>
              📍 {r.display_name.split(',').slice(0, 3).join(', ')}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Perk display helper ───────────────────────────────────────────────────────
function PerkBadge({ icon, label, active }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 6,
      padding: '5px 10px', borderRadius: 8,
      background: active ? 'var(--brand-dim)' : 'var(--bg-input)',
      border: `1px solid ${active ? 'var(--brand)' : 'var(--border)'}`,
      opacity: active ? 1 : 0.45,
      fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 600,
      color: active ? 'var(--brand)' : 'var(--text-3)',
    }}>
      <span>{icon}</span>
      <span>{label}</span>
      <span style={{ marginLeft: 2, fontWeight: 800 }}>{active ? '✓' : '✕'}</span>
    </div>
  );
}

export default function BarberSetup() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [shopId, setShopId]         = useState(null);
  const [shopMeta, setShopMeta]     = useState(null);   // full DB row: tier, status, is_active, dates
  const [plans, setPlans]           = useState(DEFAULT_PLANS);
  const [loading, setLoading]       = useState(true);
  const [saving, setSaving]         = useState(false);
  const [uploadingImg, setUploadingImg] = useState(false);
  const [services, setServices]     = useState([]);
  const [newSrv, setNewSrv]         = useState({ name: '', price: '', duration_minutes: 30 });
  const [showMap, setShowMap]       = useState(false);
  const [locating, setLocating]     = useState(false);
  const fileInputRef                = useRef(null);

  const [form, setForm] = useState({
    name: '', city: '', address: '', description: '', phone: '',
    images: [], lat: null, lng: null,
  });

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    loadExisting();
  }, [user, authReady]); // eslint-disable-line

  const loadExisting = async () => {
    // Load shop + live plans_config in parallel
    const [{ data: s }, { data: cfg }] = await Promise.all([
      supabase.from('shops').select('*').eq('owner_id', user.id).maybeSingle(),
      supabase.from('app_settings').select('key, value'),
    ]);

    // Parse live plan config so perks are always up-to-date
    const cfgMap = {};
    (cfg || []).forEach(r => { cfgMap[r.key] = r.value; });
    if (cfgMap.plans_config) {
      try { setPlans(JSON.parse(cfgMap.plans_config)); } catch {}
    }

    if (s) {
      setShopId(s.id);
      setShopMeta(s);   // store full row — tier, status, is_active, dates
      setForm({
        name: s.name || '', city: s.city || '',
        address: s.address || '', description: s.description || '',
        phone: s.phone || '', images: s.images || [],
        lat: s.lat || null, lng: s.lng || null,
      });
      const { data: srv } = await supabase.from('services').select('*').eq('shop_id', s.id);
      setServices(srv || []);
    }
    setLoading(false);
  };

  // ── Derived plan perks from live DB config ─────────────────────────────────
  const tier      = shopMeta?.subscription_tier || 'basic';
  const planPerks = plans[tier] || DEFAULT_PLANS[tier];
  const isApproved = shopMeta?.subscription_status === 'active' && shopMeta?.is_active === true;
  const photoLimit = planPerks?.photos ?? 0;

  const detectLocation = () => {
    if (!navigator.geolocation) return showToast('error', 'Geolocation not supported on this device');
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setForm(p => ({ ...p, lat: pos.coords.latitude, lng: pos.coords.longitude }));
        setLocating(false);
        showToast('success', 'Location detected!');
      },
      (err) => {
        setLocating(false);
        if (err.code === 1) showToast('error', 'Location permission denied');
        else showToast('error', 'Could not detect location');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // ── Image upload — enforces approval + live plan photo limit ──────────────
  const uploadImage = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (fileInputRef.current) fileInputRef.current.value = '';

    if (!shopId) return showToast('error', 'Save shop details first');

    // 1. Must be approved by admin
    if (!isApproved) {
      return showToast('error', 'Your shop must be approved before uploading photos');
    }

    // 2. Fetch live plan config fresh — catches any mid-session admin changes
    const { data: freshCfg } = await supabase
      .from('app_settings').select('value').eq('key', 'plans_config').maybeSingle();
    let livePlans = plans;
    if (freshCfg?.value) {
      try { livePlans = JSON.parse(freshCfg.value); setPlans(livePlans); } catch {}
    }
    const liveLimit = livePlans[tier]?.photos ?? 0;

    // 3. Enforce limit against current image count
    if (form.images.length >= liveLimit) {
      return showToast('error',
        liveLimit === 0
          ? `Your ${tier} plan does not allow any photos. Upgrade your plan.`
          : `Your ${tier} plan allows ${liveLimit} photo${liveLimit !== 1 ? 's' : ''}. You've reached the limit.`
      );
    }

    setUploadingImg(true);
    try {
      const url = await uploadShopImage(file, shopId);
      const newImages = [...form.images, url];
      setForm(p => ({ ...p, images: newImages }));
      await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
      showToast('success', 'Photo uploaded');
    } catch (err) {
      showToast('error', 'Upload failed: ' + err.message);
    }
    setUploadingImg(false);
  };

  const removeImage = async (url) => {
    const newImages = form.images.filter(i => i !== url);
    setForm(p => ({ ...p, images: newImages }));
    await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
    await deleteImage(url);
    showToast('success', 'Photo removed');
  };

  const geocodeAddress = async (address, city) => {
    const queries = [
      [address, city].filter(Boolean).join(', '),
      city,
    ];
    for (const q of queries) {
      if (!q) continue;
      try {
        const res = await fetch(
          `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q + ', Pakistan')}&format=json&limit=1`,
          { headers: { 'Accept-Language': 'en' } }
        );
        const json = await res.json();
        if (json?.[0]) return { lat: parseFloat(json[0].lat), lng: parseFloat(json[0].lon) };
      } catch {}
    }
    return null;
  };

  const save = async () => {
    if (!form.name || !form.city || !form.address) return showToast('error', 'Name, city and address are required');
    setSaving(true);

    // Auto-geocode if barber hasn't pinned manually
    let lat = form.lat;
    let lng = form.lng;
    if (!lat || !lng) {
      const coords = await geocodeAddress(form.address, form.city);
      if (coords) { lat = coords.lat; lng = coords.lng; }
    }

    if (shopId) {
      // Only update editable fields — never overwrite tier/status/approval from this page
      const { error } = await supabase.from('shops').update({
        name: form.name, city: form.city, address: form.address,
        description: form.description, phone: form.phone,
        lat, lng,
      }).eq('id', shopId);
      if (error) { setSaving(false); return showToast('error', error.message); }
      showToast('success', 'Shop updated!');
    } else {
      const { data, error } = await supabase.from('shops').insert({
        owner_id: user.id,
        name: form.name, city: form.city, address: form.address,
        description: form.description, phone: form.phone,
        lat, lng,
        images: [],
        is_active: false,
        subscription_status: 'pending',
        subscription_tier: 'basic',
      }).select().maybeSingle();
      if (error) { setSaving(false); return showToast('error', error.message); }
      if (data) { setShopId(data.id); setShopMeta(data); }
      showToast('success', 'Shop created! Go to Subscription to choose a plan.');
    }
    setSaving(false);
  };

  const addService = async () => {
    if (!shopId) return showToast('error', 'Save shop details first');
    if (!newSrv.name || !newSrv.price) return showToast('error', 'Name and price required');
    const { data, error } = await supabase.from('services')
      .insert({ ...newSrv, shop_id: shopId, price: parseFloat(newSrv.price), is_active: true })
      .select().maybeSingle();
    if (error) return showToast('error', error.message);
    if (data) setServices(prev => [...prev, data]);
    setNewSrv({ name: '', price: '', duration_minutes: 30 });
    showToast('success', 'Service added');
  };

  const removeService = async (id) => {
    await supabase.from('services').delete().eq('id', id);
    setServices(prev => prev.filter(s => s.id !== id));
    showToast('success', 'Service removed');
  };

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  const mapCenter = form.lat && form.lng ? [form.lat, form.lng] : [30.3753, 69.3451];

  // ── Subscription status banner ─────────────────────────────────────────────
  const approvedAt  = shopMeta?.subscription_approved_at;
  const expiresAt   = shopMeta?.subscription_expires_at;
  const isExpired   = shopMeta?.subscription_status === 'expired';
  const isPending   = shopMeta?.subscription_status === 'pending';

  const fmt = (d) => d ? new Date(d).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' }) : null;

  const canUploadMore = isApproved && form.images.length < photoLimit;

  return (
    <div className="page">
      {ToastEl}

      {/* Full-screen map picker modal */}
      {showMap && createPortal(
        <div style={{ position: 'fixed', inset: 0, zIndex: 3000, background: 'var(--bg)', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', background: 'var(--bg-nav)', borderBottom: '1px solid var(--border)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <button onClick={() => setShowMap(false)} style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 10, width: 36, height: 36, cursor: 'pointer', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-1)' }}>←</button>
              <span style={{ fontSize: 16 }}>Pin Your Shop</span>
            </div>
            <button onClick={() => setShowMap(false)} style={{ background: 'linear-gradient(135deg, var(--brand), var(--brand-2))', color: '#fff', border: 'none', borderRadius: 12, padding: '8px 20px', cursor: 'pointer', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>Done</button>
          </div>
          <div style={{ padding: '10px 20px', background: 'var(--brand-glow)', borderBottom: '1px solid var(--border-brand)', fontSize: 13, color: 'var(--brand)', fontFamily: 'var(--font-display)', fontWeight: 600, textAlign: 'center' }}>
            Tap anywhere on the map to drop a pin on your shop location
          </div>
          <div style={{ flex: 1, position: 'relative' }}>
            <MapContainer center={mapCenter} zoom={form.lat ? 15 : 6} style={{ width: '100%', height: '100%' }} zoomControl attributionControl={false}>
              <TileLayer url="https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png" />
              <LocationPicker position={form.lat && form.lng ? [form.lat, form.lng] : null} onPick={([lat, lng]) => setForm(p => ({ ...p, lat, lng }))} />
              <MapSearch onResult={(lat, lng) => setForm(p => ({ ...p, lat, lng }))} />
            </MapContainer>
            <button onClick={detectLocation} disabled={locating} style={{ position: 'absolute', bottom: 20, right: 16, zIndex: 999, background: '#fff', border: '1.5px solid var(--border-brand)', borderRadius: 14, padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, color: 'var(--brand)', cursor: 'pointer', boxShadow: 'var(--shadow-md)' }}>
              {locating ? <span className="spinner spinner-sm" /> : '📍'} Use My GPS
            </button>
          </div>
          {form.lat && form.lng && (
            <div style={{ padding: '12px 20px', background: 'var(--bg-card)', borderTop: '1px solid var(--border)', fontSize: 12, color: 'var(--text-2)', fontFamily: 'var(--font-display)', textAlign: 'center' }}>
              📍 {form.lat.toFixed(6)}, {form.lng.toFixed(6)} — location saved
            </div>
          )}
        </div>
      , document.body)}

      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
        <span className="page-title">Shop Setup</span>
      </div>

      <div style={{ padding: '20px 20px 0' }}>

        {/* ── Subscription Status Banner ────────────────────────────────────── */}
        {shopMeta && (
          <div className="card" style={{
            marginBottom: 20,
            borderColor: isApproved ? 'var(--success)' : isExpired ? 'var(--error)' : 'var(--border)',
            background: isApproved ? 'rgba(34,197,94,0.05)' : isExpired ? 'rgba(239,68,68,0.05)' : 'var(--bg-card)',
          }}>
            {/* Plan + status row */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div>
                <p style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 2 }}>Current Plan</p>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, textTransform: 'capitalize', color: isApproved ? 'var(--success)' : 'var(--text-1)' }}>
                  {tier}
                </span>
              </div>
              <span className={`badge ${isApproved ? 'badge-success' : isExpired ? 'badge-error' : 'badge-warning'}`}>
                {shopMeta.subscription_status}
              </span>
            </div>

            {/* Approval + expiry dates */}
            {(approvedAt || expiresAt) && (
              <div style={{ display: 'flex', gap: 16, marginBottom: 12, flexWrap: 'wrap' }}>
                {approvedAt && (
                  <div style={{ fontSize: 12, color: 'var(--text-2)' }}>
                    <span style={{ color: 'var(--text-3)' }}>Approved: </span>
                    <strong>{fmt(approvedAt)}</strong>
                  </div>
                )}
                {expiresAt && (
                  <div style={{ fontSize: 12, color: isExpired ? 'var(--error)' : new Date(expiresAt) - new Date() < 3 * 24 * 60 * 60 * 1000 ? 'var(--warning, #f59e0b)' : 'var(--text-2)' }}>
                    <span style={{ color: 'inherit', opacity: 0.75 }}>{isExpired ? 'Expired: ' : 'Expires: '}</span>
                    <strong>{fmt(expiresAt)}</strong>
                  </div>
                )}
              </div>
            )}

            {/* Live perks from plan config */}
            <p style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Your Perks</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              <PerkBadge icon="📸" label={`${photoLimit} photo${photoLimit !== 1 ? 's' : ''}`} active={photoLimit > 0} />
              <PerkBadge icon="📱" label="QR Code"        active={!!planPerks?.qr} />
              <PerkBadge icon="🏅" label="Premium Badge"  active={!!planPerks?.badge} />
              <PerkBadge icon="⭐" label="Priority Listing" active={!!planPerks?.priority} />
            </div>

            {/* Warnings */}
            {!isApproved && isPending && (
              <p style={{ fontSize: 12, color: 'var(--text-2)', marginTop: 12, padding: '8px 12px', background: 'var(--bg-input)', borderRadius: 8 }}>
                ⏳ Awaiting admin approval — photo uploads will be unlocked once your plan is active.
              </p>
            )}
            {isExpired && (
              <p style={{ fontSize: 12, color: 'var(--error)', marginTop: 12, padding: '8px 12px', background: 'rgba(239,68,68,0.07)', borderRadius: 8 }}>
                ⚠️ Your plan has expired. Renew via Subscription to re-enable your shop.
              </p>
            )}
            {isApproved && form.images.length > photoLimit && (
              <p style={{ fontSize: 12, color: 'var(--warning, #f59e0b)', marginTop: 12, padding: '8px 12px', background: 'rgba(245,158,11,0.07)', borderRadius: 8 }}>
                ⚠️ You have {form.images.length} photos but your plan now allows {photoLimit}. New uploads are blocked — upgrade or remove extras.
              </p>
            )}
          </div>
        )}

        {/* ── Basic Info ───────────────────────────────────────────────────── */}
        <div className="card" style={{ marginBottom: 20 }}>
          <p className="section-label" style={{ marginBottom: 16 }}>Basic Info</p>

          {[
            { label: 'Shop Name *', key: 'name', placeholder: 'e.g. Cuts & Glory' },
            { label: 'City *',      key: 'city', placeholder: 'e.g. Lahore' },
            { label: 'Address *',   key: 'address', placeholder: 'Full address' },
            { label: 'Phone',       key: 'phone', placeholder: '+92 300 0000000' },
          ].map(f => (
            <div key={f.key} className="input-group">
              <label className="input-label">{f.label}</label>
              <input className="input" placeholder={f.placeholder}
                value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} />
            </div>
          ))}

          <div className="input-group">
            <label className="input-label">Description</label>
            <textarea className="input" placeholder="Tell customers about your shop..."
              value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
          </div>

          {/* Location */}
          <div className="input-group">
            <label className="input-label">Shop Location on Map</label>
            <div style={{ background: 'var(--bg-input)', border: '1.5px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                {form.lat && form.lng ? (
                  <>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--brand)', fontFamily: 'var(--font-display)', marginBottom: 2 }}>📍 Location set</div>
                    <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{form.lat.toFixed(5)}, {form.lng.toFixed(5)}</div>
                  </>
                ) : (
                  <>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--warning, #f59e0b)', fontFamily: 'var(--font-display)', marginBottom: 2 }}>⚠️ No pin set</div>
                    <div style={{ fontSize: 11, color: 'var(--text-3)' }}>We'll estimate from your address — tap to pin exactly</div>
                  </>
                )}
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {form.lat && form.lng && (
                  <button onClick={() => setForm(p => ({ ...p, lat: null, lng: null }))} style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 10, padding: '7px 12px', cursor: 'pointer', fontSize: 12, color: 'var(--error)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Remove</button>
                )}
                <button onClick={() => setShowMap(true)} style={{ background: 'linear-gradient(135deg, var(--brand), var(--brand-2))', border: 'none', borderRadius: 10, padding: '8px 14px', cursor: 'pointer', fontSize: 12, color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/></svg>
                  {form.lat ? 'Edit' : 'Set'} Location
                </button>
              </div>
            </div>
            <p style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 6 }}>This places your shop as a pin on the map for customers to discover</p>
          </div>

          {/* ── Photos — gated by approval + live plan limit ─────────────── */}
          {shopId && (
            <div className="input-group">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <label className="input-label" style={{ marginBottom: 0 }}>
                  Shop Photos
                  {isApproved
                    ? ` (${form.images.length} / ${photoLimit})`
                    : ' (locked — needs approval)'}
                </label>
                {isApproved && photoLimit > 0 && (
                  <span style={{ fontSize: 11, color: 'var(--text-3)' }}>
                    {Math.max(0, photoLimit - form.images.length)} slot{photoLimit - form.images.length !== 1 ? 's' : ''} left
                  </span>
                )}
              </div>

              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 8 }}>
                {form.images.map(url => (
                  <div key={url} style={{ position: 'relative', width: 80, height: 80 }}>
                    <img src={url} alt="" style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 10 }} />
                    <button onClick={() => removeImage(url)} style={{ position: 'absolute', top: -6, right: -6, width: 22, height: 22, borderRadius: '50%', background: 'var(--error)', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13, lineHeight: 1 }}>✕</button>
                  </div>
                ))}

                {/* Upload button — only shown when approved AND under limit */}
                {canUploadMore && (
                  <label style={{ width: 80, height: 80, borderRadius: 10, border: '2px dashed var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--text-3)', fontSize: 24, background: 'var(--bg-input)' }}>
                    {uploadingImg ? <span className="spinner spinner-sm" /> : '+'}
                    <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadImage} disabled={uploadingImg} />
                  </label>
                )}
              </div>

              {/* Status message below the photo grid */}
              {!isApproved && (
                <p style={{ fontSize: 12, color: 'var(--text-3)', padding: '8px 12px', background: 'var(--bg-input)', borderRadius: 8 }}>
                  🔒 Photo uploads unlock after admin approves your plan.
                </p>
              )}
              {isApproved && photoLimit === 0 && (
                <p style={{ fontSize: 12, color: 'var(--text-3)', padding: '8px 12px', background: 'var(--bg-input)', borderRadius: 8 }}>
                  Your current plan does not include photo uploads. Upgrade your plan to add shop photos.
                </p>
              )}
              {isApproved && photoLimit > 0 && form.images.length >= photoLimit && (
                <p style={{ fontSize: 12, color: 'var(--text-3)', padding: '8px 12px', background: 'var(--bg-input)', borderRadius: 8 }}>
                  Photo limit reached for your {tier} plan. Upgrade to add more.
                </p>
              )}
              {isApproved && photoLimit > 0 && form.images.length < photoLimit && (
                <p style={{ fontSize: 12, color: 'var(--text-3)' }}>Images are auto-compressed before upload</p>
              )}
            </div>
          )}

          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? <span className="spinner spinner-sm" /> : shopId ? 'Update Shop' : 'Create Shop'}
          </button>
        </div>

        {/* ── Services ─────────────────────────────────────────────────────── */}
        <div className="card" style={{ marginBottom: 20 }}>
          <p className="section-label" style={{ marginBottom: 16 }}>Services</p>

          {services.map(s => (
            <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div>
                <div style={{ fontWeight: 600, fontFamily: 'var(--font-display)', fontSize: 14 }}>{s.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text-2)' }}>Rs {s.price} · {s.duration_minutes} min</div>
              </div>
              <button className="btn btn-danger btn-sm" onClick={() => removeService(s.id)}>Remove</button>
            </div>
          ))}

          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ display: 'flex', gap: 10 }}>
              <input className="input" placeholder="Service name" style={{ flex: 2 }}
                value={newSrv.name} onChange={e => setNewSrv(p => ({ ...p, name: e.target.value }))} />
              <input className="input" placeholder="Price" type="number" style={{ flex: 1 }}
                value={newSrv.price} onChange={e => setNewSrv(p => ({ ...p, price: e.target.value }))} />
            </div>
            <select className="input" value={newSrv.duration_minutes}
              onChange={e => setNewSrv(p => ({ ...p, duration_minutes: parseInt(e.target.value) }))}>
              {[15, 20, 30, 45, 60, 90].map(d => <option key={d} value={d}>{d} minutes</option>)}
            </select>
            <button className="btn btn-secondary" onClick={addService}>+ Add Service</button>
          </div>
        </div>

      </div>
    </div>
  );
}
