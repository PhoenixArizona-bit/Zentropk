import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { format, addDays } from 'date-fns';

const PLAN_DEFAULTS = {
  basic:   { badge: false, priority: false },
  pro:     { badge: false, priority: true  },
  premium: { badge: true,  priority: true  },
};

export default function ShopDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { showToast, ToastEl } = useToast();

  const [shop, setShop]           = useState(null);
  const [services, setServices]   = useState([]);
  const [reviews, setReviews]     = useState([]);
  const [slots, setSlots]         = useState([]);
  const [loading, setLoading]     = useState(true);
  const [plansConfig, setPlansConfig] = useState(PLAN_DEFAULTS);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [selectedSrv, setSelectedSrv]   = useState(null);
  const [booking, setBooking]     = useState(false);
  const [imgIdx, setImgIdx]       = useState(0);

  useEffect(() => {
    fetchShop();
    supabase.from('app_settings').select('value').eq('key', 'plans_config').maybeSingle().then(({ data }) => {
      if (data?.value) {
        try {
          const parsed = JSON.parse(data.value);
          setPlansConfig(t => {
            const merged = {};
            for (const k of ['basic', 'pro', 'premium']) merged[k] = { ...PLAN_DEFAULTS[k], ...(parsed[k] || {}) };
            return merged;
          });
        } catch {}
      }
    });
  }, [id]);
  useEffect(() => { fetchSlots(); }, [id, selectedDate]);

  const fetchShop = async () => {
    const [{ data: s }, { data: srv }, { data: rev }] = await Promise.all([
      supabase.from('shops').select('*').eq('id', id).maybeSingle(),
      supabase.from('services').select('*').eq('shop_id', id).eq('is_active', true),
      supabase.from('reviews').select('*, profiles(full_name)').eq('shop_id', id).order('created_at', { ascending: false }).limit(10),
    ]);
    setShop(s);
    setServices(srv || []);
    setReviews(rev || []);
    setLoading(false);
  };

  const fetchSlots = async () => {
    const { data } = await supabase
      .from('time_slots')
      .select('*')
      .eq('shop_id', id)
      .eq('slot_date', selectedDate)
      .eq('is_booked', false)
      .order('start_time');
    setSlots(data || []);
  };

  const bookSlot = async () => {
    if (!user) return navigate('/login');
    if (!selectedSlot || !selectedSrv) return showToast('error', 'Select a service and time slot');
    setBooking(true);

    const { error } = await supabase.from('bookings').insert({
      shop_id: id,
      customer_id: user.id,
      time_slot_id: selectedSlot.id,
      service_id: selectedSrv.id,
      status: 'pending',
    });

    if (!error) {
      await supabase.from('time_slots').update({ is_booked: true }).eq('id', selectedSlot.id);
      showToast('success', 'Booking confirmed!');
      setSelectedSlot(null);
      fetchSlots();
    } else {
      console.error('[DB] booking error:', error);
      showToast('error', 'Booking failed: ' + error.message);
    }
    setBooking(false);
  };

  // Generate next 7 days
  const dates = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(new Date(), i);
    return { value: format(d, 'yyyy-MM-dd'), label: format(d, 'EEE'), day: format(d, 'd') };
  });

  if (loading) return (
    <div className="loading-screen">
      <div className="spinner" />
    </div>
  );

  if (!shop) return (
    <div className="empty-state" style={{ minHeight: '100dvh' }}>
      <div className="empty-icon">🔍</div>
      <div className="empty-title">Shop not found</div>
      <button className="btn btn-secondary btn-sm" onClick={() => navigate('/')}>Go Home</button>
    </div>
  );

  const imgs = shop.images || [];

  return (
    <div className="page">
      {ToastEl}

      {/* Back */}
      <div style={{ position: 'absolute', top: 16, left: 16, zIndex: 10 }}>
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
      </div>

      {/* Images */}
      <div style={{ position: 'relative', height: 260, background: 'var(--bg-input)', overflow: 'hidden' }}>
        {imgs.length > 0 ? (
          <img src={imgs[imgIdx]} alt={shop.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : (
          <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 64 }}>✂️</div>
        )}
        {imgs.length > 1 && (
          <div style={{ position: 'absolute', bottom: 12, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 6 }}>
            {imgs.map((_, i) => (
              <div key={i} onClick={() => setImgIdx(i)}
                style={{ width: i === imgIdx ? 20 : 6, height: 6, borderRadius: 3,
                  background: i === imgIdx ? 'var(--brand)' : 'rgba(255,255,255,0.4)',
                  transition: 'all 0.2s', cursor: 'pointer' }} />
            ))}
          </div>
        )}
      </div>

      <div style={{ padding: '20px 20px 0' }}>
        {/* Shop Info */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
            <h1 style={{ fontSize: 26 }}>{shop.name}</h1>
            {plansConfig[shop.subscription_tier]?.badge === true && shop.subscription_tier !== 'basic' && (
              <span className="badge badge-brand">{shop.subscription_tier}</span>
            )}
          </div>
          <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 8 }}>📍 {shop.address}, {shop.city}</p>
          {shop.rating && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <span className="stars">{'★'.repeat(Math.round(shop.rating))}</span>
              <span style={{ fontSize: 13, color: 'var(--text-2)' }}>{shop.rating.toFixed(1)} ({reviews.length} reviews)</span>
            </div>
          )}
          {shop.description && <p style={{ color: 'var(--text-2)', fontSize: 14, lineHeight: 1.6 }}>{shop.description}</p>}
        </div>

        {/* Services */}
        {services.length > 0 && (
          <div style={{ marginBottom: 28 }}>
            <p className="section-label">Services</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {services.map(srv => (
                <div key={srv.id} onClick={() => setSelectedSrv(selectedSrv?.id === srv.id ? null : srv)}
                  style={{
                    padding: '14px 16px', borderRadius: 'var(--radius)',
                    border: `1.5px solid ${selectedSrv?.id === srv.id ? 'var(--brand)' : 'var(--border)'}`,
                    background: selectedSrv?.id === srv.id ? 'var(--brand-dim)' : 'var(--bg-card)',
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    cursor: 'pointer', transition: 'all 0.2s'
                  }}>
                  <div>
                    <div style={{ fontWeight: 600, fontFamily: 'var(--font-display)', marginBottom: 2 }}>{srv.name}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-2)' }}>{srv.duration_minutes} min</div>
                  </div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--brand)', fontSize: 16 }}>
                    Rs {srv.price}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Date Picker */}
        <div style={{ marginBottom: 20 }}>
          <p className="section-label">Pick a Date</p>
          <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 8 }}>
            {dates.map(d => (
              <button key={d.value} onClick={() => { setSelectedDate(d.value); setSelectedSlot(null); }}
                style={{
                  flexShrink: 0, width: 56, padding: '10px 0',
                  borderRadius: 'var(--radius-sm)', border: `1.5px solid ${selectedDate === d.value ? 'var(--brand)' : 'var(--border)'}`,
                  background: selectedDate === d.value ? 'var(--brand-dim)' : 'var(--bg-input)',
                  color: selectedDate === d.value ? 'var(--brand)' : 'var(--text-2)',
                  fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2
                }}>
                <span style={{ fontSize: 10, textTransform: 'uppercase' }}>{d.label}</span>
                <span style={{ fontSize: 18 }}>{d.day}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Time Slots */}
        <div style={{ marginBottom: 28 }}>
          <p className="section-label">Available Slots</p>
          {slots.length === 0 ? (
            <div className="empty-state" style={{ padding: '30px 0' }}>
              <div className="empty-icon">🕐</div>
              <div className="empty-sub">No slots available for this date</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {slots.map(slot => (
                <button key={slot.id} onClick={() => setSelectedSlot(selectedSlot?.id === slot.id ? null : slot)}
                  className={`chip${selectedSlot?.id === slot.id ? ' active' : ''}`}>
                  {slot.start_time.slice(0, 5)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Book Button */}
        <button className="btn btn-primary" onClick={bookSlot} disabled={booking || !selectedSlot || !selectedSrv}
          style={{ marginBottom: 32 }}>
          {booking ? <span className="spinner spinner-sm" /> : `Book — ${selectedSrv ? `Rs ${selectedSrv.price}` : 'Select Service & Slot'}`}
        </button>

        {/* Reviews */}
        {reviews.length > 0 && (
          <div style={{ marginBottom: 32 }}>
            <p className="section-label">Reviews</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {reviews.map(r => (
                <div key={r.id} className="card card-sm">
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                    <span style={{ fontWeight: 600, fontSize: 14, fontFamily: 'var(--font-display)' }}>
                      {r.profiles?.full_name || 'Customer'}
                    </span>
                    <span className="stars" style={{ fontSize: 13 }}>{'★'.repeat(r.rating)}</span>
                  </div>
                  {r.comment && <p style={{ color: 'var(--text-2)', fontSize: 13, lineHeight: 1.5 }}>{r.comment}</p>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
