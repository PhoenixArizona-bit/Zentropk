import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { uploadPaymentProof } from '../lib/imageUpload';

const DEFAULT_PLANS = {
  basic:   { name: 'Basic',   price: 999,  color: '#8EA0BC', photos: 3,  qr: false, badge: false, priority: false },
  pro:     { name: 'Pro',     price: 2499, color: '#0080FF', photos: 10, qr: true,  badge: false, priority: true  },
  premium: { name: 'Premium', price: 4999, color: '#FFB800', photos: 30, qr: true,  badge: true,  priority: true  },
};

// All perks in display order
const PERK_DEFS = [
  { key: 'photos',   icon: '📸', label: (v) => `Up to ${v} shop photo${v !== 1 ? 's' : ''}`, isNum: true  },
  { key: 'priority', icon: '⭐', label: ()  => 'Priority listing',                            isNum: false },
  { key: 'badge',    icon: '🏅', label: ()  => 'Premium badge on listing',                    isNum: false },
  { key: 'qr',       icon: '📱', label: ()  => 'QR code for your shop',                       isNum: false },
];

const TIER_COLORS = { basic: '#8EA0BC', pro: '#0080FF', premium: '#FFB800' };

const fmt = (d) => d
  ? new Date(d).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })
  : null;

export default function BarberPayment() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [shop, setShop]             = useState(null);
  const [payments, setPayments]     = useState([]);
  const [settings, setSettings]     = useState({});
  const [plans, setPlans]           = useState(DEFAULT_PLANS);
  const [loading, setLoading]       = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingProof, setUploadingProof] = useState(false);
  const [selectedPlan, setSelectedPlan]     = useState(null);
  const [expandedPlan, setExpandedPlan]     = useState(null);
  const [form, setForm] = useState({ txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    loadData();
  }, [user, authReady]); // eslint-disable-line

  const loadData = async () => {
    const [{ data: s }, { data: pays }, { data: cfg }] = await Promise.all([
      supabase.from('shops')
        .select('id, name, subscription_tier, subscription_status, subscription_approved_at, subscription_expires_at, is_active')
        .eq('owner_id', user.id).maybeSingle(),
      supabase.from('payment_submissions').select('*').eq('owner_id', user.id).order('submitted_at', { ascending: false }),
      supabase.from('app_settings').select('key, value'),
    ]);
    setShop(s);
    setPayments(pays || []);

    const map = {};
    (cfg || []).forEach(r => { map[r.key] = r.value; });
    setSettings(map);

    if (map.plans_config) {
      try { setPlans(JSON.parse(map.plans_config)); } catch {}
    }
    setLoading(false);
  };

  const uploadProof = async (e) => {
    const file = e.target.files[0];
    if (!file || !user) return;
    setUploadingProof(true);
    try {
      const url = await uploadPaymentProof(file, user.id);
      setForm(p => ({ ...p, screenshot_url: url }));
      showToast('success', 'Screenshot uploaded');
    } catch (err) {
      showToast('error', 'Upload failed: ' + err.message);
    }
    setUploadingProof(false);
  };

  const submit = async () => {
    if (!shop)         return showToast('error', 'No shop found — set up your shop first');
    if (!selectedPlan) return showToast('error', 'Select a plan first');
    if (!form.txn_id)  return showToast('error', 'Transaction ID required');
    setSubmitting(true);

    const plan = plans[selectedPlan];
    const { error } = await supabase.from('payment_submissions').insert({
      shop_id:        shop.id,
      owner_id:       user.id,
      amount:         plan.price,
      txn_id:         form.txn_id,
      screenshot_url: form.screenshot_url,
      payment_method: form.payment_method,
      status:         'pending',
      submitted_at:   new Date().toISOString(),
    });

    setSubmitting(false);
    if (error) return showToast('error', error.message);
    showToast('success', 'Payment submitted! Admin will review soon.');
    setForm({ txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });
    setSelectedPlan(null);
    loadData();
  };

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  const accountNumber    = form.payment_method === 'jazzcash' ? settings.jazzcash_number  : settings.easypaisa_number;
  const accountName      = form.payment_method === 'jazzcash' ? settings.jazzcash_name    : settings.easypaisa_name;
  const selectedPlanData = selectedPlan ? plans[selectedPlan] : null;
  const currentTier      = shop?.subscription_tier || 'basic';
  const isActive         = shop?.subscription_status === 'active' && shop?.is_active;
  const isExpired        = shop?.subscription_status === 'expired';
  const approvedAt       = shop?.subscription_approved_at;
  const expiresAt        = shop?.subscription_expires_at;

  return (
    <div className="page">
      {ToastEl}
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
        <span className="page-title">Subscription</span>
      </div>

      <div style={{ padding: '20px 20px 0' }}>

        {/* ── Current Plan Status Card ─────────────────────────────────────── */}
        {shop && (
          <div className="card" style={{
            marginBottom: 20,
            borderColor: isActive ? 'var(--success)' : isExpired ? 'var(--error)' : 'var(--border)',
            background: isActive ? 'rgba(34,197,94,0.05)' : isExpired ? 'rgba(239,68,68,0.05)' : 'var(--bg-card)',
          }}>
            {/* Tier name + badge */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
              <div>
                <p style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 3 }}>Active Plan</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 10, height: 10, borderRadius: '50%', background: TIER_COLORS[currentTier] || '#8EA0BC', flexShrink: 0 }} />
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, textTransform: 'capitalize', color: TIER_COLORS[currentTier] || 'var(--text-1)' }}>
                    {plans[currentTier]?.name || currentTier}
                  </span>
                </div>
              </div>
              <span className={`badge ${isActive ? 'badge-success' : isExpired ? 'badge-error' : 'badge-warning'}`}>
                {shop.subscription_status}
              </span>
            </div>

            {/* Approval + expiry dates */}
            {(approvedAt || expiresAt) && (
              <div style={{ display: 'flex', gap: 16, marginBottom: 12, flexWrap: 'wrap' }}>
                {approvedAt && (
                  <div style={{ fontSize: 12, color: 'var(--text-2)' }}>
                    <span style={{ color: 'var(--text-3)' }}>Approved: </span>
                    <strong>{fmt(approvedAt)}</strong>
                  </div>
                )}
                {expiresAt && (
                  <div style={{
                    fontSize: 12,
                    color: isExpired ? 'var(--error)'
                      : new Date(expiresAt) - new Date() < 3 * 24 * 60 * 60 * 1000 ? '#f59e0b'
                      : 'var(--text-2)',
                  }}>
                    <span style={{ opacity: 0.75 }}>{isExpired ? 'Expired: ' : 'Expires: '}</span>
                    <strong>{fmt(expiresAt)}</strong>
                  </div>
                )}
              </div>
            )}

            {/* Live perks for current plan — always fetched fresh */}
            <p style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>
              Your Perks
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {PERK_DEFS.map(perk => {
                const planData = plans[currentTier] || DEFAULT_PLANS[currentTier];
                const rawVal   = planData?.[perk.key];
                const active   = perk.isNum ? rawVal > 0 : !!rawVal;
                return (
                  <div key={perk.key} style={{ display: 'flex', alignItems: 'center', gap: 10, opacity: active ? 1 : 0.4 }}>
                    <span style={{ fontSize: 14 }}>{perk.icon}</span>
                    <span style={{ fontSize: 13, color: active ? 'var(--text-1)' : 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                      {perk.isNum ? perk.label(rawVal) : perk.label()}
                    </span>
                    <span style={{ marginLeft: 'auto', fontSize: 12, fontWeight: 800, color: active ? 'var(--success)' : 'var(--text-3)' }}>
                      {active ? '✓' : '✕'}
                    </span>
                  </div>
                );
              })}
            </div>

            {isExpired && (
              <p style={{ fontSize: 12, color: 'var(--error)', marginTop: 12, padding: '8px 12px', background: 'rgba(239,68,68,0.07)', borderRadius: 8 }}>
                ⚠️ Plan expired — renew below to reactivate your shop listing.
              </p>
            )}
          </div>
        )}

        {/* ── Plan Comparison ──────────────────────────────────────────────── */}
        <p className="section-label" style={{ marginBottom: 12 }}>Choose a Plan</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
          {Object.entries(plans).map(([key, plan]) => {
            const isSelected = selectedPlan === key;
            const isExpanded = expandedPlan === key;
            const isCurrent  = currentTier === key && isActive;
            const tierColor  = TIER_COLORS[key] || '#8EA0BC';

            return (
              <div key={key} style={{
                borderRadius: 'var(--radius)',
                border: `1.5px solid ${isSelected ? tierColor : isCurrent ? tierColor + '66' : 'var(--border)'}`,
                background: isSelected
                  ? key === 'premium' ? 'rgba(255,184,0,0.06)' : key === 'pro' ? 'rgba(0,128,255,0.05)' : 'rgba(142,160,188,0.06)'
                  : 'var(--bg-card)',
                overflow: 'hidden',
                transition: 'all 0.18s',
                boxShadow: isSelected ? `0 4px 20px ${tierColor}22` : 'var(--shadow-card)',
              }}>
                {/* Current plan tag */}
                {isCurrent && (
                  <div style={{ background: tierColor, padding: '3px 14px', fontSize: 10, fontFamily: 'var(--font-display)', fontWeight: 800, color: '#fff', textAlign: 'center', textTransform: 'uppercase', letterSpacing: 1 }}>
                    Current Plan
                  </div>
                )}

                {/* Header row */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px' }}>
                  {/* Radio */}
                  <div onClick={() => setSelectedPlan(key)} style={{ width: 22, height: 22, borderRadius: '50%', flexShrink: 0, cursor: 'pointer', border: `2px solid ${isSelected ? tierColor : 'var(--border)'}`, background: isSelected ? tierColor : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {isSelected && <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff' }} />}
                  </div>

                  {/* Name + price */}
                  <div style={{ flex: 1, cursor: 'pointer' }} onClick={() => setSelectedPlan(key)}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 8, height: 8, borderRadius: '50%', background: tierColor, flexShrink: 0 }} />
                      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, color: isSelected ? tierColor : 'var(--text-1)', textTransform: 'capitalize' }}>
                        {plan.name}
                      </span>
                    </div>
                    <div style={{ fontSize: 13, color: 'var(--text-2)', fontWeight: 600, marginTop: 2 }}>
                      Rs {plan.price.toLocaleString()} / month
                    </div>
                  </div>

                  {/* Expand button */}
                  <button onClick={() => setExpandedPlan(isExpanded ? null : key)} style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 8, padding: '5px 10px', cursor: 'pointer', fontSize: 11, fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--text-2)', display: 'flex', alignItems: 'center', gap: 4, flexShrink: 0 }}>
                    Details {isExpanded ? '▲' : '▼'}
                  </button>
                </div>

                {/* Quick perk icons (always visible) */}
                <div style={{ display: 'flex', gap: 6, padding: '0 16px 12px', flexWrap: 'wrap' }}>
                  {PERK_DEFS.map(perk => {
                    const rawVal = plan[perk.key];
                    const active = perk.isNum ? rawVal > 0 : !!rawVal;
                    return (
                      <span key={perk.key} title={perk.isNum ? perk.label(rawVal) : perk.label()} style={{ fontSize: 16, opacity: active ? 1 : 0.25, cursor: 'default' }}>
                        {perk.icon}
                      </span>
                    );
                  })}
                </div>

                {/* Expanded perks detail */}
                {isExpanded && (
                  <div style={{ padding: '12px 16px 14px', borderTop: `1px solid ${isSelected ? tierColor + '33' : 'var(--border)'}` }}>
                    {PERK_DEFS.map(perk => {
                      const rawVal = plan[perk.key];
                      const active = perk.isNum ? rawVal > 0 : !!rawVal;
                      return (
                        <div key={perk.key} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 0', opacity: active ? 1 : 0.38 }}>
                          <span style={{ fontSize: 15 }}>{perk.icon}</span>
                          <span style={{ fontSize: 13, color: active ? 'var(--text-1)' : 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                            {perk.isNum ? perk.label(rawVal) : perk.label()}
                          </span>
                          <span style={{ marginLeft: 'auto', fontSize: 12, fontWeight: 800, color: active ? 'var(--success)' : 'var(--text-3)' }}>
                            {active ? '✓' : '✕'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* ── Payment form — only when plan selected ───────────────────────── */}
        {selectedPlan && (
          <>
            {(accountNumber || accountName) && (
              <div className="card" style={{ marginBottom: 20 }}>
                <p className="section-label" style={{ marginBottom: 12 }}>
                  Send Rs {selectedPlanData?.price?.toLocaleString()} To
                </p>
                <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
                  {['jazzcash', 'easypaisa'].map(m => (
                    <button key={m} onClick={() => setForm(p => ({ ...p, payment_method: m }))}
                      className={`btn ${form.payment_method === m ? 'btn-primary' : 'btn-secondary'} btn-sm`}
                      style={{ flex: 1, textTransform: 'capitalize' }}>
                      {m}
                    </button>
                  ))}
                </div>
                {accountNumber && (
                  <div style={{ background: 'var(--bg-input)', borderRadius: 'var(--radius-sm)', padding: '14px 16px' }}>
                    {accountName && (
                      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4 }}>
                        Account: <strong style={{ color: 'var(--text-1)' }}>{accountName}</strong>
                      </p>
                    )}
                    <p style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, color: 'var(--brand)' }}>
                      {accountNumber}
                    </p>
                  </div>
                )}
              </div>
            )}

            <div className="card" style={{ marginBottom: 20 }}>
              <p className="section-label" style={{ marginBottom: 16 }}>Submit Payment Proof</p>

              <div className="input-group">
                <label className="input-label">Transaction ID</label>
                <input className="input" placeholder="TXN ID from receipt"
                  value={form.txn_id} onChange={e => setForm(p => ({ ...p, txn_id: e.target.value }))} />
              </div>

              <div className="input-group">
                <label className="input-label">Payment Screenshot</label>
                {form.screenshot_url ? (
                  <div style={{ position: 'relative', marginBottom: 8 }}>
                    <img src={form.screenshot_url} alt="proof" style={{ width: '100%', borderRadius: 12, maxHeight: 200, objectFit: 'cover' }} />
                    <button onClick={() => setForm(p => ({ ...p, screenshot_url: '' }))} style={{ position: 'absolute', top: 8, right: 8, background: 'var(--error)', color: '#fff', border: 'none', borderRadius: 8, padding: '4px 10px', cursor: 'pointer', fontSize: 12 }}>
                      Remove
                    </button>
                  </div>
                ) : (
                  <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, padding: '16px', border: '2px dashed var(--border)', borderRadius: 'var(--radius-sm)', background: 'var(--bg-input)', cursor: 'pointer', color: 'var(--text-2)', fontSize: 14 }}>
                    {uploadingProof ? <span className="spinner spinner-sm" /> : '📎 Upload Screenshot'}
                    <input type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadProof} disabled={uploadingProof} />
                  </label>
                )}
              </div>

              <button className="btn btn-primary" onClick={submit} disabled={submitting}>
                {submitting ? <span className="spinner spinner-sm" /> : `Submit · ${selectedPlanData?.name} Plan`}
              </button>
            </div>
          </>
        )}

        {/* ── Payment History ──────────────────────────────────────────────── */}
        {payments.length > 0 && (
          <div style={{ marginBottom: 30 }}>
            <p className="section-label" style={{ marginBottom: 12 }}>Payment History</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {payments.map(p => (
                <div key={p.id} className="card card-sm">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>Rs {p.amount?.toLocaleString()}</span>
                    <span className={`badge ${p.status === 'approved' ? 'badge-success' : p.status === 'rejected' ? 'badge-error' : 'badge-warning'}`}>
                      {p.status}
                    </span>
                  </div>
                  <p style={{ fontSize: 12, color: 'var(--text-2)' }}>TXN: {p.txn_id} · {p.payment_method}</p>
                  <p style={{ fontSize: 12, color: 'var(--text-3)' }}>
                    Submitted: {new Date(p.submitted_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </p>
                  {p.reviewed_at && (
                    <p style={{ fontSize: 12, color: p.status === 'approved' ? 'var(--success)' : 'var(--error)' }}>
                      {p.status === 'approved' ? '✓ Approved' : '✕ Rejected'}: {new Date(p.reviewed_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
