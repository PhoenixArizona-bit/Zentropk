import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { uploadShopImage, deleteImage } from '../lib/imageUpload';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';

// Fix leaflet icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

function makeBrandPin() {
  return L.divIcon({
    className: '',
    iconSize:  [36, 44],
    iconAnchor:[18, 44],
    html: `<svg width="36" height="44" viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg">
      <filter id="s"><feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#0080FF" flood-opacity="0.45"/></filter>
      <path d="M18 2C9.16 2 2 9.16 2 18c0 12 16 24 16 24S34 30 34 18C34 9.16 26.84 2 18 2z"
        fill="#0080FF" filter="url(#s)"/>
      <circle cx="18" cy="18" r="8" fill="white" opacity="0.95"/>
      <text x="18" y="22" text-anchor="middle" font-family="Sora,sans-serif" font-weight="900" font-size="11" fill="#0080FF">✂</text>
    </svg>`,
  });
}

// Tap-to-pin component inside the map
function LocationPicker({ position, onPick }) {
  useMapEvents({
    click(e) { onPick([e.latlng.lat, e.latlng.lng]); },
  });
  return position ? <Marker position={position} icon={makeBrandPin()} /> : null;
}

export default function BarberSetup() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [shopId, setShopId]     = useState(null);
  const [loading, setLoading]   = useState(true);
  const [saving, setSaving]     = useState(false);
  const [uploadingImg, setUploadingImg] = useState(false);
  const [services, setServices] = useState([]);
  const [newSrv, setNewSrv]     = useState({ name: '', price: '', duration_minutes: 30 });
  const [showMap, setShowMap]   = useState(false);
  const [locating, setLocating] = useState(false);

  const [form, setForm] = useState({
    name: '', city: '', address: '', description: '', phone: '',
    images: [], lat: null, lng: null,
  });

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    loadExisting();
  }, [user, authReady]); // eslint-disable-line

  const loadExisting = async () => {
    const { data: s } = await supabase
      .from('shops')
      .select('*')
      .eq('owner_id', user.id)
      .maybeSingle();

    if (s) {
      setShopId(s.id);
      setForm({
        name: s.name || '', city: s.city || '',
        address: s.address || '', description: s.description || '',
        phone: s.phone || '', images: s.images || [],
        lat: s.lat || null, lng: s.lng || null,
      });
      const { data: srv } = await supabase.from('services').select('*').eq('shop_id', s.id);
      setServices(srv || []);
    }
    setLoading(false);
  };

  // Get GPS and set as location
  const detectLocation = () => {
    if (!navigator.geolocation) return showToast('error', 'Geolocation not supported on this device');
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setForm(p => ({ ...p, lat: pos.coords.latitude, lng: pos.coords.longitude }));
        setLocating(false);
        showToast('success', 'Location detected!');
      },
      (err) => {
        setLocating(false);
        if (err.code === 1) showToast('error', 'Location permission denied');
        else showToast('error', 'Could not detect location');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const uploadImage = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!shopId) return showToast('error', 'Save shop details first');
    if (form.images.length >= 10) return showToast('error', 'Max 10 images');
    setUploadingImg(true);
    try {
      const url = await uploadShopImage(file, shopId);
      const newImages = [...form.images, url];
      setForm(p => ({ ...p, images: newImages }));
      await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
      showToast('success', 'Image uploaded');
    } catch (err) {
      showToast('error', 'Upload failed: ' + err.message);
    }
    setUploadingImg(false);
  };

  const removeImage = async (url) => {
    const newImages = form.images.filter(i => i !== url);
    setForm(p => ({ ...p, images: newImages }));
    await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
    await deleteImage(url);
    showToast('success', 'Image removed');
  };

  const save = async () => {
    if (!form.name || !form.city || !form.address) return showToast('error', 'Name, city and address are required');
    setSaving(true);

    const payload = {
      ...form,
      owner_id: user.id,
      is_active: false,
      subscription_status: 'pending',
      subscription_tier: 'basic',
    };

    if (shopId) {
      const { error } = await supabase.from('shops').update(payload).eq('id', shopId);
      if (error) { setSaving(false); return showToast('error', error.message); }
      showToast('success', 'Shop updated!');
    } else {
      const { data, error } = await supabase.from('shops').insert(payload).select().maybeSingle();
      if (error) { setSaving(false); return showToast('error', error.message); }
      if (data) setShopId(data.id);
      showToast('success', 'Shop created! Awaiting admin approval.');
    }
    setSaving(false);
  };

  const addService = async () => {
    if (!shopId) return showToast('error', 'Save shop details first');
    if (!newSrv.name || !newSrv.price) return showToast('error', 'Name and price required');
    const { data, error } = await supabase.from('services')
      .insert({ ...newSrv, shop_id: shopId, price: parseFloat(newSrv.price), is_active: true })
      .select().maybeSingle();
    if (error) return showToast('error', error.message);
    if (data) setServices(prev => [...prev, data]);
    setNewSrv({ name: '', price: '', duration_minutes: 30 });
    showToast('success', 'Service added');
  };

  const removeService = async (id) => {
    await supabase.from('services').delete().eq('id', id);
    setServices(prev => prev.filter(s => s.id !== id));
    showToast('success', 'Service removed');
  };

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  const mapCenter = form.lat && form.lng
    ? [form.lat, form.lng]
    : [30.3753, 69.3451]; // Pakistan center fallback

  return (
    <div className="page">
      {ToastEl}

      {/* Full-screen map picker modal */}
      {showMap && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 3000,
          background: 'var(--bg)', display: 'flex', flexDirection: 'column',
        }}>
          {/* Map header */}
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '16px 20px', background: 'var(--bg-nav)',
            borderBottom: '1px solid var(--border)',
            fontFamily: 'var(--font-display)', fontWeight: 700,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <button onClick={() => setShowMap(false)}
                style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 10,
                  width: 36, height: 36, cursor: 'pointer', fontSize: 18, display: 'flex',
                  alignItems: 'center', justifyContent: 'center', color: 'var(--text-1)' }}>
                ←
              </button>
              <span style={{ fontSize: 16 }}>Pin Your Shop</span>
            </div>
            <button
              onClick={() => setShowMap(false)}
              style={{
                background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
                color: '#fff', border: 'none', borderRadius: 12,
                padding: '8px 20px', cursor: 'pointer',
                fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14,
              }}>
              Done
            </button>
          </div>

          {/* Instruction bar */}
          <div style={{
            padding: '10px 20px', background: 'var(--brand-glow)',
            borderBottom: '1px solid var(--border-brand)',
            fontSize: 13, color: 'var(--brand)', fontFamily: 'var(--font-display)', fontWeight: 600,
            textAlign: 'center',
          }}>
            Tap anywhere on the map to drop a pin on your shop location
          </div>

          {/* Map */}
          <div style={{ flex: 1, position: 'relative' }}>
            <MapContainer
              center={mapCenter}
              zoom={form.lat ? 15 : 6}
              style={{ width: '100%', height: '100%' }}
              zoomControl={true}
              attributionControl={false}
            >
              <TileLayer url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png" />
              <LocationPicker
                position={form.lat && form.lng ? [form.lat, form.lng] : null}
                onPick={([lat, lng]) => setForm(p => ({ ...p, lat, lng }))}
              />
            </MapContainer>

            {/* GPS button over the map */}
            <button
              onClick={detectLocation}
              disabled={locating}
              style={{
                position: 'absolute', bottom: 20, right: 16, zIndex: 999,
                background: '#fff', border: '1.5px solid var(--border-brand)',
                borderRadius: 14, padding: '10px 16px',
                display: 'flex', alignItems: 'center', gap: 8,
                fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13,
                color: 'var(--brand)', cursor: 'pointer',
                boxShadow: 'var(--shadow-md)',
              }}>
              {locating ? <span className="spinner spinner-sm" /> : '📍'}
              Use My GPS
            </button>
          </div>

          {/* Coords display */}
          {form.lat && form.lng && (
            <div style={{
              padding: '12px 20px', background: 'var(--bg-card)',
              borderTop: '1px solid var(--border)',
              fontSize: 12, color: 'var(--text-2)', fontFamily: 'var(--font-display)',
              textAlign: 'center',
            }}>
              📍 {form.lat.toFixed(6)}, {form.lng.toFixed(6)} — location saved
            </div>
          )}
        </div>
      )}

      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
        <span className="page-title">Shop Setup</span>
      </div>

      <div style={{ padding: '20px 20px 0' }}>

        {/* Basic Info */}
        <div className="card" style={{ marginBottom: 20 }}>
          <p className="section-label" style={{ marginBottom: 16 }}>Basic Info</p>

          {[
            { label: 'Shop Name *', key: 'name', placeholder: 'e.g. Cuts & Glory' },
            { label: 'City *', key: 'city', placeholder: 'e.g. Lahore' },
            { label: 'Address *', key: 'address', placeholder: 'Full address' },
            { label: 'Phone', key: 'phone', placeholder: '+92 300 0000000' },
          ].map(f => (
            <div key={f.key} className="input-group">
              <label className="input-label">{f.label}</label>
              <input className="input" placeholder={f.placeholder}
                value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} />
            </div>
          ))}

          <div className="input-group">
            <label className="input-label">Description</label>
            <textarea className="input" placeholder="Tell customers about your shop..."
              value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
          </div>

          {/* ── Location ── */}
          <div className="input-group">
            <label className="input-label">Shop Location on Map</label>
            <div style={{
              background: 'var(--bg-input)', border: '1.5px solid var(--border)',
              borderRadius: 'var(--radius-sm)', padding: '12px 16px',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <div>
                {form.lat && form.lng ? (
                  <>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--brand)', fontFamily: 'var(--font-display)', marginBottom: 2 }}>
                      📍 Location set
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-3)' }}>
                      {form.lat.toFixed(5)}, {form.lng.toFixed(5)}
                    </div>
                  </>
                ) : (
                  <>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-2)', fontFamily: 'var(--font-display)', marginBottom: 2 }}>
                      No location set
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-3)' }}>
                      Customers will find you on the map
                    </div>
                  </>
                )}
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {form.lat && form.lng && (
                  <button
                    onClick={() => setForm(p => ({ ...p, lat: null, lng: null }))}
                    style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 10,
                      padding: '7px 12px', cursor: 'pointer', fontSize: 12,
                      color: 'var(--error)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
                    Remove
                  </button>
                )}
                <button
                  onClick={() => setShowMap(true)}
                  style={{
                    background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
                    border: 'none', borderRadius: 10, padding: '8px 14px',
                    cursor: 'pointer', fontSize: 12, color: '#fff',
                    fontFamily: 'var(--font-display)', fontWeight: 700,
                    display: 'flex', alignItems: 'center', gap: 6,
                  }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/>
                  </svg>
                  {form.lat ? 'Edit' : 'Set'} Location
                </button>
              </div>
            </div>
            <p style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 6 }}>
              This places your shop as a pin on the map for customers to discover
            </p>
          </div>

          {/* Images */}
          {shopId && (
            <div className="input-group">
              <label className="input-label">Shop Photos ({form.images.length}/10)</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 10 }}>
                {form.images.map(url => (
                  <div key={url} style={{ position: 'relative', width: 80, height: 80 }}>
                    <img src={url} alt="" style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 10 }} />
                    <button onClick={() => removeImage(url)}
                      style={{ position: 'absolute', top: -6, right: -6, width: 22, height: 22, borderRadius: '50%',
                        background: 'var(--error)', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 13, lineHeight: 1 }}>
                      ✕
                    </button>
                  </div>
                ))}
                {form.images.length < 10 && (
                  <label style={{ width: 80, height: 80, borderRadius: 10, border: '2px dashed var(--border)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                    color: 'var(--text-3)', fontSize: 24, background: 'var(--bg-input)' }}>
                    {uploadingImg ? <span className="spinner spinner-sm" /> : '+'}
                    <input type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadImage} disabled={uploadingImg} />
                  </label>
                )}
              </div>
              <p style={{ fontSize: 12, color: 'var(--text-3)' }}>Images are auto-compressed before upload</p>
            </div>
          )}

          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? <span className="spinner spinner-sm" /> : shopId ? 'Update Shop' : 'Create Shop'}
          </button>
        </div>

        {/* Services */}
        <div className="card" style={{ marginBottom: 20 }}>
          <p className="section-label" style={{ marginBottom: 16 }}>Services</p>

          {services.map(s => (
            <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div>
                <div style={{ fontWeight: 600, fontFamily: 'var(--font-display)', fontSize: 14 }}>{s.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text-2)' }}>Rs {s.price} · {s.duration_minutes} min</div>
              </div>
              <button className="btn btn-danger btn-sm" onClick={() => removeService(s.id)}>Remove</button>
            </div>
          ))}

          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ display: 'flex', gap: 10 }}>
              <input className="input" placeholder="Service name" style={{ flex: 2 }}
                value={newSrv.name} onChange={e => setNewSrv(p => ({ ...p, name: e.target.value }))} />
              <input className="input" placeholder="Price" type="number" style={{ flex: 1 }}
                value={newSrv.price} onChange={e => setNewSrv(p => ({ ...p, price: e.target.value }))} />
            </div>
            <select className="input" value={newSrv.duration_minutes}
              onChange={e => setNewSrv(p => ({ ...p, duration_minutes: parseInt(e.target.value) }))}>
              {[15, 20, 30, 45, 60, 90].map(d => <option key={d} value={d}>{d} minutes</option>)}
            </select>
            <button className="btn btn-secondary" onClick={addService}>+ Add Service</button>
          </div>
        </div>

      </div>
    </div>
  );
}
