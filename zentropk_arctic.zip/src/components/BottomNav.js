import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export default function BottomNav() {
  const { profile } = useAuth();
  const { pathname } = useLocation();

  if (['/login', '/register', '/admin'].some(p => pathname.startsWith(p))) return null;

  const isBarber = profile?.role === 'barber';

  const customerLinks = [
    { to: '/',        icon: '🏠', label: 'Home'    },
    { to: '/explore', icon: '🗺️', label: 'Explore' },
    { to: '/account', icon: '👤', label: 'Account' },
  ];

  const barberLinks = [
    { to: '/barber/dashboard', icon: '📊', label: 'Dashboard' },
    { to: '/barber/slots',     icon: '🕐', label: 'Slots'     },
    { to: '/barber/setup',     icon: '✂️', label: 'Shop'      },
    { to: '/barber/payment',   icon: '💳', label: 'Payment'   },
  ];

  const links = isBarber ? barberLinks : customerLinks;

  return (
    <nav className="bottomnav">
      {links.map(l => (
        <NavLink
          key={l.to}
          to={l.to}
          end={l.to === '/'}
          className={({ isActive }) => `bottomnav-item${isActive ? ' active' : ''}`}
        >
          <span className="bottomnav-icon">{l.icon}</span>
          {l.label}
        </NavLink>
      ))}
    </nav>
  );
}
