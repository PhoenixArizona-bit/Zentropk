import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { format, addDays } from 'date-fns';

export default function BarberSlots() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [shopId, setShopId]       = useState(null);
  const [loading, setLoading]     = useState(true);
  const [slots, setSlots]         = useState([]);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [generating, setGenerating] = useState(false);

  const [genForm, setGenForm] = useState({
    start: '09:00', end: '18:00', interval: 30,
    daysAhead: 7,
  });

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    loadShop();
  }, [user, authReady]); // eslint-disable-line

  useEffect(() => {
    if (shopId) loadSlots();
  }, [shopId, selectedDate]); // eslint-disable-line

  const loadShop = async () => {
    const { data } = await supabase.from('shops').select('id').eq('owner_id', user.id).maybeSingle();
    if (data) setShopId(data.id);
    else showToast('error', 'Set up your shop first');
    setLoading(false);
  };

  const loadSlots = useCallback(async () => {
    const { data } = await supabase
      .from('time_slots')
      .select('*')
      .eq('shop_id', shopId)
      .eq('slot_date', selectedDate)
      .order('start_time');
    setSlots(data || []);
  }, [shopId, selectedDate]);

  const generateSlots = async () => {
    if (!shopId) return;
    setGenerating(true);

    const dates = Array.from({ length: genForm.daysAhead }, (_, i) =>
      format(addDays(new Date(), i), 'yyyy-MM-dd')
    );

    const toInsert = [];
    for (const date of dates) {
      const [sh, sm] = genForm.start.split(':').map(Number);
      const [eh, em] = genForm.end.split(':').map(Number);
      let cur = sh * 60 + sm;
      const end = eh * 60 + em;

      while (cur + genForm.interval <= end) {
        const hh = String(Math.floor(cur / 60)).padStart(2, '0');
        const mm = String(cur % 60).padStart(2, '0');
        const nh = String(Math.floor((cur + genForm.interval) / 60)).padStart(2, '0');
        const nm = String((cur + genForm.interval) % 60).padStart(2, '0');
        toInsert.push({
          shop_id: shopId,
          slot_date: date,
          start_time: `${hh}:${mm}:00`,
          end_time: `${nh}:${nm}:00`,
          is_booked: false,
        });
        cur += genForm.interval;
      }
    }

    // Upsert to avoid duplicates
    const { error } = await supabase.from('time_slots').upsert(toInsert, {
      onConflict: 'shop_id,slot_date,start_time',
      ignoreDuplicates: true,
    });

    setGenerating(false);
    if (error) { console.error('[DB] generateSlots error:', error); return showToast('error', error.message); }
    showToast('success', `Generated slots for ${genForm.daysAhead} days`);
    loadSlots();
  };

  const deleteSlot = async (id) => {
    await supabase.from('time_slots').delete().eq('id', id);
    setSlots(prev => prev.filter(s => s.id !== id));
  };

  const deleteAllForDate = async () => {
    await supabase.from('time_slots').delete().eq('shop_id', shopId).eq('slot_date', selectedDate).eq('is_booked', false);
    showToast('success', 'Cleared all free slots');
    loadSlots();
  };

  const dates = Array.from({ length: 14 }, (_, i) => {
    const d = addDays(new Date(), i);
    return { value: format(d, 'yyyy-MM-dd'), label: format(d, 'EEE'), day: format(d, 'd') };
  });

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  return (
    <div className="page">
      {ToastEl}
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
        <span className="page-title">Time Slots</span>
      </div>

      <div style={{ padding: '20px 20px 0' }}>
        {/* Generate */}
        <div className="card" style={{ marginBottom: 20 }}>
          <p className="section-label" style={{ marginBottom: 16 }}>Generate Slots</p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
            <div className="input-group" style={{ marginBottom: 0 }}>
              <label className="input-label">Start Time</label>
              <input className="input" type="time" value={genForm.start}
                onChange={e => setGenForm(p => ({ ...p, start: e.target.value }))} />
            </div>
            <div className="input-group" style={{ marginBottom: 0 }}>
              <label className="input-label">End Time</label>
              <input className="input" type="time" value={genForm.end}
                onChange={e => setGenForm(p => ({ ...p, end: e.target.value }))} />
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
            <div className="input-group" style={{ marginBottom: 0 }}>
              <label className="input-label">Interval (min)</label>
              <select className="input" value={genForm.interval}
                onChange={e => setGenForm(p => ({ ...p, interval: parseInt(e.target.value) }))}>
                {[15, 20, 30, 45, 60].map(v => <option key={v} value={v}>{v} min</option>)}
              </select>
            </div>
            <div className="input-group" style={{ marginBottom: 0 }}>
              <label className="input-label">Days Ahead</label>
              <select className="input" value={genForm.daysAhead}
                onChange={e => setGenForm(p => ({ ...p, daysAhead: parseInt(e.target.value) }))}>
                {[1, 3, 7, 14, 30].map(v => <option key={v} value={v}>{v} days</option>)}
              </select>
            </div>
          </div>
          <button className="btn btn-primary" onClick={generateSlots} disabled={generating || !shopId}>
            {generating ? <span className="spinner spinner-sm" /> : '⚡ Generate Slots'}
          </button>
        </div>

        {/* Date picker */}
        <p className="section-label">View / Manage</p>
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 12, marginBottom: 16 }}>
          {dates.map(d => (
            <button key={d.value} onClick={() => setSelectedDate(d.value)}
              style={{
                flexShrink: 0, width: 52, padding: '8px 0',
                borderRadius: 'var(--radius-sm)',
                border: `1.5px solid ${selectedDate === d.value ? 'var(--brand)' : 'var(--border)'}`,
                background: selectedDate === d.value ? 'var(--brand-dim)' : 'var(--bg-input)',
                color: selectedDate === d.value ? 'var(--brand)' : 'var(--text-2)',
                fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
              }}>
              <span style={{ fontSize: 9, textTransform: 'uppercase' }}>{d.label}</span>
              <span style={{ fontSize: 17 }}>{d.day}</span>
            </button>
          ))}
        </div>

        {/* Slots list */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <span style={{ fontSize: 14, color: 'var(--text-2)' }}>{slots.length} slots on {selectedDate}</span>
          {slots.some(s => !s.is_booked) && (
            <button className="btn btn-danger btn-sm" onClick={deleteAllForDate}>Clear Free</button>
          )}
        </div>

        {slots.length === 0 ? (
          <div className="empty-state" style={{ padding: '30px 0' }}>
            <div className="empty-icon">🕐</div>
            <div className="empty-sub">No slots for this date. Generate some above.</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 30 }}>
            {slots.map(s => (
              <div key={s.id} style={{
                padding: '8px 14px', borderRadius: 'var(--radius-sm)',
                border: `1.5px solid ${s.is_booked ? 'var(--error)' : 'var(--success)'}`,
                background: s.is_booked ? 'rgba(255,59,48,0.08)' : 'rgba(0,200,100,0.08)',
                display: 'flex', alignItems: 'center', gap: 8,
              }}>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13,
                  color: s.is_booked ? 'var(--error)' : 'var(--success)' }}>
                  {s.start_time.slice(0, 5)}
                </span>
                {!s.is_booked && (
                  <button onClick={() => deleteSlot(s.id)}
                    style={{ background: 'none', border: 'none', color: 'var(--text-3)', cursor: 'pointer', fontSize: 14, lineHeight: 1 }}>
                    ✕
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
