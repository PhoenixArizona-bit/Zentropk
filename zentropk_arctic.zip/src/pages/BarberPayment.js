import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { uploadPaymentProof } from '../lib/imageUpload';

export default function BarberPayment() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [shop, setShop]           = useState(null);
  const [payments, setPayments]   = useState([]);
  const [settings, setSettings]   = useState({});
  const [loading, setLoading]     = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingProof, setUploadingProof] = useState(false);
  const [form, setForm] = useState({ amount: '', txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });

  const uploadProof = async (e) => {
    const file = e.target.files[0];
    if (!file || !user) return;
    setUploadingProof(true);
    try {
      const url = await uploadPaymentProof(file, user.id);
      setForm(p => ({ ...p, screenshot_url: url }));
      showToast('success', 'Screenshot uploaded');
    } catch (err) {
      showToast('error', 'Upload failed: ' + err.message);
    }
    setUploadingProof(false);
  };

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    loadData();
  }, [user, authReady]); // eslint-disable-line

  const loadData = async () => {
    const [{ data: s }, { data: pays }, { data: cfg }] = await Promise.all([
      supabase.from('shops').select('id, name, subscription_tier, subscription_status').eq('owner_id', user.id).maybeSingle(),
      supabase.from('payment_submissions').select('*').eq('owner_id', user.id).order('submitted_at', { ascending: false }),
      supabase.from('app_settings').select('key, value')
        .in('key', ['jazzcash_number', 'easypaisa_number', 'jazzcash_name', 'easypaisa_name']),
    ]);
    setShop(s);
    setPayments(pays || []);

    const map = {};
    (cfg || []).forEach(r => { map[r.key] = r.value; });
    setSettings(map);
    setLoading(false);
  };

  const submit = async () => {
    if (!shop) return showToast('error', 'No shop found');
    if (!form.amount || !form.txn_id) return showToast('error', 'Amount and transaction ID required');
    setSubmitting(true);

    const { error } = await supabase.from('payment_submissions').insert({
      shop_id: shop.id,
      owner_id: user.id,
      amount: parseFloat(form.amount),
      txn_id: form.txn_id,
      screenshot_url: form.screenshot_url,
      payment_method: form.payment_method,
      status: 'pending',
      submitted_at: new Date().toISOString(),
    });

    setSubmitting(false);
    if (error) { console.error('[DB] payment submit error:', error); return showToast('error', error.message); }
    showToast('success', 'Payment submitted! Admin will review soon.');
    setForm({ amount: '', txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });
    loadData();
  };

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  const accountNumber = form.payment_method === 'jazzcash' ? settings.jazzcash_number : settings.easypaisa_number;
  const accountName   = form.payment_method === 'jazzcash' ? settings.jazzcash_name   : settings.easypaisa_name;

  return (
    <div className="page">
      {ToastEl}
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
        <span className="page-title">Subscription Payment</span>
      </div>

      <div style={{ padding: '20px 20px 0' }}>
        {/* Current Plan */}
        {shop && (
          <div className="card" style={{ marginBottom: 20 }}>
            <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4 }}>Current Plan</p>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, textTransform: 'capitalize' }}>
                {shop.subscription_tier || 'Basic'}
              </span>
              <span className={`badge ${shop.subscription_status === 'active' ? 'badge-success' : 'badge-warning'}`}>
                {shop.subscription_status || 'Pending'}
              </span>
            </div>
          </div>
        )}

        {/* Payment Info */}
        {(accountNumber || accountName) && (
          <div className="card" style={{ marginBottom: 20 }}>
            <p className="section-label" style={{ marginBottom: 12 }}>Send Payment To</p>
            <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
              {['jazzcash', 'easypaisa'].map(m => (
                <button key={m} onClick={() => setForm(p => ({ ...p, payment_method: m }))}
                  className={`btn ${form.payment_method === m ? 'btn-primary' : 'btn-secondary'} btn-sm`}
                  style={{ flex: 1, textTransform: 'capitalize' }}>
                  {m}
                </button>
              ))}
            </div>
            {accountNumber && (
              <div style={{ background: 'var(--bg-input)', borderRadius: 'var(--radius-sm)', padding: '14px 16px' }}>
                {accountName && <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4 }}>Account Name: <strong style={{ color: 'var(--text-1)' }}>{accountName}</strong></p>}
                <p style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, color: 'var(--brand)' }}>{accountNumber}</p>
              </div>
            )}
          </div>
        )}

        {/* Submit Form */}
        <div className="card" style={{ marginBottom: 20 }}>
          <p className="section-label" style={{ marginBottom: 16 }}>Submit Payment Proof</p>

          <div className="input-group">
            <label className="input-label">Amount Paid (Rs)</label>
            <input className="input" type="number" placeholder="e.g. 1000"
              value={form.amount} onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} />
          </div>

          <div className="input-group">
            <label className="input-label">Transaction ID</label>
            <input className="input" placeholder="TXN ID from receipt"
              value={form.txn_id} onChange={e => setForm(p => ({ ...p, txn_id: e.target.value }))} />
          </div>

          <div className="input-group">
            <label className="input-label">Payment Screenshot</label>
            {form.screenshot_url ? (
              <div style={{ position: 'relative', marginBottom: 8 }}>
                <img src={form.screenshot_url} alt="proof" style={{ width: '100%', borderRadius: 12, maxHeight: 200, objectFit: 'cover' }} />
                <button onClick={() => setForm(p => ({ ...p, screenshot_url: '' }))}
                  style={{ position: 'absolute', top: 8, right: 8, background: 'var(--error)', color: '#fff',
                    border: 'none', borderRadius: 8, padding: '4px 10px', cursor: 'pointer', fontSize: 12 }}>
                  Remove
                </button>
              </div>
            ) : (
              <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
                padding: '16px', border: '2px dashed var(--border)', borderRadius: 'var(--radius-sm)',
                background: 'var(--bg-input)', cursor: 'pointer', color: 'var(--text-2)', fontSize: 14 }}>
                {uploadingProof ? <span className="spinner spinner-sm" /> : '📎 Upload Screenshot (auto-compressed)'}
                <input type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadProof} disabled={uploadingProof} />
              </label>
            )}
          </div>

          <button className="btn btn-primary" onClick={submit} disabled={submitting}>
            {submitting ? <span className="spinner spinner-sm" /> : 'Submit Payment'}
          </button>
        </div>

        {/* History */}
        {payments.length > 0 && (
          <div style={{ marginBottom: 30 }}>
            <p className="section-label">Payment History</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {payments.map(p => (
                <div key={p.id} className="card card-sm">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>Rs {p.amount}</span>
                    <span className={`badge ${p.status === 'approved' ? 'badge-success' : p.status === 'rejected' ? 'badge-error' : 'badge-warning'}`}>
                      {p.status}
                    </span>
                  </div>
                  <p style={{ fontSize: 12, color: 'var(--text-2)' }}>TXN: {p.txn_id} · {p.payment_method}</p>
                  <p style={{ fontSize: 12, color: 'var(--text-3)' }}>{new Date(p.submitted_at).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
