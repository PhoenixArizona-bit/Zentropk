import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useToast } from '../hooks/useToast';

export default function Register() {
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();
  const [name, setName]   = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass]   = useState('');
  const [role, setRole]   = useState('customer');
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!name || !email || !pass) return showToast('error', 'Fill in all fields');
    if (pass.length < 6) return showToast('error', 'Password must be 6+ characters');
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({ email, password: pass });
    if (error) { setLoading(false); return showToast('error', error.message); }
    const uid = data.user?.id;
    if (uid) await supabase.from('profiles').insert({ id: uid, full_name: name, email, role });
    setLoading(false);
    showToast('success', 'Account created!');
    setTimeout(() => navigate('/'), 1000);
  };

  return (
    <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '40px 24px', maxWidth: 480, margin: '0 auto' }}>
      {ToastEl}

      <div style={{ marginBottom: 36 }} className="fade-up">
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 34, letterSpacing: -0.5, marginBottom: 8 }}>
          Join<span style={{ color: 'var(--brand)' }}>Zentro</span>
        </div>
        <p style={{ color: 'var(--text-2)', fontSize: 15 }}>Create your account</p>
      </div>

      <div className="fade-up" style={{ animationDelay: '0.08s' }}>
        {/* Role selector — styled like JSX reference */}
        <div style={{ marginBottom: 20 }}>
          <div className="input-label" style={{ marginBottom: 8 }}>I am a</div>
          <div style={{ display: 'flex', gap: 8 }}>
            {[
              { value: 'customer', label: '👤 Customer' },
              { value: 'barber',   label: '✂️ Barber' },
            ].map(r => (
              <button key={r.value} onClick={() => setRole(r.value)} style={{
                flex: 1, padding: '12px', borderRadius: 14,
                border: `1.5px solid ${role === r.value ? 'var(--brand)' : 'var(--border-strong)'}`,
                background: role === r.value ? 'var(--brand-glow)' : 'var(--bg-input)',
                color: role === r.value ? 'var(--brand)' : 'var(--text-2)',
                fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14,
                cursor: 'pointer', transition: 'all 0.18s',
              }}>
                {r.label}
              </button>
            ))}
          </div>
        </div>

        <div className="input-group">
          <label className="input-label">Full Name</label>
          <input className="input" placeholder="Your name" value={name} onChange={e => setName(e.target.value)} />
        </div>
        <div className="input-group">
          <label className="input-label">Email</label>
          <input className="input" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
        </div>
        <div className="input-group">
          <label className="input-label">Password</label>
          <input className="input" type="password" placeholder="Min 6 characters" value={pass} onChange={e => setPass(e.target.value)} />
        </div>

        <button className="btn btn-primary" onClick={submit} disabled={loading} style={{ marginTop: 8 }}>
          {loading ? <span className="spinner spinner-sm" style={{ borderTopColor: '#fff' }} /> : 'Create Account'}
        </button>

        <p style={{ textAlign: 'center', marginTop: 28, color: 'var(--text-2)', fontSize: 14 }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color: 'var(--brand)', fontWeight: 700 }}>Sign In</Link>
        </p>
      </div>
    </div>
  );
}
