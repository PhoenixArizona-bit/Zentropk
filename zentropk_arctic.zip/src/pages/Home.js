import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

export default function Home() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [shops, setShops]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');

  useEffect(() => { fetchShops(); }, []);

  const fetchShops = async () => {
    const { data } = await supabase
      .from('shops')
      .select('id, name, city, address, images, rating, subscription_tier')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(20);
    setShops(data || []);
    setLoading(false);
  };

  const filtered = shops.filter(s =>
    s.name?.toLowerCase().includes(search.toLowerCase()) ||
    s.city?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page">
      {/* Top Nav */}
      <div className="topnav">
        <div className="topnav-logo">
          Zentro<span>PK</span>
        </div>
        {!user ? (
          <Link to="/login" className="btn btn-primary btn-sm" style={{ minWidth: 80 }}>Sign In</Link>
        ) : (
          <Link to="/account">
            <div style={{
              width: 36, height: 36, borderRadius: '50%',
              background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font-display)', fontWeight: 800,
              color: '#fff', fontSize: 15,
              boxShadow: '0 2px 8px var(--brand-glow)'
            }}>
              {profile?.full_name?.[0]?.toUpperCase() || '?'}
            </div>
          </Link>
        )}
      </div>

      <div style={{ padding: '24px 20px 0' }}>
        <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 20 }}>
          {profile?.role === 'barber' ? (
            <span>Barber account — <Link to="/barber/dashboard" style={{ color: 'var(--brand)', fontWeight: 700 }}>Go to Dashboard ›</Link></span>
          ) : (
            <span>Book your next cut ✂️</span>
          )}
        </p>

        {/* Search */}
        <div style={{ position: 'relative', marginBottom: 28 }}>
          <span style={{
            position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)',
            fontSize: 16, pointerEvents: 'none', color: 'var(--text-3)'
          }}>🔍</span>
          <input
            className="input"
            placeholder="Search shops or city..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ paddingLeft: 42, marginBottom: 0 }}
          />
        </div>

        {/* Section header */}
        <p className="section-label">
          {search ? `Results for "${search}"` : 'Nearby Shops'}
        </p>
        <div className="accent-line" />

        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[1,2,3].map(i => (
              <div key={i} className="skeleton" style={{ height: 220, borderRadius: 'var(--radius)' }} />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">✂️</div>
            <div className="empty-title">No shops found</div>
            <div className="empty-sub">Try a different search or check back later</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {filtered.map((shop, i) => (
              <div key={shop.id} className="fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
                <ShopCard shop={shop} onClick={() => navigate(`/shop/${shop.id}`)} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ShopCard({ shop, onClick }) {
  const img = shop.images?.[0];
  return (
    <div className="shop-card" onClick={onClick}>
      {img ? (
        <img src={img} alt={shop.name} className="shop-card-img" />
      ) : (
        <div className="shop-card-img" style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 48, background: 'var(--bg-input)'
        }}>✂️</div>
      )}
      <div className="shop-card-body">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
          <div className="shop-card-name">{shop.name}</div>
          {shop.subscription_tier && shop.subscription_tier !== 'basic' && (
            <span className="badge badge-brand">{shop.subscription_tier}</span>
          )}
        </div>
        <div className="shop-card-meta">
          <span>📍 {shop.city || shop.address}</span>
          {shop.rating && <span>⭐ {shop.rating.toFixed(1)}</span>}
        </div>
      </div>
    </div>
  );
}
