import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { format } from 'date-fns';

export default function MyBookings() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading]  = useState(true);
  const [tab, setTab]          = useState('upcoming');

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    fetchBookings();
  }, [user, authReady]); // eslint-disable-line

  const fetchBookings = async () => {
    const { data } = await supabase
      .from('bookings')
      .select('*, shops(name, address), services(name, price), time_slots(slot_date, start_time)')
      .eq('customer_id', user.id)
      .order('created_at', { ascending: false });
    setBookings(data || []);
    setLoading(false);
  };

  const cancel = async (id, slotId) => {
    const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', id);
    if (!error) {
      await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
      showToast('success', 'Booking cancelled');
      fetchBookings();
    }
  };

  const today = format(new Date(), 'yyyy-MM-dd');
  const upcoming = bookings.filter(b => b.time_slots?.slot_date >= today && b.status !== 'cancelled');
  const past     = bookings.filter(b => b.time_slots?.slot_date < today || b.status === 'cancelled');
  const list     = tab === 'upcoming' ? upcoming : past;

  return (
    <div className="page">
      {ToastEl}
      <div className="topnav">
        <div className="topnav-logo">Zentro<span>PK</span></div>
        <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Bookings</span>
      </div>

      <div style={{ padding: '24px 20px 0' }}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
          {['upcoming', 'past'].map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`chip${tab === t ? ' active' : ''}`}
              style={{ textTransform: 'capitalize' }}>
              {t} ({t === 'upcoming' ? upcoming.length : past.length})
            </button>
          ))}
        </div>

        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[1,2].map(i => <div key={i} className="skeleton" style={{ height: 130, borderRadius: 'var(--radius)' }} />)}
          </div>
        ) : list.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📅</div>
            <div className="empty-title">No bookings yet</div>
            <div className="empty-sub">Browse shops and book your next cut</div>
            <button className="btn btn-primary btn-sm" onClick={() => navigate('/')} style={{ marginTop: 16 }}>
              Explore Shops
            </button>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {list.map((b, i) => (
              <div key={b.id} className="fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
                <BookingCard booking={b} onCancel={() => cancel(b.id, b.time_slot_id)} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function BookingCard({ booking: b, onCancel }) {
  const statusColor = {
    pending:   'var(--warning)',
    confirmed: 'var(--success)',
    cancelled: 'var(--text-3)',
    completed: 'var(--brand)',
  };
  return (
    <div className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>{b.shops?.name}</div>
        <span style={{
          fontSize: 10, fontWeight: 700, color: statusColor[b.status],
          textTransform: 'uppercase', fontFamily: 'var(--font-display)',
          background: `${statusColor[b.status]}15`, padding: '3px 9px',
          borderRadius: 20, border: `1px solid ${statusColor[b.status]}30`
        }}>{b.status}</span>
      </div>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 4 }}>
        ✂️ {b.services?.name} — <span style={{ color: 'var(--brand)', fontWeight: 700 }}>Rs {b.services?.price}</span>
      </p>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: b.status === 'pending' ? 14 : 0 }}>
        📅 {b.time_slots?.slot_date} at {b.time_slots?.start_time?.slice(0, 5)}
      </p>
      {b.status === 'pending' && (
        <button className="btn btn-danger btn-sm" onClick={onCancel}>Cancel Booking</button>
      )}
    </div>
  );
}
