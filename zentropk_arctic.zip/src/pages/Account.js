import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { format } from 'date-fns';

// ── Branded QR Generator ─────────────────────────────────────────────────────
// Matches the reference photo: dark modules on light bg, circle logo in center
// with Z icon on top and ZENTRO text below — but in app arctic theme colors.
function ZentroQR({ shopId, shopName, size = 260 }) {
  const canvasRef = useRef(null);
  const [qrReady, setQrReady] = useState(false);

  useEffect(() => {
    if (!shopId) return;
    const url = `${window.location.origin}/shop/${shopId}`;
    drawBrandedQR(url);
  }, [shopId]); // eslint-disable-line

  const drawBrandedQR = (text) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const s = size;
    canvas.width = s;
    canvas.height = s;

    // ── Step 1: fetch QR image from API
    // Theme: #060E1E dark modules on #F0F6FF arctic light background
    // ecc=H gives 30% error correction — plenty of room for center logo
    const qrColor = '060E1E';
    const qrBg    = 'F0F6FF';
    const apiUrl  = `https://api.qrserver.com/v1/create-qr-code/?size=${s}x${s}&data=${encodeURIComponent(text)}&margin=1&color=${qrColor}&bgcolor=${qrBg}&ecc=H`;

    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      // Draw QR onto canvas
      ctx.drawImage(img, 0, 0, s, s);

      // ── Step 2: center logo — circle like reference photo
      const cx = s / 2;
      const cy = s / 2;
      const r  = s * 0.155; // circle radius

      // White ring (border)
      ctx.beginPath();
      ctx.arc(cx, cy, r + 5, 0, Math.PI * 2);
      ctx.fillStyle = '#F0F6FF';
      ctx.fill();

      // Dark navy circle (matches QR module color)
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fillStyle = '#060E1E';
      ctx.fill();

      // Blue brand accent ring inside
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = '#0080FF';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // ── "Z" icon — top half of circle
      const zSize = Math.round(r * 0.72);
      ctx.fillStyle = '#0080FF';
      ctx.font = `900 ${zSize}px Sora, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'alphabetic';
      ctx.fillText('Z', cx, cy - 2);

      // ── "ZENTRO" text — bottom half
      const tSize = Math.round(r * 0.30);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = `700 ${tSize}px Sora, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.letterSpacing = '1px';
      ctx.fillText('ZENTRO', cx, cy + 3);

      setQrReady(true);
    };

    img.onerror = () => {
      // Offline fallback
      ctx.fillStyle = '#F0F6FF';
      ctx.fillRect(0, 0, s, s);
      ctx.fillStyle = '#0080FF';
      ctx.font = `700 13px Sora, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('QR unavailable', s / 2, s / 2);
      ctx.fillText('(requires internet)', s / 2, s / 2 + 18);
      setQrReady(true);
    };

    img.src = apiUrl;
  };

  const download = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `zentro-qr-${shopName?.replace(/\s+/g, '-').toLowerCase()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
      <div style={{
        padding: 12, background: '#fff', borderRadius: 16,
        border: '1.5px solid var(--border-brand)',
        boxShadow: 'var(--shadow-brand)',
        position: 'relative',
      }}>
        <canvas ref={canvasRef} style={{ display: 'block', borderRadius: 8 }} />
        {!qrReady && (
          <div style={{
            position: 'absolute', inset: 12, borderRadius: 8,
            background: 'var(--bg-input)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <div className="spinner" />
          </div>
        )}
      </div>
      <p style={{ fontSize: 12, color: 'var(--text-2)', textAlign: 'center', lineHeight: 1.5 }}>
        Customers scan this to book directly at <strong style={{ color: 'var(--brand)' }}>{shopName}</strong>
      </p>
      {qrReady && (
        <button className="btn btn-secondary btn-sm" onClick={download} style={{ width: 'auto', paddingLeft: 20, paddingRight: 20 }}>
          ⬇ Download QR
        </button>
      )}
    </div>
  );
}

// ── Booking Card ─────────────────────────────────────────────────────────────
function BookingCard({ booking: b, onCancel }) {
  const statusColor = {
    pending:   'var(--warning)',
    confirmed: 'var(--success)',
    cancelled: 'var(--text-3)',
    completed: 'var(--brand)',
  };
  return (
    <div className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>{b.shops?.name}</div>
        <span style={{
          fontSize: 10, fontWeight: 700, color: statusColor[b.status],
          textTransform: 'uppercase', fontFamily: 'var(--font-display)',
          background: `${statusColor[b.status]}18`, padding: '3px 9px',
          borderRadius: 20, border: `1px solid ${statusColor[b.status]}30`
        }}>{b.status}</span>
      </div>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 4 }}>
        ✂️ {b.services?.name} — <span style={{ color: 'var(--brand)', fontWeight: 700 }}>Rs {b.services?.price}</span>
      </p>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: b.status === 'pending' ? 14 : 0 }}>
        📅 {b.time_slots?.slot_date} at {b.time_slots?.start_time?.slice(0, 5)}
      </p>
      {b.status === 'pending' && (
        <button className="btn btn-danger btn-sm" onClick={onCancel}>Cancel Booking</button>
      )}
    </div>
  );
}

// ── Main Account Page ─────────────────────────────────────────────────────────
export default function Account() {
  const { user, profile, signOut, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [bookings, setBookings]   = useState([]);
  const [tab, setTab]             = useState('upcoming');
  const [bLoading, setBLoading]   = useState(true);
  const [shop, setShop]           = useState(null);   // barber only
  const [showQR, setShowQR]       = useState(false);

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    fetchBookings();
    if (profile?.role === 'barber') fetchShop();
  }, [user, authReady, profile]); // eslint-disable-line

  const fetchBookings = async () => {
    const { data, error } = await supabase
      .from('bookings')
      .select('*, shops(name, address), services(name, price), time_slots(slot_date, start_time)')
      .eq('customer_id', user.id)
      .order('created_at', { ascending: false });
    if (error) console.error('bookings fetch error:', error);
    setBookings(data || []);
    setBLoading(false);
  };

  const fetchShop = async () => {
    const { data, error } = await supabase
      .from('shops').select('id, name, is_active')
      .eq('owner_id', user.id).maybeSingle();
    if (error) console.error('shop fetch error:', error);
    setShop(data || null);
  };

  const cancel = async (id, slotId) => {
    const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', id);
    if (!error) {
      await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
      showToast('success', 'Booking cancelled');
      fetchBookings();
    } else {
      showToast('error', 'Failed to cancel');
    }
  };

  const handleSignOut = async () => { await signOut(); navigate('/'); };

  if (!authReady) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) return null;

  const today = format(new Date(), 'yyyy-MM-dd');
  const upcoming = bookings.filter(b => b.time_slots?.slot_date >= today && b.status !== 'cancelled');
  const past     = bookings.filter(b => b.time_slots?.slot_date < today  || b.status === 'cancelled');
  const list     = tab === 'upcoming' ? upcoming : past;

  const hasQR = !!shop;

  return (
    <div className="page">
      {ToastEl}
      <div className="topnav">
        <div className="topnav-logo">Zentro<span>PK</span></div>
        <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Account</span>
      </div>

      <div style={{ padding: '24px 20px 0' }}>

        {/* ── Profile Hero ── */}
        <div className="fade-up" style={{ marginBottom: 20 }}>
          <div style={{
            background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
            borderRadius: 20, padding: 24, color: '#fff',
            display: 'flex', alignItems: 'center', gap: 16,
            boxShadow: 'var(--shadow-brand)'
          }}>
            <div style={{
              width: 60, height: 60, borderRadius: '50%',
              background: 'rgba(255,255,255,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 24,
              flexShrink: 0, border: '2px solid rgba(255,255,255,0.4)'
            }}>
              {profile?.full_name?.[0]?.toUpperCase() || '?'}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, marginBottom: 2 }}>
                {profile?.full_name}
              </div>
              <div style={{ fontSize: 13, opacity: 0.85, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 6 }}>
                {user.email}
              </div>
              <span style={{
                background: 'rgba(255,255,255,0.2)', borderRadius: 100,
                padding: '3px 10px', fontSize: 11, fontWeight: 700,
                fontFamily: 'var(--font-display)', textTransform: 'capitalize'
              }}>
                {profile?.role}
              </span>
            </div>
          </div>
        </div>

        {/* ── Barber Quick Links ── */}
        {profile?.role === 'barber' && (
          <div className="card fade-up" style={{ marginBottom: 20, padding: 0, overflow: 'hidden' }}>
            {[
              { icon: '📊', label: 'Barber Dashboard', to: '/barber/dashboard' },
              { icon: '✂️', label: 'Shop Setup',        to: '/barber/setup' },
              { icon: '🕐', label: 'Manage Slots',      to: '/barber/slots' },
              { icon: '💳', label: 'Subscription',      to: '/barber/payment' },
            ].map((item, i, arr) => (
              <div key={item.to}
                onClick={() => navigate(item.to)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 14,
                  padding: '16px 20px', cursor: 'pointer',
                  borderBottom: i < arr.length - 1 ? '1px solid var(--border)' : 'none',
                  transition: 'background 0.15s'
                }}>
                <span style={{ fontSize: 20 }}>{item.icon}</span>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, flex: 1 }}>{item.label}</span>
                <span style={{ color: 'var(--text-3)', fontSize: 18 }}>›</span>
              </div>
            ))}

            {/* QR Code row for pro/premium barbers */}
            {hasQR && (
              <div
                onClick={() => setShowQR(v => !v)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 14,
                  padding: '16px 20px', cursor: 'pointer',
                  borderTop: '1px solid var(--border)',
                  background: showQR ? 'var(--brand-glow2)' : 'transparent',
                  transition: 'background 0.15s'
                }}>
                <span style={{ fontSize: 20 }}>📱</span>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, flex: 1 }}>
                  My QR Code
  {shop.subscription_tier}
                  </span>
                </span>
                <span style={{ color: 'var(--text-3)', fontSize: 18, transition: 'transform 0.2s', transform: showQR ? 'rotate(90deg)' : 'none' }}>›</span>
              </div>
            )}
          </div>
        )}

        {/* ── QR Panel (barber) ── */}
        {hasQR && showQR && (
          <div className="card fade-up" style={{ marginBottom: 20 }}>
            <p className="section-label" style={{ marginBottom: 16, fontSize: 15 }}>📱 Shop QR Code</p>
            <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 20, lineHeight: 1.6 }}>
              Share or print this QR — customers scan it to book directly at your shop.
            </p>
            <ZentroQR shopId={shop.id} shopName={shop.name} size={220} />
          </div>
        )}

        {/* ── Bookings Section (customers always, barbers optionally) ── */}
        {profile?.role !== 'barber' && (
          <>
            <p className="section-label" style={{ marginBottom: 4 }}>My Bookings</p>
            <div className="accent-line" />

            <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
              {['upcoming', 'past'].map(t => (
                <button key={t} onClick={() => setTab(t)}
                  className={`chip${tab === t ? ' active' : ''}`}
                  style={{ textTransform: 'capitalize' }}>
                  {t} ({t === 'upcoming' ? upcoming.length : past.length})
                </button>
              ))}
            </div>

            {bLoading ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {[1, 2].map(i => <div key={i} className="skeleton" style={{ height: 130, borderRadius: 'var(--radius)' }} />)}
              </div>
            ) : list.length === 0 ? (
              <div className="empty-state" style={{ padding: '40px 0' }}>
                <div className="empty-icon">📅</div>
                <div className="empty-title">No bookings yet</div>
                <div className="empty-sub">Browse shops and book your next cut</div>
                <button className="btn btn-primary btn-sm" onClick={() => navigate('/')} style={{ marginTop: 16 }}>
                  Explore Shops
                </button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {list.map((b, i) => (
                  <div key={b.id} className="fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
                    <BookingCard booking={b} onCancel={() => cancel(b.id, b.time_slot_id)} />
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* ── Sign Out ── */}
        <button className="btn btn-danger fade-up" onClick={handleSignOut} style={{ marginTop: 28, marginBottom: 12 }}>
          Sign Out
        </button>
      </div>
    </div>
  );
}
