import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export default function Account() {
  const { user, profile, signOut, authReady } = useAuth();
  const navigate = useNavigate();

  if (!authReady) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) { navigate('/login'); return null; }

  const handleSignOut = async () => { await signOut(); navigate('/'); };

  const menuItems = [
    ...(profile?.role === 'barber' ? [{ icon: '📊', label: 'Barber Dashboard', to: '/barber/dashboard' }] : []),
    { icon: '📅', label: 'My Bookings', to: '/bookings' },
  ];

  return (
    <div className="page">
      <div className="topnav">
        <div className="topnav-logo">Zentro<span>PK</span></div>
        <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Account</span>
      </div>

      <div style={{ padding: '28px 20px 0' }}>
        {/* Profile hero card */}
        <div className="fade-up" style={{ marginBottom: 24 }}>
          <div style={{
            background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
            borderRadius: 20, padding: 24, color: '#fff',
            display: 'flex', alignItems: 'center', gap: 16,
            boxShadow: 'var(--shadow-brand)'
          }}>
            <div style={{
              width: 60, height: 60, borderRadius: '50%',
              background: 'rgba(255,255,255,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 24,
              flexShrink: 0, border: '2px solid rgba(255,255,255,0.4)'
            }}>
              {profile?.full_name?.[0]?.toUpperCase() || '?'}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, marginBottom: 2 }}>
                {profile?.full_name}
              </div>
              <div style={{ fontSize: 13, opacity: 0.85, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 6 }}>
                {user.email}
              </div>
              <span style={{
                background: 'rgba(255,255,255,0.2)', borderRadius: 100,
                padding: '3px 10px', fontSize: 11, fontWeight: 700,
                fontFamily: 'var(--font-display)', textTransform: 'capitalize'
              }}>
                {profile?.role}
              </span>
            </div>
          </div>
        </div>

        {/* Menu items */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }} className="card fade-up" style={{ padding: 0, marginBottom: 16, overflow: 'hidden' }}>
          {menuItems.map((item, i) => (
            <div key={item.to}
              onClick={() => navigate(item.to)}
              style={{
                display: 'flex', alignItems: 'center', gap: 14,
                padding: '16px 20px', cursor: 'pointer',
                borderBottom: i < menuItems.length - 1 ? '1px solid var(--border)' : 'none',
                transition: 'background 0.15s'
              }}>
              <span style={{ fontSize: 20 }}>{item.icon}</span>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, flex: 1 }}>{item.label}</span>
              <span style={{ color: 'var(--text-3)', fontSize: 18 }}>›</span>
            </div>
          ))}
        </div>

        <button className="btn btn-danger fade-up" onClick={handleSignOut}>Sign Out</button>
      </div>
    </div>
  );
}
