import { useState, useEffect } from 'react';
import { supabase, sha256 } from '../lib/supabase';

// ── Default plans (stored in app_settings as JSON) ───────────────────────────
const DEFAULT_PLANS = {
  basic:   { name: 'Basic',   price: 999,  color: '#8EA0BC', photos: 3,  qr: false, badge: false, priority: false },
  pro:     { name: 'Pro',     price: 2499, color: '#FF5C1A', photos: 10, qr: true,  badge: false, priority: true  },
  premium: { name: 'Premium', price: 4999, color: '#FFB800', photos: 30, qr: true,  badge: true,  priority: true  },
};

// ── Pattern Lock ─────────────────────────────────────────────────────────────
function PatternLock({ onDone, label = 'Draw Pattern' }) {
  const [pattern, setPattern] = useState([]);
  const [drawing, setDrawing] = useState(false);

  const start = (i) => { setPattern([i]); setDrawing(true); };
  const enter = (i) => { if (!drawing || pattern.includes(i)) return; setPattern(p => [...p, i]); };
  const end   = () => {
    if (!drawing) return;
    setDrawing(false);
    if (pattern.length >= 4) onDone(pattern);
    setPattern([]);
  };

  return (
    <div style={{ userSelect: 'none' }}>
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 12, textAlign: 'center' }}>{label}</p>
      <div onMouseLeave={end} onTouchEnd={end}
        style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 60px)', gap: 16, margin: '0 auto', width: 'fit-content' }}>
        {[0,1,2,3,4,5,6,7,8].map(i => (
          <div key={i} data-node={i}
            onMouseDown={() => start(i)} onMouseEnter={() => enter(i)} onMouseUp={end}
            onTouchStart={() => start(i)}
            onTouchMove={e => {
              const t = e.touches[0];
              const el = document.elementFromPoint(t.clientX, t.clientY);
              if (el?.dataset?.node !== undefined) enter(Number(el.dataset.node));
            }}
            style={{
              width: 60, height: 60, borderRadius: '50%', cursor: 'pointer',
              background: pattern.includes(i) ? 'var(--brand-dim)' : 'var(--bg-input)',
              border: `2px solid ${pattern.includes(i) ? 'var(--brand)' : 'var(--border)'}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'all 0.15s',
            }}>
            {pattern.includes(i) && <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'var(--brand)' }} />}
          </div>
        ))}
      </div>
      {pattern.length > 0 && pattern.length < 4 && !drawing && (
        <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--error)', marginTop: 10 }}>Need at least 4 nodes</p>
      )}
    </div>
  );
}

// ── Admin Login (3-step: keyword → password → pattern) ───────────────────────
function AdminLogin({ onAuthed }) {
  const [step, setStep]       = useState('keyword');
  const [keyword, setKeyword] = useState('');
  const [pass, setPass]       = useState('');
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const checkKeyword = async () => {
    setLoading(true); setError('');
    const { data } = await supabase.from('app_settings').select('value').eq('key', 'admin_search_keyword').maybeSingle();
    const expected = data?.value || 'zentro@admin';
    if (keyword.trim() !== expected) { setError('Invalid keyword'); setLoading(false); return; }
    setStep('password'); setLoading(false);
  };

  const checkPass = async () => {
    setLoading(true); setError('');
    const { data } = await supabase.from('app_settings').select('value').eq('key', 'admin_password_hash').maybeSingle();
    const hash = await sha256(pass);
    if (!data || data.value !== hash) { setError('Wrong password'); setLoading(false); return; }
    setStep('pattern'); setLoading(false);
  };

  const checkPattern = async (drawn) => {
    setError('');
    const { data } = await supabase.from('app_settings').select('value').eq('key', 'admin_pattern_hash').maybeSingle();
    const hash = await sha256(drawn.join('-'));
    if (!data || data.value !== hash) { setError('Wrong pattern — try again'); return; }
    onAuthed();
  };

  const stepNum = step === 'keyword' ? 1 : step === 'password' ? 2 : 3;

  return (
    <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '40px 24px' }}>
      <div style={{ textAlign: 'center', marginBottom: 36 }}>
        <div style={{ fontSize: 44, marginBottom: 10 }}>🛡️</div>
        <h1 style={{ fontSize: 26, marginBottom: 4 }}>Admin Portal</h1>
        <p style={{ color: 'var(--text-2)', fontSize: 14 }}>ZentroPK</p>
      </div>

      {/* Step indicators */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 20, marginBottom: 36 }}>
        {['Keyword', 'Password', 'Pattern'].map((label, i) => (
          <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
            <div style={{
              width: 34, height: 34, borderRadius: '50%',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 13,
              background: i + 1 <= stepNum ? 'var(--brand)' : 'var(--bg-input)',
              color: i + 1 <= stepNum ? '#fff' : 'var(--text-3)',
              border: `2px solid ${i + 1 <= stepNum ? 'var(--brand)' : 'var(--border)'}`,
              transition: 'all 0.3s',
            }}>
              {i + 1 < stepNum ? '✓' : i + 1}
            </div>
            <span style={{ fontSize: 10, color: i + 1 === stepNum ? 'var(--brand)' : 'var(--text-3)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>
              {label}
            </span>
          </div>
        ))}
      </div>

      {step === 'keyword' && (
        <div>
          <div className="input-group">
            <label className="input-label">Secret Keyword</label>
            <input className="input" placeholder="Enter admin keyword"
              value={keyword} onChange={e => setKeyword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && checkKeyword()} />
          </div>
          {error && <p style={{ color: 'var(--error)', fontSize: 13, marginBottom: 12 }}>{error}</p>}
          <button className="btn btn-primary" onClick={checkKeyword} disabled={loading}>
            {loading ? <span className="spinner spinner-sm" /> : 'Continue →'}
          </button>
        </div>
      )}

      {step === 'password' && (
        <div>
          <div className="input-group">
            <label className="input-label">Admin Password</label>
            <input className="input" type="password" placeholder="••••••••"
              value={pass} onChange={e => setPass(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && checkPass()} />
          </div>
          {error && <p style={{ color: 'var(--error)', fontSize: 13, marginBottom: 12 }}>{error}</p>}
          <button className="btn btn-primary" onClick={checkPass} disabled={loading}>
            {loading ? <span className="spinner spinner-sm" /> : 'Continue →'}
          </button>
          <button className="btn btn-ghost" onClick={() => { setStep('keyword'); setError(''); }} style={{ marginTop: 10 }}>← Back</button>
        </div>
      )}

      {step === 'pattern' && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <PatternLock onDone={checkPattern} label="Draw your admin pattern" />
          {error && <p style={{ color: 'var(--error)', fontSize: 13, textAlign: 'center', marginTop: 12 }}>{error}</p>}
          <button className="btn btn-ghost" onClick={() => { setStep('password'); setError(''); }} style={{ marginTop: 20, width: '100%' }}>← Back</button>
        </div>
      )}
    </div>
  );
}

// ── Main Admin Portal ─────────────────────────────────────────────────────────
export default function AdminPortal() {
  const [authed, setAuthed]     = useState(false);
  const [tab, setTab]           = useState('shops');
  const [shops, setShops]       = useState([]);
  const [payments, setPayments] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [users, setUsers]       = useState([]);
  const [plans, setPlans]       = useState(DEFAULT_PLANS);
  const [fetched, setFetched]   = useState(false);
  const [toast, setToast]       = useState(null);

  // ── Extensible settings — add any new key here and it auto-saves/loads ──────
  const [settings, setSettings] = useState({
    jazzcash_number:      '',
    jazzcash_name:        '',
    easypaisa_number:     '',
    easypaisa_name:       '',
    admin_search_keyword: 'zentro@admin',
  });

  const showToast = (type, text) => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    if (authed && !fetched) { fetchAll(); setFetched(true); }
  }, [authed]); // eslint-disable-line

  const fetchAll = async () => {
    const [{ data: sh }, { data: pa }, { data: bo }, { data: us }, { data: cfg }] = await Promise.all([
      supabase.from('shops').select('*, profiles(full_name, email)').order('created_at', { ascending: false }),
      supabase.from('payment_submissions').select('*, shops(name)').order('submitted_at', { ascending: false }),
      supabase.from('bookings').select('*, profiles(full_name), shops(name), services(name), time_slots(slot_date, start_time)').order('created_at', { ascending: false }).limit(100),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('app_settings').select('key, value'),
    ]);
    setShops(sh || []);
    setPayments(pa || []);
    setBookings(bo || []);
    setUsers(us || []);

    // Load all settings from DB — any new key added to DB automatically appears
    const map = {};
    (cfg || []).forEach(r => { map[r.key] = r.value; });
    setSettings(prev => ({ ...prev, ...map }));

    // Load plans from DB if saved
    if (map.plans_config) {
      try { setPlans(JSON.parse(map.plans_config)); } catch {}
    }
  };

  const approveShop = async (id, active) => {
    await supabase.from('shops').update({ is_active: active, subscription_status: active ? 'active' : 'pending' }).eq('id', id);
    fetchAll();
    showToast('success', active ? 'Shop approved' : 'Shop deactivated');
  };

  const setShopTier = async (id, tier) => {
    await supabase.from('shops').update({ subscription_tier: tier }).eq('id', id);
    fetchAll();
    showToast('success', `Tier set to ${tier}`);
  };

  const reviewPayment = async (id, status, shopId) => {
    await supabase.from('payment_submissions').update({ status, reviewed_at: new Date().toISOString() }).eq('id', id);
    if (status === 'approved') {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30); // 30 days from now
      await supabase.from('shops').update({
        subscription_status: 'active',
        is_active: true,
        subscription_expires_at: expiresAt.toISOString(),
      }).eq('id', shopId);
    }
    fetchAll();
    showToast('success', `Payment ${status}${status === 'approved' ? ' — subscription active for 30 days' : ''}`);
  };

  const saveSettings = async () => {
    // Exclude hash keys (changed via dedicated changers) and plans_config (saved via savePlans)
    const excludedKeys = ['admin_password_hash', 'admin_pattern_hash', 'plans_config'];
    const rows = Object.entries(settings)
      .filter(([key]) => !excludedKeys.includes(key))
      .map(([key, value]) => ({ key, value: String(value) }));
    if (rows.length === 0) { showToast('error', 'Nothing to save'); return; }
    const { error } = await supabase.from('app_settings').upsert(rows, { onConflict: 'key' });
    if (error) {
      console.error('[DB] saveSettings failed:', error);
      showToast('error', 'Save failed: ' + error.message);
    } else {
      showToast('success', 'Settings saved');
    }
  };

  // Add a new custom setting key at runtime
  const addCustomSetting = (key, value = '') => {
    if (!key || settings[key] !== undefined) return;
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const savePlans = async (updatedPlans) => {
    setPlans(updatedPlans);
    const { error } = await supabase.from('app_settings').upsert(
      { key: 'plans_config', value: JSON.stringify(updatedPlans) },
      { onConflict: 'key' }
    );
    if (error) {
      console.error('[DB] savePlans failed:', error);
      showToast('error', 'Save failed: ' + error.message);
    } else {
      showToast('success', 'Plans saved');
    }
  };

  if (!authed) return <AdminLogin onAuthed={() => setAuthed(true)} />;

  const TABS = [
    { key: 'shops',    label: '🏪 Shops' },
    { key: 'payments', label: '💳 Payments' },
    { key: 'bookings', label: '📅 Bookings' },
    { key: 'users',    label: '👥 Users' },
    { key: 'plans',    label: '📦 Plans' },
    { key: 'settings', label: '⚙️ Settings' },
  ];

  const pendingPayments = payments.filter(p => p.status === 'pending').length;

  return (
    <div style={{ minHeight: '100dvh', paddingBottom: 40 }}>
      {toast && <div className={`toast toast-${toast.type}`}>{toast.text}</div>}

      {/* Header */}
      <div style={{ padding: '24px 20px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ fontSize: 24 }}>🛡️ Admin</h1>
          <p style={{ fontSize: 12, color: 'var(--text-2)', marginTop: 2 }}>
            {shops.length} shops · {users.length} users · {pendingPayments} pending payments
          </p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={() => setAuthed(false)}>🔒 Lock</button>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '0 20px 4px', marginBottom: 20 }}>
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)} style={{
            flexShrink: 0, padding: '8px 16px', borderRadius: 20,
            border: `1.5px solid ${tab === t.key ? 'var(--brand)' : 'var(--border)'}`,
            background: tab === t.key ? 'var(--brand-dim)' : 'var(--bg-input)',
            color: tab === t.key ? 'var(--brand)' : 'var(--text-2)',
            fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, cursor: 'pointer',
          }}>
            {t.label}
            {t.key === 'payments' && pendingPayments > 0 && (
              <span style={{ marginLeft: 6, background: 'var(--brand)', color: '#fff', borderRadius: 10, padding: '1px 6px', fontSize: 11 }}>
                {pendingPayments}
              </span>
            )}
          </button>
        ))}
      </div>

      <div style={{ padding: '0 20px' }}>

        {/* ── SHOPS ── */}
        {tab === 'shops' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{shops.length} total · {shops.filter(s => s.is_active).length} active</p>
            {shops.length === 0 && <div className="empty-state"><div className="empty-icon">🏪</div><div className="empty-sub">No shops yet</div></div>}
            {shops.map(s => (
              <div key={s.id} className="card" style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>{s.name}</div>
                  <span className={`badge ${s.is_active ? 'badge-success' : 'badge-warning'}`}>
                    {s.is_active ? 'Active' : 'Pending'}
                  </span>
                </div>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 2 }}>📍 {s.city}, {s.address}</p>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: s.subscription_expires_at ? 2 : 12 }}>👤 {s.profiles?.full_name}</p>
                {s.subscription_expires_at && (
                  <p style={{ fontSize: 12, marginBottom: 12,
                    color: new Date(s.subscription_expires_at) < new Date() ? 'var(--error)' : 'var(--text-3)' }}>
                    ⏱ {new Date(s.subscription_expires_at) < new Date() ? 'Expired' : 'Expires'}: {new Date(s.subscription_expires_at).toLocaleDateString()}
                  </p>
                )}

                {/* Tier selector */}
                <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
                  {['basic', 'pro', 'premium'].map(tier => (
                    <button key={tier} onClick={() => setShopTier(s.id, tier)}
                      style={{
                        flex: 1, padding: '6px 0', borderRadius: 8, fontSize: 12, fontWeight: 700,
                        fontFamily: 'var(--font-display)', cursor: 'pointer', textTransform: 'capitalize',
                        border: `1.5px solid ${s.subscription_tier === tier ? 'var(--brand)' : 'var(--border)'}`,
                        background: s.subscription_tier === tier ? 'var(--brand-dim)' : 'var(--bg-input)',
                        color: s.subscription_tier === tier ? 'var(--brand)' : 'var(--text-3)',
                      }}>
                      {tier}
                    </button>
                  ))}
                </div>

                <button className={`btn btn-sm ${s.is_active ? 'btn-danger' : 'btn-primary'}`} style={{ width: '100%' }}
                  onClick={() => approveShop(s.id, !s.is_active)}>
                  {s.is_active ? 'Deactivate Shop' : '✓ Approve Shop'}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* ── PAYMENTS ── */}
        {tab === 'payments' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{payments.length} total · {pendingPayments} pending</p>
            {payments.length === 0 && <div className="empty-state"><div className="empty-icon">💳</div><div className="empty-sub">No payments yet</div></div>}
            {payments.map(p => (
              <div key={p.id} className="card" style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{p.shops?.name}</span>
                  <span className={`badge ${p.status === 'approved' ? 'badge-success' : p.status === 'rejected' ? 'badge-error' : 'badge-warning'}`}>
                    {p.status}
                  </span>
                </div>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 2 }}>💰 Rs {p.amount} · {p.payment_method}</p>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 2 }}>🔖 TXN: {p.txn_id}</p>
                <p style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: p.screenshot_url ? 8 : 12 }}>
                  {new Date(p.submitted_at).toLocaleDateString()}
                </p>
                {p.screenshot_url && (
                  <a href={p.screenshot_url} target="_blank" rel="noreferrer"
                    style={{ fontSize: 13, color: 'var(--brand)', display: 'block', marginBottom: 10 }}>
                    📎 View Screenshot ↗
                  </a>
                )}
                {p.status === 'pending' && (
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button className="btn btn-primary btn-sm" style={{ flex: 1 }}
                      onClick={() => reviewPayment(p.id, 'approved', p.shop_id)}>✓ Approve</button>
                    <button className="btn btn-danger btn-sm" style={{ flex: 1 }}
                      onClick={() => reviewPayment(p.id, 'rejected', p.shop_id)}>✕ Reject</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* ── BOOKINGS ── */}
        {tab === 'bookings' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{bookings.length} total bookings</p>
            {bookings.length === 0 && <div className="empty-state"><div className="empty-icon">📅</div><div className="empty-sub">No bookings yet</div></div>}
            {bookings.map(b => (
              <div key={b.id} className="card card-sm" style={{ marginBottom: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>{b.shops?.name}</span>
                  <span style={{ fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-display)',
                    color: b.status === 'completed' ? 'var(--success)' : b.status === 'cancelled' ? 'var(--text-3)' : 'var(--warning)' }}>
                    {b.status?.toUpperCase()}
                  </span>
                </div>
                <p style={{ fontSize: 12, color: 'var(--text-2)' }}>👤 {b.profiles?.full_name} · ✂️ {b.services?.name}</p>
                <p style={{ fontSize: 12, color: 'var(--text-2)' }}>📅 {b.time_slots?.slot_date} at {b.time_slots?.start_time?.slice(0, 5)}</p>
              </div>
            ))}
          </div>
        )}

        {/* ── USERS ── */}
        {tab === 'users' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>
              {users.length} total · {users.filter(u => u.role === 'barber').length} barbers · {users.filter(u => u.role === 'customer').length} customers
            </p>
            {users.length === 0 && <div className="empty-state"><div className="empty-icon">👥</div><div className="empty-sub">No users yet</div></div>}
            {users.map(u => (
              <div key={u.id} className="card card-sm" style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>{u.full_name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-2)' }}>{u.email}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{new Date(u.created_at).toLocaleDateString()}</div>
                </div>
                <span className={`badge ${u.role === 'barber' ? 'badge-brand' : 'badge-success'}`}>{u.role}</span>
              </div>
            ))}
          </div>
        )}

        {/* ── PLANS ── */}
        {tab === 'plans' && (
          <PlansEditor plans={plans} onSave={savePlans} showToast={showToast} />
        )}

        {/* ── SETTINGS ── */}
        {tab === 'settings' && (
          <SettingsEditor
            settings={settings}
            setSettings={setSettings}
            onSave={saveSettings}
            onAddCustom={addCustomSetting}
            showToast={showToast}
          />
        )}
      </div>
    </div>
  );
}

// ── Plans Editor ──────────────────────────────────────────────────────────────
function PlansEditor({ plans, onSave, showToast }) {
  const [local, setLocal] = useState(plans);
  const [saving, setSaving] = useState(false);

  useEffect(() => { setLocal(plans); }, [plans]);

  const update = (tier, field, value) => {
    setLocal(prev => ({
      ...prev,
      [tier]: { ...prev[tier], [field]: field === 'price' ? parseInt(value) || 0 : field === 'photos' ? parseInt(value) || 0 : value }
    }));
  };

  const togglePerk = (tier, perk) => {
    setLocal(prev => ({
      ...prev,
      [tier]: { ...prev[tier], [perk]: !prev[tier][perk] }
    }));
  };

  const save = async () => {
    setSaving(true);
    await onSave(local);
    setSaving(false);
  };

  const tierColors = { basic: '#8EA0BC', pro: 'var(--brand)', premium: '#FFB800' };

  return (
    <div>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 20 }}>
        Edit subscription plan prices and perks. Changes apply immediately after saving.
      </p>

      {Object.entries(local).map(([tier, plan]) => (
        <div key={tier} className="card" style={{ marginBottom: 16, borderColor: tierColors[tier] + '44' }}>
          {/* Tier header */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: tierColors[tier], flexShrink: 0 }} />
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, textTransform: 'capitalize' }}>{tier}</span>
          </div>

          {/* Plan name */}
          <div className="input-group">
            <label className="input-label">Display Name</label>
            <input className="input" value={plan.name}
              onChange={e => update(tier, 'name', e.target.value)} />
          </div>

          {/* Price */}
          <div className="input-group">
            <label className="input-label">Monthly Price (Rs)</label>
            <input className="input" type="number" value={plan.price}
              onChange={e => update(tier, 'price', e.target.value)} />
          </div>

          {/* Photo limit */}
          <div className="input-group">
            <label className="input-label">Max Photos</label>
            <input className="input" type="number" value={plan.photos}
              onChange={e => update(tier, 'photos', e.target.value)} />
          </div>

          {/* Perks toggles */}
          <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>Perks</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { key: 'qr',       label: 'QR Code Payment',   icon: '📱' },
              { key: 'badge',    label: 'Premium Badge',      icon: '🏅' },
              { key: 'priority', label: 'Priority Listing',   icon: '⭐' },
            ].map(perk => (
              <div key={perk.key} onClick={() => togglePerk(tier, perk.key)}
                style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '10px 14px', borderRadius: 'var(--radius-sm)',
                  background: plan[perk.key] ? 'var(--brand-dim)' : 'var(--bg-input)',
                  border: `1.5px solid ${plan[perk.key] ? 'var(--brand)' : 'var(--border)'}`,
                  cursor: 'pointer', transition: 'all 0.2s',
                }}>
                <span style={{ fontSize: 14 }}>{perk.icon} {perk.label}</span>
                <div style={{
                  width: 40, height: 22, borderRadius: 11,
                  background: plan[perk.key] ? 'var(--brand)' : 'var(--border)',
                  position: 'relative', transition: 'background 0.2s',
                }}>
                  <div style={{
                    position: 'absolute', top: 3,
                    left: plan[perk.key] ? 21 : 3,
                    width: 16, height: 16, borderRadius: '50%',
                    background: '#fff', transition: 'left 0.2s',
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      <button className="btn btn-primary" onClick={save} disabled={saving} style={{ marginBottom: 30 }}>
        {saving ? <span className="spinner spinner-sm" /> : '💾 Save Plans'}
      </button>
    </div>
  );
}

// ── Settings Editor ───────────────────────────────────────────────────────────
// Extensible — any new feature just needs a new entry in SETTING_FIELDS
// or the admin can add a custom key at runtime
const SETTING_FIELDS = [
  { section: 'Payment', fields: [
    { label: 'JazzCash Number',      key: 'jazzcash_number' },
    { label: 'JazzCash Account Name', key: 'jazzcash_name' },
    { label: 'Easypaisa Number',     key: 'easypaisa_number' },
    { label: 'Easypaisa Account Name', key: 'easypaisa_name' },
  ]},
  { section: 'Admin Access', fields: [
    { label: 'Secret Keyword', key: 'admin_search_keyword' },
  ]},
];

function SettingsEditor({ settings, setSettings, onSave, onAddCustom, showToast }) {
  const [newKey, setNewKey]     = useState('');
  const [newVal, setNewVal]     = useState('');
  const [saving, setSaving]     = useState(false);

  const save = async () => {
    setSaving(true);
    await onSave();
    setSaving(false);
  };

  // Keys already shown in predefined sections
  const predefinedKeys = SETTING_FIELDS.flatMap(s => s.fields.map(f => f.key))
    .concat(['admin_password_hash', 'admin_pattern_hash', 'plans_config']);

  // Any extra keys from DB not in predefined list = custom settings
  const customKeys = Object.keys(settings).filter(k => !predefinedKeys.includes(k));

  return (
    <div>
      {/* Predefined sections */}
      {SETTING_FIELDS.map(section => (
        <div key={section.section} style={{ marginBottom: 24 }}>
          <p className="section-label" style={{ fontSize: 15, marginBottom: 14 }}>{section.section}</p>
          {section.fields.map(f => (
            <div key={f.key} className="input-group">
              <label className="input-label">{f.label}</label>
              <input className="input" value={settings[f.key] || ''}
                onChange={e => setSettings(p => ({ ...p, [f.key]: e.target.value }))} />
            </div>
          ))}
        </div>
      ))}

      {/* Custom settings added at runtime */}
      {customKeys.length > 0 && (
        <div style={{ marginBottom: 24 }}>
          <p className="section-label" style={{ fontSize: 15, marginBottom: 14 }}>Custom Settings</p>
          {customKeys.map(key => (
            <div key={key} className="input-group">
              <label className="input-label" style={{ fontFamily: 'monospace', fontSize: 12 }}>{key}</label>
              <input className="input" value={settings[key] || ''}
                onChange={e => setSettings(p => ({ ...p, [key]: e.target.value }))} />
            </div>
          ))}
        </div>
      )}

      <button className="btn btn-primary" onClick={save} disabled={saving} style={{ marginBottom: 28 }}>
        {saving ? <span className="spinner spinner-sm" /> : '💾 Save Settings'}
      </button>

      {/* Add custom setting */}
      <div className="divider" />
      <p className="section-label" style={{ fontSize: 15, marginBottom: 6 }}>Add New Setting</p>
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 14 }}>
        Add any new feature setting — it will automatically appear here and be editable forever.
      </p>
      <div style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
        <input className="input" placeholder="setting_key" value={newKey}
          onChange={e => setNewKey(e.target.value.toLowerCase().replace(/\s/g, '_'))} />
        <input className="input" placeholder="value" value={newVal}
          onChange={e => setNewVal(e.target.value)} />
      </div>
      <button className="btn btn-secondary" onClick={() => {
        if (!newKey) return showToast('error', 'Enter a key');
        onAddCustom(newKey, newVal);
        setNewKey(''); setNewVal('');
        showToast('info', `Added "${newKey}" — save to persist`);
      }}>
        + Add Setting
      </button>

      {/* Change Password */}
      <div className="divider" style={{ marginTop: 28 }} />
      <p className="section-label" style={{ fontSize: 15, marginBottom: 14 }}>Change Admin Password</p>
      <AdminPasswordChanger showToast={showToast} />

      {/* Change Pattern */}
      <div className="divider" />
      <p className="section-label" style={{ fontSize: 15, marginBottom: 14 }}>Change Admin Pattern</p>
      <AdminPatternChanger showToast={showToast} />
    </div>
  );
}

// ── Password Changer ──────────────────────────────────────────────────────────
function AdminPasswordChanger({ showToast }) {
  const [newPass, setNewPass] = useState('');
  const [confirm, setConfirm] = useState('');
  const [saving, setSaving]   = useState(false);

  const save = async () => {
    if (newPass.length < 6) return showToast('error', 'Min 6 characters');
    if (newPass !== confirm) return showToast('error', 'Passwords do not match');
    setSaving(true);
    const hash = await sha256(newPass);
    const { error: pwErr } = await supabase.from('app_settings').upsert({ key: 'admin_password_hash', value: hash }, { onConflict: 'key' });
    setSaving(false);
    if (pwErr) { console.error('[DB] password update failed:', pwErr); showToast('error', 'Failed: ' + pwErr.message); return; }
    setNewPass(''); setConfirm('');
    showToast('success', 'Password updated');
  };

  return (
    <div style={{ marginBottom: 8 }}>
      <div className="input-group">
        <label className="input-label">New Password</label>
        <input className="input" type="password" placeholder="Min 6 characters"
          value={newPass} onChange={e => setNewPass(e.target.value)} />
      </div>
      <div className="input-group">
        <label className="input-label">Confirm Password</label>
        <input className="input" type="password" placeholder="Repeat password"
          value={confirm} onChange={e => setConfirm(e.target.value)} />
      </div>
      <button className="btn btn-secondary" onClick={save} disabled={saving}>
        {saving ? <span className="spinner spinner-sm" /> : 'Update Password'}
      </button>
    </div>
  );
}

// ── Pattern Changer ───────────────────────────────────────────────────────────
function AdminPatternChanger({ showToast }) {
  const [drawn, setDrawn] = useState([]);
  const [saved, setSaved] = useState(false);

  const save = async () => {
    if (drawn.length < 4) return showToast('error', 'Draw at least 4 nodes');
    const hash = await sha256(drawn.join('-'));
    const { error: patErr } = await supabase.from('app_settings').upsert({ key: 'admin_pattern_hash', value: hash }, { onConflict: 'key' });
    if (patErr) { console.error('[DB] pattern update failed:', patErr); showToast('error', 'Failed: ' + patErr.message); return; }
    setSaved(true); setDrawn([]);
    showToast('success', 'Pattern updated');
  };

  return (
    <div style={{ marginBottom: 30 }}>
      <PatternLock onDone={(p) => { setDrawn(p); setSaved(false); }} label="Draw new pattern (4+ nodes)" />
      {drawn.length >= 4 && !saved && (
        <button className="btn btn-secondary" onClick={save} style={{ marginTop: 16 }}>
          Save Pattern ({drawn.length} nodes)
        </button>
      )}
    </div>
  );
}
