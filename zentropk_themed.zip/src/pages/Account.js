import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export default function Account() {
  const { user, profile, signOut, authReady } = useAuth();
  const navigate = useNavigate();

  if (!authReady) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) { navigate('/login'); return null; }

  const handleSignOut = async () => { await signOut(); navigate('/'); };

  const menuItems = [
    ...(profile?.role === 'barber' ? [{ icon: '📊', label: 'Barber Dashboard', to: '/barber/dashboard' }] : []),
    { icon: '📅', label: 'My Bookings', to: '/bookings' },
  ];

  return (
    <div className="page">
      {/* Top Nav */}
      <div className="topnav">
        <div className="topnav-logo">Zentro<span>PK</span></div>
        <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 600 }}>Account</span>
      </div>

      <div style={{ padding: '28px 20px 0' }}>
        {/* Profile card */}
        <div className="card fade-up" style={{ marginBottom: 24, display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{
            width: 60, height: 60, borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 24, color: '#fff',
            flexShrink: 0, boxShadow: 'var(--shadow-brand)'
          }}>
            {profile?.full_name?.[0]?.toUpperCase() || '?'}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, marginBottom: 2 }}>
              {profile?.full_name}
            </div>
            <div style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 6, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {user.email}
            </div>
            <span className={`badge ${profile?.role === 'barber' ? 'badge-brand' : 'badge-success'}`}>
              {profile?.role}
            </span>
          </div>
        </div>

        {/* Menu */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16 }} className="fade-up">
          {menuItems.map(item => (
            <button key={item.to} className="btn btn-secondary"
              onClick={() => navigate(item.to)}
              style={{ justifyContent: 'flex-start', gap: 12 }}>
              <span>{item.icon}</span> {item.label}
              <span style={{ marginLeft: 'auto', color: 'var(--text-3)' }}>›</span>
            </button>
          ))}
        </div>

        <button className="btn btn-danger fade-up" onClick={handleSignOut} style={{ animationDelay: '0.12s' }}>
          Sign Out
        </button>
      </div>
    </div>
  );
}
