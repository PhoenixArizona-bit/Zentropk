import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export default function Explore() {
  const navigate = useNavigate();
  const [shops, setShops]     = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from('shops').select('id, name, city, address, images, subscription_tier, rating')
      .eq('is_active', true)
      .then(({ data }) => { setShops(data || []); setLoading(false); });
  }, []);

  return (
    <div className="page">
      <div className="topnav">
        <div className="topnav-logo">Zentro<span>PK</span></div>
        <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 600 }}>Explore</span>
      </div>

      <div style={{ padding: '24px 20px 0' }}>
        <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 20 }}>All active barber shops</p>

        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: 80, borderRadius: 'var(--radius)' }} />)}
          </div>
        ) : shops.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🗺️</div>
            <div className="empty-title">No shops yet</div>
            <div className="empty-sub">Check back soon</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {shops.map((s, i) => (
              <div key={s.id} className="card card-sm fade-up"
                style={{ display: 'flex', gap: 14, alignItems: 'center', cursor: 'pointer', animationDelay: `${i * 0.04}s` }}
                onClick={() => navigate(`/shop/${s.id}`)}>
                <div style={{
                  width: 54, height: 54, borderRadius: 14, flexShrink: 0,
                  background: 'var(--bg-input)', overflow: 'hidden',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22
                }}>
                  {s.images?.[0]
                    ? <img src={s.images[0]} alt={s.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    : '✂️'}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.name}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-2)', display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span>📍 {s.city}</span>
                    {s.rating && <span>⭐ {s.rating.toFixed(1)}</span>}
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6, flexShrink: 0 }}>
                  {s.subscription_tier && s.subscription_tier !== 'basic' && (
                    <span className="badge badge-brand">{s.subscription_tier}</span>
                  )}
                  <span style={{ color: 'var(--text-3)', fontSize: 18 }}>›</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
