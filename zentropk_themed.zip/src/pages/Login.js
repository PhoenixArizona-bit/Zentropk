import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useToast } from '../hooks/useToast';

export default function Login() {
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();
  const [email, setEmail] = useState('');
  const [pass, setPass]   = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!email || !pass) return showToast('error', 'Fill in all fields');
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password: pass });
    setLoading(false);
    if (error) return showToast('error', error.message);
    navigate('/');
  };

  return (
    <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '40px 24px', maxWidth: 480, margin: '0 auto' }}>
      {ToastEl}

      {/* Logo */}
      <div style={{ marginBottom: 44 }} className="fade-up">
        <div style={{
          width: 52, height: 52, borderRadius: 16,
          background: 'var(--brand)', marginBottom: 24,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 26, boxShadow: 'var(--shadow-brand)'
        }}>✂️</div>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 34, marginBottom: 8, letterSpacing: -0.5 }}>
          Zentro<span style={{ color: 'var(--brand)' }}>PK</span>
        </div>
        <p style={{ color: 'var(--text-2)', fontSize: 15 }}>Sign in to your account</p>
      </div>

      <div className="fade-up" style={{ animationDelay: '0.08s' }}>
        <div className="input-group">
          <label className="input-label">Email</label>
          <input className="input" type="email" placeholder="you@email.com"
            value={email} onChange={e => setEmail(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && submit()} />
        </div>

        <div className="input-group">
          <label className="input-label">Password</label>
          <input className="input" type="password" placeholder="••••••••"
            value={pass} onChange={e => setPass(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && submit()} />
        </div>

        <button className="btn btn-primary" onClick={submit} disabled={loading} style={{ marginTop: 8 }}>
          {loading ? <span className="spinner spinner-sm" /> : 'Sign In →'}
        </button>

        <p style={{ textAlign: 'center', marginTop: 28, color: 'var(--text-2)', fontSize: 14 }}>
          No account?{' '}
          <Link to="/register" style={{ color: 'var(--brand)', fontWeight: 700 }}>Register</Link>
        </p>
      </div>
    </div>
  );
}
