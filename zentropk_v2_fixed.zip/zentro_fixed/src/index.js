import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { warmupDb } from './lib/supabase';

// Warm DB after first paint — doesn't block render, reduces cold-start on first query.
// Using requestIdleCallback so it yields to paint first; falls back to setTimeout.
if (typeof requestIdleCallback !== 'undefined') {
  requestIdleCallback(warmupDb);
} else {
  setTimeout(warmupDb, 100);
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(e) {
    const msg = e?.message || '';
    if (msg.includes('is not defined') || msg.includes('access_denied') || msg.includes('accessDenied')) {
      try {
        if (!sessionStorage.getItem('_zentro_err_reload')) {
          sessionStorage.setItem('_zentro_err_reload', '1');
          localStorage.clear();
          sessionStorage.clear();
          if (window.location.hash) window.history.replaceState(null, '', window.location.pathname);
          window.location.reload();
          return { error: null };
        }
      } catch (_) {}
    }
    return { error: e };
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{ padding: 32, fontFamily: 'sans-serif', color: '#c0392b' }}>
          <h2>App failed to load</h2>
          <pre style={{ background: '#fdecea', padding: 16, borderRadius: 8, whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: 13 }}>
            {this.state.error.message}
          </pre>
          <button
            onClick={() => { localStorage.clear(); sessionStorage.clear(); window.location.href = '/'; }}
            style={{ marginTop: 16, padding: '10px 20px', background: '#c0392b', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 14 }}
          >Clear storage &amp; reload</button>
        </div>
      );
    }
    return this.props.children;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
