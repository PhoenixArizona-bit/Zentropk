import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import Navbar from './components/Navbar';
import ErrorBoundary from './components/ErrorBoundary';
import './styles/global.css';

// ── Regular app chunks ────────────────────────────────────────────────────────
const Home            = lazy(() => import('./pages/Home'));
const Shops           = lazy(() => import('./pages/Shops'));
const ShopDetail      = lazy(() => import('./pages/ShopDetail'));
const Account         = lazy(() => import('./pages/Account'));
const Login           = lazy(() => import('./pages/Login'));
const Register        = lazy(() => import('./pages/Register'));
const MyBookings      = lazy(() => import('./pages/MyBookings'));
const BarberDashboard = lazy(() => import('./pages/BarberDashboard'));
const BarberSetup     = lazy(() => import('./pages/BarberSetup'));
const BarberSlots     = lazy(() => import('./pages/BarberSlots'));
const BarberPayment   = lazy(() => import('./pages/BarberPayment'));

// ── Admin chunk — only loaded when browser hits /admin ───────────────────────
const AdminShops = lazy(() => import('./pages/AdminShops'));

// ── Spinner ───────────────────────────────────────────────────────────────────
const Spinner = () => (
  <div className="loading-screen">
    <div className="loading-logo">✂ Zentro</div>
    <div className="spinner" />
    <p className="loading-tagline">Pakistan's Barber Booking Platform</p>
  </div>
);

// ── User role guard ───────────────────────────────────────────────────────────
function ProtectedRoute({ children, allowedRoles }) {
  const { user, profile, authReady } = useAuth();

  // Always wait for auth to settle
  if (!authReady) return <Spinner />;

  // Not logged in → send to account page
  if (!user) return <Navigate to="/account" replace />;

  // Logged in but profile not loaded yet → wait (prevents role-based redirect flash)
  if (!profile || !profile.role) return <Spinner />;

  // Wrong role → redirect to shops
  if (allowedRoles && !allowedRoles.includes(profile.role))
    return <Navigate to="/shops" replace />;

  return children;
}

function AppRoutes() {
  return (
    <div id="app-shell">
      <Suspense fallback={<Spinner />}>
        <Routes>
          <Route path="/"                 element={<Home />} />
          <Route path="/shops"            element={<Shops />} />
          <Route path="/shops/:id"        element={<ShopDetail />} />
          <Route path="/account"          element={<Account />} />
          <Route path="/login"            element={<Login />} />
          <Route path="/register"         element={<Register />} />

          <Route path="/bookings" element={
            <ProtectedRoute allowedRoles={['customer']}><MyBookings /></ProtectedRoute>
          } />
          <Route path="/barber/dashboard" element={
            <ProtectedRoute allowedRoles={['barber']}><BarberDashboard /></ProtectedRoute>
          } />
          <Route path="/barber/setup" element={
            <ProtectedRoute allowedRoles={['barber']}><BarberSetup /></ProtectedRoute>
          } />
          <Route path="/barber/slots" element={
            <ProtectedRoute allowedRoles={['barber']}><BarberSlots /></ProtectedRoute>
          } />
          <Route path="/barber/payment" element={
            <ProtectedRoute allowedRoles={['barber']}><BarberPayment /></ProtectedRoute>
          } />

          {/*
           * /admin — loads AdminShops (visually identical to Shops).
           * AdminShops is the ONLY file that references AdminPortal.
           * Normal /shops users load Shops.js which has zero admin code.
           * Portal appears only after the secret keyword is typed + Enter.
           * No separate login URL. URL stays /admin throughout.
           */}
          <Route path="/admin" element={<AdminShops />} />

          <Route path="*" element={<Navigate to="/shops" replace />} />
        </Routes>
      </Suspense>

      <NavbarConditional />
    </div>
  );
}

// Hide Navbar on /admin so it looks like a clean app entry point
function NavbarConditional() {
  const { pathname } = useLocation();
  if (pathname === '/admin') return null;
  return <Navbar />;
}

export default function App() {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </ErrorBoundary>
    </BrowserRouter>
  );
}
