import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const brandIcon = new L.DivIcon({
  className: '',
  html: `<div style="
    width:36px;height:36px;border-radius:50% 50% 50% 0;
    background:#FF3D00;transform:rotate(-45deg);
    border:3px solid #fff;box-shadow:0 2px 8px rgba(255,61,0,0.5);
    display:flex;align-items:center;justify-content:center;
  "><span style="transform:rotate(45deg);font-size:14px;line-height:1">✂</span></div>`,
  iconSize: [36, 36],
  iconAnchor: [18, 36],
  popupAnchor: [0, -38],
});

function LocateButton() {
  const map = useMap();
  return (
    <button onClick={() => map.locate({ setView: true, maxZoom: 14 })} style={{
      position: 'absolute', bottom: 16, right: 16, zIndex: 800,
      width: 44, height: 44, borderRadius: 14,
      background: 'var(--bg-card)', border: '1px solid var(--border)',
      boxShadow: 'var(--shadow)', fontSize: 20, cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>📍</button>
  );
}

export default function ShopsMap({ shops, center, avgRating, onShopClick }) {
  return (
    <div style={{ padding: '0 16px 0', height: 420 }} className="fade-up">
      <div style={{ height: '100%', width: '100%', borderRadius: 20, overflow: 'hidden', position: 'relative' }}>
        <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }} zoomControl={false}>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org">OSM</a>'
            url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
            maxZoom={19}
          />
          <LocateButton />
          {shops.map(shop =>
            shop.lat && shop.lng ? (
              <Marker key={shop.id} position={[shop.lat, shop.lng]} icon={brandIcon}>
                <Popup>
                  <div style={{ padding: 4, minWidth: 160 }}>
                    <div style={{ fontFamily: 'Outfit', fontWeight: 700, fontSize: 15, marginBottom: 4 }}>{shop.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: 8 }}>📍 {shop.city}</div>
                    {avgRating(shop.reviews) && <div style={{ fontSize: 12, marginBottom: 8 }}>⭐ {avgRating(shop.reviews)}</div>}
                    <button
                      onClick={() => onShopClick(shop.id)}
                      style={{ background: '#FF3D00', color: '#fff', border: 'none', borderRadius: 10, padding: '8px 16px', fontSize: 13, fontWeight: 700, cursor: 'pointer', width: '100%' }}
                    >Book Now →</button>
                  </div>
                </Popup>
              </Marker>
            ) : null
          )}
        </MapContainer>
      </div>
      {shops.length === 0 && (
        <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-3)' }}>No shops found nearby</div>
      )}
    </div>
  );
}
