import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const MapIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/>
    <line x1="9" y1="3" x2="9" y2="18"/>
    <line x1="15" y1="6" x2="15" y2="21"/>
  </svg>
);

const PersonIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
    <circle cx="12" cy="7" r="4"/>
  </svg>
);

const DashIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
    <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
  </svg>
);

const ShieldIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
  </svg>
);

export default function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, profile } = useAuth();

  const isAdmin = profile?.role === 'admin';
  const isBarber = profile?.role === 'barber';

  const getDashPath = () => '/account';

  // Admin always goes to /account (portal opens inline there)
  const tabs = [
    { path: '/shops', label: 'Explore', Icon: MapIcon },
    isAdmin
      ? { path: '/account', label: 'Admin', Icon: ShieldIcon }
      : { path: user ? getDashPath() : '/account', label: user ? 'My Space' : 'Account', Icon: user ? DashIcon : PersonIcon },
  ];

  const isActive = (path) => {
    if (path === '/shops') {
      return location.pathname === '/shops' || location.pathname.startsWith('/shops/');
    }
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  return (
    <nav className="bottom-nav">
      {tabs.map(({ path, label, Icon }) => (
        <button
          key={path + label}
          className={`nav-btn ${isActive(path) ? 'active' : ''}`}
          onClick={() => navigate(path)}
        >
          <Icon />
          {label}
        </button>
      ))}
    </nav>
  );
}
