import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error('Zentro ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: '100vh', display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          padding: '0 32px', background: 'var(--bg)',
        }}>
          <div style={{ fontSize: 56, marginBottom: 16 }}>⚠️</div>
          <h2 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, marginBottom: 8, textAlign: 'center' }}>
            Something went wrong
          </h2>
          <p style={{ color: 'var(--text-2)', fontSize: 14, textAlign: 'center', marginBottom: 28 }}>
            The app ran into an unexpected error. Your data is safe.
          </p>
          <button
            onClick={() => { this.setState({ hasError: false, error: null }); window.location.href = '/'; }}
            style={{
              padding: '14px 28px', borderRadius: 16, border: 'none',
              background: 'var(--brand)', color: '#fff',
              fontWeight: 700, fontSize: 15, cursor: 'pointer',
              fontFamily: 'Plus Jakarta Sans, sans-serif',
            }}
          >
            Go back to home
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
