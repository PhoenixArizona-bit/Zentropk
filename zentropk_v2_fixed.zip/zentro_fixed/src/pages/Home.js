import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// Home just redirects to shops (the map is the home experience)
export default function Home() {
  const navigate = useNavigate();
  useEffect(() => { navigate('/shops', { replace: true }); }, [navigate]);
  return null;
}
