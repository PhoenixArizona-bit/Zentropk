import React, { useState } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { signUp } from '../lib/supabase';

export default function Register() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [role, setRole] = useState(searchParams.get('role') || 'customer');
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', password: '', confirm: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault(); setError('');
    if (form.password !== form.confirm) { setError('Passwords do not match'); return; }
    if (form.password.length < 6) { setError('Password must be at least 6 characters'); return; }
    setLoading(true);
    const { error: err } = await signUp(form.email, form.password, role, form.fullName, form.phone);
    setLoading(false);
    if (err) { setError(err.message); return; }
    if (role === 'barber') navigate('/barber/setup');
    else navigate('/shops');
  };

  return (
    <div className="page fade-up" style={{ padding: '0 20px' }}>
      <div style={{ padding: '20px 0 8px' }}>
        <button onClick={() => navigate(-1)} style={{ background: 'none', border: 'none', color: 'var(--text-2)', fontSize: 24, cursor: 'pointer' }}>←</button>
      </div>

      <div style={{ padding: '16px 0 24px' }}>
        <h1 style={{ fontSize: 28, marginBottom: 8 }}>Create Account</h1>
        <p style={{ color: 'var(--text-2)', fontSize: 15 }}>Join Pakistan's barber booking platform</p>
      </div>

      {/* Role selector */}
      <div style={{
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 24,
      }}>
        {[
          { val: 'customer', icon: '👤', label: 'Customer', desc: 'Book barbers' },
          { val: 'barber', icon: '💈', label: 'Barber', desc: 'List your shop' },
        ].map(({ val, icon, label, desc }) => (
          <button
            key={val}
            type="button"
            onClick={() => setRole(val)}
            style={{
              padding: '16px 12px', borderRadius: 16, border: '2px solid',
              borderColor: role === val ? 'var(--brand)' : 'var(--border)',
              background: role === val ? 'var(--brand-glow)' : 'var(--bg-card)',
              cursor: 'pointer', textAlign: 'center', transition: 'all 0.2s',
            }}
          >
            <div style={{ fontSize: 28, marginBottom: 6 }}>{icon}</div>
            <div style={{ fontFamily: 'Outfit', fontWeight: 800, fontSize: 15, color: role === val ? 'var(--brand)' : 'var(--text)', marginBottom: 2 }}>{label}</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{desc}</div>
          </button>
        ))}
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Full Name</label>
          <input name="fullName" value={form.fullName} onChange={handleChange} placeholder="Your name" required />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="you@email.com" required />
        </div>
        <div className="form-group">
          <label>Phone</label>
          <input name="phone" value={form.phone} onChange={handleChange} placeholder="03xx-xxxxxxx" required />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div className="form-group">
            <label>Password</label>
            <input name="password" type="password" value={form.password} onChange={handleChange} placeholder="••••••••" required />
          </div>
          <div className="form-group">
            <label>Confirm</label>
            <input name="confirm" type="password" value={form.confirm} onChange={handleChange} placeholder="••••••••" required />
          </div>
        </div>
        <button type="submit" className="btn-primary" style={{ marginTop: 8 }} disabled={loading}>
          {loading ? 'Creating account...' : `Create ${role === 'barber' ? 'Barber' : 'Customer'} Account`}
        </button>
      </form>

      <p style={{ textAlign: 'center', marginTop: 24, color: 'var(--text-2)', fontSize: 14 }}>
        Already have an account? <Link to="/login" style={{ color: 'var(--brand)', fontWeight: 700 }}>Sign in</Link>
      </p>
    </div>
  );
}
