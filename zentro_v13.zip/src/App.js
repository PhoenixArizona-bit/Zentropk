import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { warmupDb } from './lib/supabase';
import './styles/global.css';

import BottomNav      from './components/BottomNav';
import Home           from './pages/Home';
import Explore        from './pages/Explore';
import ShopDetail     from './pages/ShopDetail';
import Login          from './pages/Login';
import Register       from './pages/Register';
import Account        from './pages/Account';
import AdminPortal    from './pages/AdminPortal';
import BarberDashboard from './pages/BarberDashboard';
import BarberSetup    from './pages/BarberSetup';
import BarberSlots    from './pages/BarberSlots';
import BarberPayment  from './pages/BarberPayment';

// Warm up Supabase connection immediately on app load
warmupDb();

function BarberRoute({ children }) {
  const { user, profile, authReady } = useAuth();
  if (!authReady) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) return <Navigate to="/login" replace />;
  if (profile && profile.role !== 'barber') return <Navigate to="/" replace />;
  return children;
}

function AppRoutes() {
  return (
    <>
      <Routes>
        <Route path="/"          element={<Home />} />
        <Route path="/explore"   element={<Explore />} />
        <Route path="/shop/:id"  element={<ShopDetail />} />
        <Route path="/login"     element={<Login />} />
        <Route path="/register"  element={<Register />} />
        <Route path="/account"   element={<Account />} />
        <Route path="/admin"     element={<AdminPortal />} />
        <Route path="/barber/dashboard" element={<BarberRoute><BarberDashboard /></BarberRoute>} />
        <Route path="/barber/setup"     element={<BarberRoute><BarberSetup /></BarberRoute>} />
        <Route path="/barber/slots"     element={<BarberRoute><BarberSlots /></BarberRoute>} />
        <Route path="/barber/payment"   element={<BarberRoute><BarberPayment /></BarberRoute>} />
        {/* Redirect old /bookings to /account */}
        <Route path="/bookings"  element={<Navigate to="/account" replace />} />
        <Route path="*"          element={<Navigate to="/" replace />} />
      </Routes>
      <BottomNav />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
