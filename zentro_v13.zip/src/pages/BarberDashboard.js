import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { usePlanPerks } from '../hooks/usePlanPerks';
import { Scissors, Clock, Calendar, BarChart } from '../lib/icons';
import { format } from 'date-fns';

const PLAN_ICONS = { basic: '🪒', pro: '⚡', premium: '👑' };

export default function BarberDashboard() {
  const { user, profile, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [shop, setShop]         = useState(null);
  const [bookings, setBookings] = useState([]);
  const [stats, setStats]       = useState({ today: 0, total: 0, earnings: 0 });
  const [loading, setLoading]   = useState(true);
  const [tab, setTab]           = useState('today'); // today | upcoming | past | all

  const { plansConfig, loading: plansLoading } = usePlanPerks(shop?.subscription_tier);

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    if (profile && profile.role !== 'barber') { navigate('/'); return; }
    if (user) fetchData();
  }, [user, profile, authReady]); // eslint-disable-line

  const fetchData = async () => {
    const { data: shopData } = await supabase
      .from('shops')
      .select('*')
      .eq('owner_id', user.id)
      .maybeSingle();

    setShop(shopData);

    if (!shopData) { setLoading(false); return; }

    const { data: bData } = await supabase
      .from('bookings')
      .select('*, profiles(full_name), services(name, price), time_slots(slot_date, start_time)')
      .eq('shop_id', shopData.id)
      .order('created_at', { ascending: false });

    const bs = bData || [];
    setBookings(bs);

    const today = format(new Date(), 'yyyy-MM-dd');
    const todayCount = bs.filter(b => b.time_slots?.slot_date === today && b.status !== 'cancelled').length;
    const completed  = bs.filter(b => b.status === 'completed').length;

    setStats({ today: todayCount, total: bs.length, completed });
    setLoading(false);
  };

  const updateStatus = async (bookingId, status, slotId) => {
    await supabase.from('bookings').update({ status }).eq('id', bookingId);
    if (status === 'cancelled') {
      await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
    }
    showToast('success', `Booking ${status}`);
    fetchData();
  };

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  if (!shop) return (
    <div className="page">
      <div className="empty-state" style={{ minHeight: '80dvh' }}>
        <div className="empty-icon"><Scissors size={36} color="var(--text-3)" /></div>
        <div className="empty-title">No shop set up yet</div>
        <div className="empty-sub">Set up your shop to start receiving bookings</div>
        <button className="btn btn-primary btn-sm" onClick={() => navigate('/barber/setup')} style={{ marginTop: 16 }}>
          Set Up My Shop
        </button>
      </div>
    </div>
  );

  const today      = format(new Date(), 'yyyy-MM-dd');
  const todayBs    = bookings.filter(b => b.time_slots?.slot_date === today);
  const upcomingBs = bookings.filter(b => b.time_slots?.slot_date > today && b.status !== 'cancelled');
  const pastBs     = bookings.filter(b => b.time_slots?.slot_date < today);

  const tabBookings = tab === 'today' ? todayBs : tab === 'upcoming' ? upcomingBs : tab === 'past' ? pastBs : bookings;

  const currentPlan = shop.subscription_tier || 'basic';

  return (
    <div className="page">
      {ToastEl}
      <div style={{ padding: '24px 20px 0' }}>

        {/* Header */}
        <div style={{ marginBottom: 24 }}>
          <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 2 }}>Welcome back</p>
          <h1 style={{ fontSize: 24, marginBottom: 4 }}>{shop.name}</h1>
          {!shop.is_active && (
            <span className="badge badge-warning">⏳ Pending Approval</span>
          )}
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 28 }}>
          {[
            { label: "Today's", value: stats.today,     icon: <Calendar size={18} color="var(--brand)" /> },
            { label: 'Total',   value: stats.total,     icon: <BarChart size={18} color="var(--brand)" /> },
            { label: 'Done',    value: stats.completed, icon: '✅' },
          ].map(s => (
            <div key={s.label} className="card" style={{ textAlign: 'center', padding: '16px 10px' }}>
              <div style={{ fontSize: 22, marginBottom: 4 }}>{s.icon}</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: 'var(--brand)' }}>{s.value}</div>
              <div style={{ fontSize: 11, color: 'var(--text-2)', fontWeight: 600, textTransform: 'uppercase' }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 28 }}>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate('/barber/slots')} style={{ width: '100%', padding: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}><Clock size={15} /> Manage Slots</button>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate('/barber/setup')} style={{ width: '100%', padding: '13px' }}>⚙️ Shop Setup</button>
        </div>

        {/* ── Plan Cards ─────────────────────────────────────────── */}
        {!plansLoading && (
          <div style={{ marginBottom: 28 }}>
            <p className="section-label">Subscription Plans</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {['basic', 'pro', 'premium'].map(tier => {
                const p       = plansConfig[tier];
                const active  = currentPlan === tier;
                return (
                  <div key={tier} className="card" style={{
                    border: active ? '2px solid var(--brand)' : '2px solid var(--border)',
                    position: 'relative',
                    padding: '16px 18px',
                  }}>
                    {active && (
                      <span style={{
                        position: 'absolute', top: 12, right: 14,
                        background: 'var(--brand)', color: '#fff',
                        fontSize: 10, fontWeight: 700, borderRadius: 6,
                        padding: '2px 8px', letterSpacing: 0.5,
                      }}>YOUR PLAN</span>
                    )}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                      <span style={{ fontSize: 22 }}>{PLAN_ICONS[tier]}</span>
                      <div>
                        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16 }}>{p.name}</div>
                        <div style={{ fontSize: 13, color: 'var(--brand)', fontWeight: 700 }}>Rs {p.price?.toLocaleString()} / mo</div>
                      </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                      {[
                        { label: 'Photos',   value: `${p.photos} uploads` },
                        { label: 'QR Code',  value: p.qr       ? '✅ Included' : '❌ Not included' },
                        { label: 'Badge',    value: p.badge    ? '✅ Included' : '❌ Not included' },
                        { label: 'Priority', value: p.priority ? '✅ Included' : '❌ Not included' },
                      ].map(f => (
                        <div key={f.label} style={{
                          background: 'var(--bg-input)', borderRadius: 8,
                          padding: '8px 10px',
                        }}>
                          <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 2 }}>{f.label}</div>
                          <div style={{ fontSize: 12, fontWeight: 600 }}>{f.value}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── Bookings Tabs ───────────────────────────────────────── */}
        <div style={{ marginBottom: 24 }}>
          <p className="section-label">Bookings</p>

          {/* Tab pills */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 16, overflowX: 'auto', paddingBottom: 4 }}>
            {[
              { key: 'today',    label: `Today (${todayBs.length})` },
              { key: 'upcoming', label: `Upcoming (${upcomingBs.length})` },
              { key: 'past',     label: `Past (${pastBs.length})` },
              { key: 'all',      label: `All (${bookings.length})` },
            ].map(t => (
              <button key={t.key} onClick={() => setTab(t.key)} style={{
                flexShrink: 0,
                padding: '7px 14px',
                borderRadius: 20,
                border: 'none',
                cursor: 'pointer',
                fontSize: 12,
                fontWeight: 700,
                fontFamily: 'var(--font-display)',
                background: tab === t.key ? 'var(--brand)' : 'var(--bg-input)',
                color:      tab === t.key ? '#fff'         : 'var(--text-2)',
                transition: 'all 0.15s',
              }}>{t.label}</button>
            ))}
          </div>

          {tabBookings.length === 0 ? (
            <div className="empty-state" style={{ padding: '24px 0' }}>
              <div className="empty-sub">No bookings here</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {tabBookings.map(b => (
                <BookingRow key={b.id} booking={b} onUpdate={updateStatus} />
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}

function BookingRow({ booking: b, onUpdate }) {
  const statusColor = { pending: 'var(--warning)', confirmed: 'var(--success)', cancelled: 'var(--text-3)', completed: 'var(--brand)' };

  return (
    <div className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{b.profiles?.full_name || 'Customer'}</div>
        <span style={{ fontSize: 12, fontWeight: 700, color: statusColor[b.status], fontFamily: 'var(--font-display)' }}>
          {b.status?.toUpperCase()}
        </span>
      </div>
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 5 }}><Scissors size={12} color="var(--text-3)" /> {b.services?.name} — Rs {b.services?.price}</p>
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 5 }}><Clock size={12} color="var(--text-3)" /> {b.time_slots?.start_time?.slice(0, 5)}</p>
      <p style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 12 }}>📅 {b.time_slots?.slot_date || '—'}</p>
      {b.status === 'pending' && (
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }}
            onClick={() => onUpdate(b.id, 'confirmed', b.time_slot_id)}>Confirm</button>
          <button className="btn btn-danger btn-sm" style={{ flex: 1 }}
            onClick={() => onUpdate(b.id, 'cancelled', b.time_slot_id)}>Cancel</button>
        </div>
      )}
      {b.status === 'confirmed' && (
        <button className="btn btn-primary btn-sm"
          onClick={() => onUpdate(b.id, 'completed', b.time_slot_id)}>Mark Complete</button>
      )}
    </div>
  );
}
