import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export default function Explore() {
  const navigate = useNavigate();
  const [shops, setShops]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from('shops').select('id, name, city, address, lat, lng, images, subscription_tier')
      .eq('is_active', true)
      .then(({ data }) => { setShops(data || []); setLoading(false); });
  }, []);

  return (
    <div className="page">
      <div style={{ padding: '20px 20px 0' }}>
        <h1 style={{ fontSize: 26, marginBottom: 6 }}>Explore</h1>
        <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 24 }}>All active barber shops</p>

        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: 80 }} />)}
          </div>
        ) : shops.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🗺️</div>
            <div className="empty-title">No shops yet</div>
            <div className="empty-sub">Check back soon</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {shops.map(s => (
              <div key={s.id} className="card card-sm"
                onClick={() => navigate(`/shop/${s.id}`)}
                style={{ display: 'flex', gap: 14, alignItems: 'center', cursor: 'pointer' }}>
                <div style={{
                  width: 56, height: 56, borderRadius: 12, flexShrink: 0,
                  background: 'var(--bg-input)', overflow: 'hidden',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24
                }}>
                  {s.images?.[0]
                    ? <img src={s.images[0]} alt={s.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    : '✂️'
                  }
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 2 }}>{s.name}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-2)' }}>📍 {s.city}</div>
                </div>
                {s.subscription_tier && s.subscription_tier !== 'basic' && (
                  <span className="badge badge-brand">{s.subscription_tier}</span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
