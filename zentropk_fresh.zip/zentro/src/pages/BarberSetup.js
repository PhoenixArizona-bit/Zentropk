import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function BarberSetup() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [shopId, setShopId]     = useState(null);
  const [loading, setLoading]   = useState(true);
  const [saving, setSaving]     = useState(false);
  const [services, setServices] = useState([]);
  const [newSrv, setNewSrv]     = useState({ name: '', price: '', duration_minutes: 30 });

  const [form, setForm] = useState({
    name: '', city: '', address: '', description: '', phone: '',
    images: [],
  });

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    loadExisting();
  }, [user, authReady]); // eslint-disable-line

  const loadExisting = async () => {
    const { data: s } = await supabase
      .from('shops')
      .select('*')
      .eq('owner_id', user.id)
      .maybeSingle();

    if (s) {
      setShopId(s.id);
      setForm({
        name: s.name || '', city: s.city || '',
        address: s.address || '', description: s.description || '',
        phone: s.phone || '', images: s.images || [],
      });

      const { data: srv } = await supabase.from('services').select('*').eq('shop_id', s.id);
      setServices(srv || []);
    }
    setLoading(false);
  };

  const save = async () => {
    if (!form.name || !form.city || !form.address) return showToast('error', 'Name, city and address are required');
    setSaving(true);

    const payload = { ...form, owner_id: user.id, is_active: false, subscription_status: 'pending', subscription_tier: 'basic' };

    if (shopId) {
      const { error } = await supabase.from('shops').update(payload).eq('id', shopId);
      if (error) { setSaving(false); return showToast('error', error.message); }
      showToast('success', 'Shop updated!');
    } else {
      const { data, error } = await supabase.from('shops').insert(payload).select().maybeSingle();
      if (error) { setSaving(false); return showToast('error', error.message); }
      if (data) setShopId(data.id);
      showToast('success', 'Shop created! Awaiting admin approval.');
    }
    setSaving(false);
  };

  const addService = async () => {
    if (!shopId) return showToast('error', 'Save shop details first');
    if (!newSrv.name || !newSrv.price) return showToast('error', 'Name and price required');

    const { data, error } = await supabase.from('services')
      .insert({ ...newSrv, shop_id: shopId, price: parseFloat(newSrv.price), is_active: true })
      .select().maybeSingle();

    if (error) return showToast('error', error.message);
    if (data) setServices(prev => [...prev, data]);
    setNewSrv({ name: '', price: '', duration_minutes: 30 });
    showToast('success', 'Service added');
  };

  const removeService = async (id) => {
    await supabase.from('services').delete().eq('id', id);
    setServices(prev => prev.filter(s => s.id !== id));
    showToast('success', 'Service removed');
  };

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  return (
    <div className="page">
      {ToastEl}
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
        <span className="page-title">Shop Setup</span>
      </div>

      <div style={{ padding: '20px 20px 0' }}>
        {/* Basic Info */}
        <div className="card" style={{ marginBottom: 20 }}>
          <p className="section-label" style={{ marginBottom: 16 }}>Basic Info</p>

          {[
            { label: 'Shop Name *', key: 'name', placeholder: 'e.g. Cuts & Glory' },
            { label: 'City *', key: 'city', placeholder: 'e.g. Lahore' },
            { label: 'Address *', key: 'address', placeholder: 'Full address' },
            { label: 'Phone', key: 'phone', placeholder: '+92 300 0000000' },
          ].map(f => (
            <div key={f.key} className="input-group">
              <label className="input-label">{f.label}</label>
              <input className="input" placeholder={f.placeholder}
                value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} />
            </div>
          ))}

          <div className="input-group">
            <label className="input-label">Description</label>
            <textarea className="input" placeholder="Tell customers about your shop..."
              value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
          </div>

          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? <span className="spinner spinner-sm" /> : shopId ? 'Update Shop' : 'Create Shop'}
          </button>
        </div>

        {/* Services */}
        <div className="card" style={{ marginBottom: 20 }}>
          <p className="section-label" style={{ marginBottom: 16 }}>Services</p>

          {services.map(s => (
            <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div>
                <div style={{ fontWeight: 600, fontFamily: 'var(--font-display)', fontSize: 14 }}>{s.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text-2)' }}>Rs {s.price} · {s.duration_minutes} min</div>
              </div>
              <button className="btn btn-danger btn-sm" onClick={() => removeService(s.id)}>Remove</button>
            </div>
          ))}

          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ display: 'flex', gap: 10 }}>
              <input className="input" placeholder="Service name" style={{ flex: 2 }}
                value={newSrv.name} onChange={e => setNewSrv(p => ({ ...p, name: e.target.value }))} />
              <input className="input" placeholder="Price" type="number" style={{ flex: 1 }}
                value={newSrv.price} onChange={e => setNewSrv(p => ({ ...p, price: e.target.value }))} />
            </div>
            <select className="input" value={newSrv.duration_minutes}
              onChange={e => setNewSrv(p => ({ ...p, duration_minutes: parseInt(e.target.value) }))}>
              {[15, 20, 30, 45, 60, 90].map(d => <option key={d} value={d}>{d} minutes</option>)}
            </select>
            <button className="btn btn-secondary" onClick={addService}>+ Add Service</button>
          </div>
        </div>
      </div>
    </div>
  );
}
