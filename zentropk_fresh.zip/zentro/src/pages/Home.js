import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

export default function Home() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [shops, setShops]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');

  useEffect(() => {
    fetchShops();
  }, []);

  const fetchShops = async () => {
    const { data } = await supabase
      .from('shops')
      .select('id, name, city, address, images, rating, subscription_tier')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(20);
    setShops(data || []);
    setLoading(false);
  };

  const filtered = shops.filter(s =>
    s.name?.toLowerCase().includes(search.toLowerCase()) ||
    s.city?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page">
      {/* Header */}
      <div style={{ padding: '20px 20px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 28 }}>
            Zentro<span style={{ color: 'var(--brand)' }}>PK</span>
          </div>
          {!user ? (
            <Link to="/login" className="btn btn-primary btn-sm">Sign In</Link>
          ) : (
            <Link to="/account">
              <div style={{
                width: 38, height: 38, borderRadius: '50%',
                background: 'var(--brand-dim)', border: '2px solid var(--brand)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--brand)', fontSize: 15
              }}>
                {profile?.full_name?.[0]?.toUpperCase() || '?'}
              </div>
            </Link>
          )}
        </div>
        <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 20 }}>
          {profile?.role === 'barber' ? (
            <span>Barber account — <Link to="/barber/dashboard" style={{ color: 'var(--brand)' }}>Go to Dashboard</Link></span>
          ) : 'Book your next cut'}
        </p>

        {/* Search */}
        <input
          className="input"
          placeholder="🔍 Search shops or city..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ marginBottom: 24 }}
        />
      </div>

      {/* Shops */}
      <div style={{ padding: '0 20px' }}>
        <p className="section-label">
          {search ? `Results for "${search}"` : 'Nearby Shops'}
        </p>

        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[1,2,3].map(i => (
              <div key={i} className="skeleton" style={{ height: 220, borderRadius: 'var(--radius)' }} />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">✂️</div>
            <div className="empty-title">No shops found</div>
            <div className="empty-sub">Try a different search or check back later</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {filtered.map(shop => (
              <ShopCard key={shop.id} shop={shop} onClick={() => navigate(`/shop/${shop.id}`)} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ShopCard({ shop, onClick }) {
  const img = shop.images?.[0];
  return (
    <div className="shop-card" onClick={onClick} style={{ cursor: 'pointer' }}>
      {img ? (
        <img src={img} alt={shop.name} className="shop-card-img" />
      ) : (
        <div className="shop-card-img" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 48 }}>✂️</div>
      )}
      <div className="shop-card-body">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
          <div className="shop-card-name">{shop.name}</div>
          {shop.subscription_tier && shop.subscription_tier !== 'basic' && (
            <span className="badge badge-brand">{shop.subscription_tier}</span>
          )}
        </div>
        <div className="shop-card-meta">
          <span>📍 {shop.city || shop.address}</span>
          {shop.rating && <span>⭐ {shop.rating.toFixed(1)}</span>}
        </div>
      </div>
    </div>
  );
}
