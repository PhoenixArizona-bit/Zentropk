import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export default function Account() {
  const { user, profile, signOut, authReady } = useAuth();
  const navigate = useNavigate();

  if (!authReady) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) { navigate('/login'); return null; }

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <div className="page">
      <div style={{ padding: '30px 20px 0' }}>
        <h1 style={{ fontSize: 26, marginBottom: 24 }}>Account</h1>

        {/* Avatar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 32 }}>
          <div style={{
            width: 64, height: 64, borderRadius: '50%',
            background: 'var(--brand-dim)', border: '2px solid var(--brand)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 26, color: 'var(--brand)'
          }}>
            {profile?.full_name?.[0]?.toUpperCase() || '?'}
          </div>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 20 }}>{profile?.full_name}</div>
            <div style={{ color: 'var(--text-2)', fontSize: 13 }}>{user.email}</div>
            <span className={`badge ${profile?.role === 'barber' ? 'badge-brand' : 'badge-success'}`} style={{ marginTop: 6 }}>
              {profile?.role}
            </span>
          </div>
        </div>

        {/* Links */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {profile?.role === 'barber' && (
            <button className="btn btn-secondary" onClick={() => navigate('/barber/dashboard')}>
              📊 Barber Dashboard
            </button>
          )}
          <button className="btn btn-secondary" onClick={() => navigate('/bookings')}>
            📅 My Bookings
          </button>
          <button className="btn btn-danger" onClick={handleSignOut}>
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
