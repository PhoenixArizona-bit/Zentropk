import { useState, useEffect } from 'react';
import { supabase, sha256 } from '../lib/supabase';

// ── Pattern Lock ─────────────────────────────────────────────────────────────
function PatternLock({ onDone, label = 'Draw Pattern' }) {
  const [pattern, setPattern] = useState([]);
  const [drawing, setDrawing] = useState(false);

  const start = (i) => { setPattern([i]); setDrawing(true); };
  const enter = (i) => { if (!drawing || pattern.includes(i)) return; setPattern(p => [...p, i]); };
  const end   = () => { if (!drawing) return; setDrawing(false); if (pattern.length >= 4) onDone(pattern); setPattern([]); };

  return (
    <div style={{ userSelect: 'none' }}>
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 12, textAlign: 'center' }}>{label}</p>
      <div onMouseLeave={end} onTouchEnd={end}
        style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 60px)', gap: 16, margin: '0 auto', width: 'fit-content' }}>
        {[0,1,2,3,4,5,6,7,8].map(i => (
          <div key={i} data-node={i}
            onMouseDown={() => start(i)} onMouseEnter={() => enter(i)} onMouseUp={end}
            onTouchStart={() => start(i)}
            onTouchMove={e => {
              const t = e.touches[0];
              const el = document.elementFromPoint(t.clientX, t.clientY);
              if (el?.dataset?.node !== undefined) enter(Number(el.dataset.node));
            }}
            style={{
              width: 60, height: 60, borderRadius: '50%', cursor: 'pointer',
              background: pattern.includes(i) ? 'var(--brand-dim)' : 'var(--bg-input)',
              border: `2px solid ${pattern.includes(i) ? 'var(--brand)' : 'var(--border)'}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'all 0.15s',
            }}>
            {pattern.includes(i) && <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'var(--brand)' }} />}
          </div>
        ))}
      </div>
      {pattern.length > 0 && pattern.length < 4 && !drawing && (
        <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--error)', marginTop: 10 }}>Need at least 4 nodes</p>
      )}
    </div>
  );
}

// ── Login Screen ─────────────────────────────────────────────────────────────
function AdminLogin({ onAuthed }) {
  const [step, setStep]     = useState('password'); // 'password' | 'pattern'
  const [pass, setPass]     = useState('');
  const [error, setError]   = useState('');
  const [loading, setLoading] = useState(false);

  const checkPass = async () => {
    setLoading(true); setError('');
    const { data } = await supabase.from('app_settings').select('value').eq('key', 'admin_password_hash').maybeSingle();
    const hash = await sha256(pass);
    if (!data || data.value !== hash) { setError('Wrong password'); setLoading(false); return; }
    setStep('pattern');
    setLoading(false);
  };

  const checkPattern = async (drawn) => {
    const { data } = await supabase.from('app_settings').select('value').eq('key', 'admin_pattern_hash').maybeSingle();
    const hash = await sha256(drawn.join('-'));
    if (!data || data.value !== hash) { setError('Wrong pattern'); return; }
    onAuthed();
  };

  return (
    <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '40px 24px' }}>
      <div style={{ textAlign: 'center', marginBottom: 40 }}>
        <div style={{ fontSize: 40, marginBottom: 8 }}>🛡️</div>
        <h1 style={{ fontSize: 28 }}>Admin Portal</h1>
        <p style={{ color: 'var(--text-2)', fontSize: 14 }}>ZentroPK</p>
      </div>

      {step === 'password' ? (
        <div>
          <div className="input-group">
            <label className="input-label">Admin Password</label>
            <input className="input" type="password" placeholder="••••••••"
              value={pass} onChange={e => setPass(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && checkPass()} />
          </div>
          {error && <p style={{ color: 'var(--error)', fontSize: 13, marginBottom: 12 }}>{error}</p>}
          <button className="btn btn-primary" onClick={checkPass} disabled={loading}>
            {loading ? <span className="spinner spinner-sm" /> : 'Continue →'}
          </button>
        </div>
      ) : (
        <div>
          <PatternLock onDone={checkPattern} label="Draw your admin pattern" />
          {error && <p style={{ color: 'var(--error)', fontSize: 13, textAlign: 'center', marginTop: 12 }}>{error}</p>}
          <button className="btn btn-ghost" onClick={() => setStep('password')} style={{ marginTop: 20 }}>
            ← Back
          </button>
        </div>
      )}
    </div>
  );
}

// ── Main Portal ──────────────────────────────────────────────────────────────
export default function AdminPortal() {
  const [authed, setAuthed]   = useState(false);
  const [tab, setTab]         = useState('shops');
  const [shops, setShops]     = useState([]);
  const [payments, setPayments] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [users, setUsers]     = useState([]);
  const [settings, setSettings] = useState({
    jazzcash_number: '', easypaisa_number: '', jazzcash_name: '', easypaisa_name: '',
    admin_search_keyword: 'zentro@admin',
  });
  const [fetched, setFetched] = useState(false);
  const [toast, setToast]     = useState(null);

  const showToast = (type, text) => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    if (authed && !fetched) { fetchAll(); setFetched(true); }
  }, [authed]); // eslint-disable-line

  const fetchAll = async () => {
    const [{ data: sh }, { data: pa }, { data: bo }, { data: us }, { data: cfg }] = await Promise.all([
      supabase.from('shops').select('*, profiles(full_name, email)').order('created_at', { ascending: false }),
      supabase.from('payment_submissions').select('*, shops(name)').order('submitted_at', { ascending: false }),
      supabase.from('bookings').select('*, profiles(full_name), shops(name), services(name), time_slots(slot_date, start_time)').order('created_at', { ascending: false }).limit(100),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('app_settings').select('key, value'),
    ]);
    setShops(sh || []);
    setPayments(pa || []);
    setBookings(bo || []);
    setUsers(us || []);

    const map = {};
    (cfg || []).forEach(r => { map[r.key] = r.value; });
    setSettings(prev => ({ ...prev, ...map }));
  };

  const approveShop = async (id, active) => {
    await supabase.from('shops').update({ is_active: active, subscription_status: active ? 'active' : 'pending' }).eq('id', id);
    fetchAll(); showToast('success', active ? 'Shop approved' : 'Shop deactivated');
  };

  const reviewPayment = async (id, status, shopId) => {
    await supabase.from('payment_submissions').update({ status, reviewed_at: new Date().toISOString() }).eq('id', id);
    if (status === 'approved') {
      await supabase.from('shops').update({ subscription_status: 'active', is_active: true }).eq('id', shopId);
    }
    fetchAll(); showToast('success', `Payment ${status}`);
  };

  const saveSettings = async () => {
    const rows = Object.entries(settings).map(([key, value]) => ({ key, value: String(value) }));
    await supabase.from('app_settings').upsert(rows, { onConflict: 'key' });
    showToast('success', 'Settings saved');
  };

  if (!authed) return <AdminLogin onAuthed={() => setAuthed(true)} />;

  const TABS = [
    { key: 'shops', label: '🏪 Shops' },
    { key: 'payments', label: '💳 Payments' },
    { key: 'bookings', label: '📅 Bookings' },
    { key: 'users', label: '👥 Users' },
    { key: 'settings', label: '⚙️ Settings' },
  ];

  return (
    <div style={{ minHeight: '100dvh', paddingBottom: 40 }}>
      {toast && <div className={`toast toast-${toast.type}`}>{toast.text}</div>}

      {/* Header */}
      <div style={{ padding: '24px 20px 0', marginBottom: 20 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h1 style={{ fontSize: 26 }}>🛡️ Admin</h1>
          <button className="btn btn-ghost btn-sm" onClick={() => setAuthed(false)}>Lock</button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '0 20px', marginBottom: 24, paddingBottom: 4 }}>
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            style={{
              flexShrink: 0, padding: '8px 16px', borderRadius: 20,
              border: `1.5px solid ${tab === t.key ? 'var(--brand)' : 'var(--border)'}`,
              background: tab === t.key ? 'var(--brand-dim)' : 'var(--bg-input)',
              color: tab === t.key ? 'var(--brand)' : 'var(--text-2)',
              fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, cursor: 'pointer',
            }}>
            {t.label}
          </button>
        ))}
      </div>

      <div style={{ padding: '0 20px' }}>
        {/* SHOPS */}
        {tab === 'shops' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{shops.length} total shops</p>
            {shops.map(s => (
              <div key={s.id} className="card" style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>{s.name}</div>
                  <span className={`badge ${s.is_active ? 'badge-success' : 'badge-warning'}`}>
                    {s.is_active ? 'Active' : 'Pending'}
                  </span>
                </div>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4 }}>📍 {s.city}, {s.address}</p>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 12 }}>👤 {s.profiles?.full_name} · {s.subscription_tier}</p>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button className="btn btn-primary btn-sm" style={{ flex: 1 }}
                    onClick={() => approveShop(s.id, !s.is_active)}>
                    {s.is_active ? 'Deactivate' : 'Approve'}
                  </button>
                </div>
              </div>
            ))}
            {shops.length === 0 && <div className="empty-state"><div className="empty-icon">🏪</div><div className="empty-sub">No shops yet</div></div>}
          </div>
        )}

        {/* PAYMENTS */}
        {tab === 'payments' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{payments.length} submissions</p>
            {payments.map(p => (
              <div key={p.id} className="card" style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{p.shops?.name}</span>
                  <span className={`badge ${p.status === 'approved' ? 'badge-success' : p.status === 'rejected' ? 'badge-error' : 'badge-warning'}`}>
                    {p.status}
                  </span>
                </div>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4 }}>Rs {p.amount} · {p.payment_method}</p>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4 }}>TXN: {p.txn_id}</p>
                {p.screenshot_url && (
                  <a href={p.screenshot_url} target="_blank" rel="noreferrer"
                    style={{ fontSize: 13, color: 'var(--brand)', display: 'block', marginBottom: 8 }}>View Screenshot ↗</a>
                )}
                {p.status === 'pending' && (
                  <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                    <button className="btn btn-primary btn-sm" style={{ flex: 1 }}
                      onClick={() => reviewPayment(p.id, 'approved', p.shop_id)}>Approve</button>
                    <button className="btn btn-danger btn-sm" style={{ flex: 1 }}
                      onClick={() => reviewPayment(p.id, 'rejected', p.shop_id)}>Reject</button>
                  </div>
                )}
              </div>
            ))}
            {payments.length === 0 && <div className="empty-state"><div className="empty-icon">💳</div><div className="empty-sub">No payments yet</div></div>}
          </div>
        )}

        {/* BOOKINGS */}
        {tab === 'bookings' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{bookings.length} bookings</p>
            {bookings.map(b => (
              <div key={b.id} className="card card-sm" style={{ marginBottom: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>{b.shops?.name}</span>
                  <span style={{ fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)',
                    color: b.status === 'completed' ? 'var(--success)' : b.status === 'cancelled' ? 'var(--text-3)' : 'var(--warning)' }}>
                    {b.status?.toUpperCase()}
                  </span>
                </div>
                <p style={{ fontSize: 12, color: 'var(--text-2)' }}>👤 {b.profiles?.full_name} · ✂️ {b.services?.name}</p>
                <p style={{ fontSize: 12, color: 'var(--text-2)' }}>📅 {b.time_slots?.slot_date} {b.time_slots?.start_time?.slice(0,5)}</p>
              </div>
            ))}
            {bookings.length === 0 && <div className="empty-state"><div className="empty-icon">📅</div><div className="empty-sub">No bookings yet</div></div>}
          </div>
        )}

        {/* USERS */}
        {tab === 'users' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{users.length} users</p>
            {users.map(u => (
              <div key={u.id} className="card card-sm" style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>{u.full_name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-2)' }}>{u.email}</div>
                </div>
                <span className={`badge ${u.role === 'barber' ? 'badge-brand' : 'badge-success'}`}>{u.role}</span>
              </div>
            ))}
            {users.length === 0 && <div className="empty-state"><div className="empty-icon">👥</div><div className="empty-sub">No users yet</div></div>}
          </div>
        )}

        {/* SETTINGS */}
        {tab === 'settings' && (
          <div>
            {[
              { label: 'JazzCash Number', key: 'jazzcash_number' },
              { label: 'JazzCash Account Name', key: 'jazzcash_name' },
              { label: 'Easypaisa Number', key: 'easypaisa_number' },
              { label: 'Easypaisa Account Name', key: 'easypaisa_name' },
              { label: 'Admin Secret Keyword', key: 'admin_search_keyword' },
            ].map(f => (
              <div key={f.key} className="input-group">
                <label className="input-label">{f.label}</label>
                <input className="input" value={settings[f.key] || ''}
                  onChange={e => setSettings(p => ({ ...p, [f.key]: e.target.value }))} />
              </div>
            ))}
            <button className="btn btn-primary" onClick={saveSettings}>Save Settings</button>
          </div>
        )}
      </div>
    </div>
  );
}
