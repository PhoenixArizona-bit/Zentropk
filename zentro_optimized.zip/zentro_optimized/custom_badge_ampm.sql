-- ============================================
-- ZENTRO: Custom Badge + AM/PM (no schema changes needed for time)
-- Run in Supabase SQL Editor
-- ============================================

-- Add custom_badge column to shops
alter table shops
  add column if not exists custom_badge text default null,
  add column if not exists custom_badge_color text default null;

-- Examples of badge colors admin can use:
-- '#FF3D00' = red (Pro)
-- '#FFB800' = gold (Premium)  
-- '#00C864' = green
-- '#7C3AED' = purple
-- '#0EA5E9' = blue
