# 🛡️ Zentro Admin Portal — Setup Guide

Your admin portal lives at `/admin` and has **two layers of security**:
1. **Database role** — Supabase RLS checks `role = 'admin'` on every query
2. **Email lock** — the frontend also checks your exact email address in code

Both must pass. Anyone else gets an "Access Denied" screen.

---

## Step 1 — Put your email in the code

Open `src/pages/AdminPortal.js` and find line 8:

```js
const ADMIN_EMAIL = 'YOUR_EMAIL@example.com';
```

Replace it with your real email address and save.

---

## Step 2 — Run the SQL in Supabase

1. Go to [supabase.com](https://supabase.com) → your project → **SQL Editor**
2. Open `admin_setup.sql` (included in this project)
3. Replace both occurrences of `YOUR_EMAIL@example.com` with your email
4. Replace `YOUR_STRONG_PASSWORD_HERE` with a strong password
5. Run the entire file

> **Tip:** Use Option B (Dashboard) to create the user if you prefer a UI:
> Supabase → Authentication → Users → **Add user**
> Then run only the `UPDATE profiles` block at the bottom.

---

## Step 3 — Verify

Run this query in the SQL Editor to confirm it worked:

```sql
select p.id, p.role, p.full_name, u.email
from profiles p
join auth.users u on u.id = p.id
where p.role = 'admin';
```

You should see one row with your email.

---

## Step 4 — Log in

1. Go to your app → `/login`
2. Sign in with your admin email and password
3. Navigate to `/admin` — you should see the full Admin Portal

---

## Security summary

| Layer | What it does |
|---|---|
| Supabase RLS | Blocks DB queries unless `role = 'admin'` in your profiles row |
| Role escalation lock | Users cannot change their own role via the API |
| Email allowlist | Frontend refuses access unless logged-in email matches `ADMIN_EMAIL` |
| ProtectedRoute | React router blocks `/admin` for any non-admin role before the page even loads |

---

## Resetting your password

Supabase → Authentication → Users → find your email → **Send password reset**

Or trigger it in-app from the Login page if you add a "Forgot password" flow.
