# Zentro — Security & Production Setup

## Before Going Live — Checklist

### 1. Set Admin Credentials in Supabase (CRITICAL)
The app has **no hardcoded passwords**. You must set them in Supabase.

**Step 1** — Generate your SHA-256 hashes:
Open browser DevTools (F12) → Console, paste this:

```js
// Replace 'YourPassword123' with your actual password
crypto.subtle.digest('SHA-256', new TextEncoder().encode('YourPassword123'))
  .then(b => console.log('HASH:', Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')))
```

Do the same for your pattern (nodes joined by dashes, e.g. `1-5-9-3`):
```js
crypto.subtle.digest('SHA-256', new TextEncoder().encode('1-5-9-3'))
  .then(b => console.log('HASH:', Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')))
```

**Step 2** — Run in Supabase SQL Editor:
```sql
insert into app_settings (key, value) values
  ('admin_password_hash', 'YOUR_PASSWORD_HASH_HERE'),
  ('admin_pattern_hash',  'YOUR_PATTERN_HASH_HERE')
on conflict (key) do update set value = excluded.value;
```

### 2. Run `production_setup.sql`
Run the entire `production_setup.sql` file in Supabase SQL Editor.
This sets up indexes, locks down storage, enables realtime, etc.

### 3. Netlify Environment Variables
In Netlify → Site Settings → Environment Variables, add:
```
REACT_APP_SUPABASE_URL=https://your-project.supabase.co
REACT_APP_SUPABASE_ANON_KEY=your-anon-key
```
Never commit `.env` to git.

### 4. Supabase Storage
- `shop-images` bucket → Public ✅
- `payment-proofs` bucket → Private ✅ (production_setup.sql handles this)

---

## Security Architecture

| Layer | What it does |
|---|---|
| SHA-256 hashing | Passwords/patterns never stored in plaintext |
| No hardcoded fallback | If Supabase is down, login is blocked — no backdoor |
| Exponential backoff rate limiter | 30s → 60s → 120s → 300s lockout after failures |
| 3-factor admin login | Secret keyword + password + pattern |
| Session TTL | Admin session expires after 4 hours |
| Row Level Security | Every table has RLS — users can only see their own data |
| Atomic slot booking | DB-level row lock prevents double bookings |
| FK cascade protection | Deleting slots won't break booking history |
| Paginated admin queries | Never loads entire DB into memory |
| Error boundaries | App crashes are contained, user sees friendly message |

---

## Choosing a Strong Pattern

Good patterns (non-obvious):
- `3-5-7-1-9` (diagonal + corners)
- `2-4-6-8-5-1` (edges inward)
- `1-9-3-7-5` (corner zigzag)

Avoid:
- `1-2-3` (top row only)
- `1-5-9` (diagonal)
- `1-2-3-6-9` (L-shape — old default)
