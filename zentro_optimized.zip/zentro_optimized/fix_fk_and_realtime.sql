-- ============================================================
-- FIX 1: Add ON DELETE CASCADE to bookings.slot_id FK
-- This lets time_slots rows be deleted even if bookings exist
-- ============================================================
ALTER TABLE bookings DROP CONSTRAINT IF EXISTS bookings_slot_id_fkey;
ALTER TABLE bookings
  ADD CONSTRAINT bookings_slot_id_fkey
  FOREIGN KEY (slot_id)
  REFERENCES time_slots(id)
  ON DELETE SET NULL;  -- keeps booking history but detaches the slot

-- ============================================================
-- FIX 2: Allow barbers & admin to delete bookings (RLS policy)
-- ============================================================
DROP POLICY IF EXISTS "Barbers can delete their shop bookings" ON bookings;
CREATE POLICY "Barbers can delete their shop bookings" ON bookings
  FOR DELETE USING (
    EXISTS (SELECT 1 FROM shops WHERE id = bookings.shop_id AND owner_id = auth.uid())
  );

-- Admin already has "for all" policy, so delete is covered.

-- ============================================================
-- FIX 3: Enable realtime on profiles so UI updates instantly
-- when admin changes a user's role/data
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE profiles;
