-- ============================================================
-- ZENTRO ADMIN SETUP — Run this in Supabase SQL Editor
-- https://supabase.com → your project → SQL Editor
-- ============================================================

-- ── STEP 1: Tighten the profiles RLS so only the admin can
--            read ALL profiles (currently any logged-in user
--            can read only their own — this is fine, but
--            the admin needs full read access too).
-- ────────────────────────────────────────────────────────────

-- Allow admin to read all profiles
create policy if not exists "Admin can read all profiles"
  on profiles for select
  using (
    exists (
      select 1 from profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- ── STEP 2: Lock role self-escalation — users cannot change
--            their own role (they could currently via the
--            "update own profile" policy).
-- ────────────────────────────────────────────────────────────

-- Drop the overly broad update policy
drop policy if exists "Users can update own profile" on profiles;

-- Re-create it but exclude role changes
create policy "Users can update own profile (no role change)"
  on profiles for update
  using (auth.uid() = id)
  with check (
    auth.uid() = id
    -- role must stay the same as what's already in the DB
    and role = (select role from profiles where id = auth.uid())
  );

-- Only admins can change roles
create policy if not exists "Admin can update any profile"
  on profiles for all
  using (
    exists (
      select 1 from profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- ── STEP 3: Create YOUR admin account
--
--   Replace the values below, then run this block.
--   After this runs, log into the app with that email
--   and you'll have full admin access.
-- ────────────────────────────────────────────────────────────

-- First, create the auth user (run in Supabase Auth → Add user,
-- OR use this SQL — pick one method):

-- Option A — SQL method (run in SQL Editor):
select auth.create_user(
  '{
    "email": "YOUR_EMAIL@example.com",
    "password": "YOUR_STRONG_PASSWORD_HERE",
    "email_confirm": true,
    "user_metadata": {
      "role": "admin",
      "full_name": "Admin"
    }
  }'::jsonb
);

-- Option B — Dashboard method (easier, no SQL needed):
--   Supabase → Authentication → Users → Add user
--   Then run only the UPDATE below to set the role.

-- ── STEP 4: Ensure the profile row has role = 'admin'
--            (run this after the user exists)
-- ────────────────────────────────────────────────────────────
update profiles
  set role = 'admin'
  where id = (
    select id from auth.users
    where email = 'YOUR_EMAIL@example.com'
    limit 1
  );

-- Verify it worked:
select p.id, p.role, p.full_name, u.email
from profiles p
join auth.users u on u.id = p.id
where p.role = 'admin';
