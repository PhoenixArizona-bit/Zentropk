-- ============================================================
-- ZENTRO — MASTER SQL (All changes from setup to latest)
-- Run this ONCE in Supabase SQL Editor on a fresh project
-- If already have a DB, scroll to the MIGRATIONS section below
-- ============================================================

-- ── EXTENSIONS ──────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── PROFILES ────────────────────────────────────────────────
create table if not exists profiles (
  id uuid references auth.users on delete cascade primary key,
  role text not null check (role in ('customer', 'barber', 'admin')),
  full_name text,
  phone text,
  avatar_url text,
  created_at timestamptz default now()
);

create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, role, full_name, phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'role', 'customer'),
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'phone'
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- ── SHOPS ───────────────────────────────────────────────────
create table if not exists shops (
  id uuid default uuid_generate_v4() primary key,
  owner_id uuid references profiles(id) on delete cascade,
  name text not null,
  description text,
  address text not null,
  city text not null,
  lat double precision,
  lng double precision,
  phone text,
  images text[] default '{}',
  is_active boolean default false,
  subscription_status text default 'pending' check (subscription_status in ('pending', 'active', 'expired', 'suspended')),
  subscription_tier text default 'basic' check (subscription_tier in ('basic', 'pro', 'premium')),
  subscription_expires_at timestamptz,
  custom_badge text default null,
  custom_badge_color text default null,
  created_at timestamptz default now()
);

-- ── SERVICES ────────────────────────────────────────────────
create table if not exists services (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  name text not null,
  description text,
  price decimal(10,2) not null,
  duration_minutes int not null default 30,
  is_active boolean default true
);

-- ── OPENING HOURS ────────────────────────────────────────────
create table if not exists opening_hours (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  day_of_week int not null check (day_of_week between 0 and 6),
  open_time time,
  close_time time,
  is_closed boolean default false,
  unique (shop_id, day_of_week)
);

-- ── TIME SLOTS ───────────────────────────────────────────────
create table if not exists time_slots (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  slot_date date not null,
  start_time time not null,
  end_time time not null,
  is_available boolean default true,
  created_at timestamptz default now(),
  unique (shop_id, slot_date, start_time)
);

-- ── BOOKINGS ─────────────────────────────────────────────────
create table if not exists bookings (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  customer_id uuid references profiles(id) on delete cascade,
  service_id uuid references services(id),
  slot_id uuid references time_slots(id),
  status text default 'pending' check (status in ('pending', 'confirmed', 'cancelled', 'completed')),
  notes text,
  created_at timestamptz default now()
);

create or replace function mark_slot_booked()
returns trigger as $$
begin
  update time_slots set is_available = false where id = new.slot_id;
  return new;
end;
$$ language plpgsql;

drop trigger if exists on_booking_created on bookings;
create trigger on_booking_created
  after insert on bookings
  for each row execute procedure mark_slot_booked();

-- ── REVIEWS ──────────────────────────────────────────────────
create table if not exists reviews (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  customer_id uuid references profiles(id) on delete cascade,
  booking_id uuid references bookings(id),
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz default now(),
  unique (booking_id)
);

-- ── PAYMENT SUBMISSIONS ───────────────────────────────────────
create table if not exists payment_submissions (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  barber_id uuid references profiles(id) on delete cascade,
  amount decimal(10,2) not null,
  payment_method text not null check (payment_method in ('jazzcash', 'easypaisa')),
  transaction_id text,
  screenshot_url text,
  status text default 'pending' check (status in ('pending', 'approved', 'rejected')),
  admin_note text,
  subscription_tier text default 'basic',
  submitted_at timestamptz default now(),
  reviewed_at timestamptz
);

-- ── NOTIFICATIONS ─────────────────────────────────────────────
create table if not exists notifications (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  owner_id uuid references profiles(id) on delete cascade,
  type text not null check (type in ('expiry_warning', 'expired', 'payment_approved', 'payment_rejected')),
  title text not null,
  message text not null,
  is_read boolean default false,
  created_at timestamptz default now()
);

-- ── APP SETTINGS ──────────────────────────────────────────────
create table if not exists app_settings (
  key   text primary key,
  value text not null
);

-- ── ROW LEVEL SECURITY ────────────────────────────────────────
alter table profiles           enable row level security;
alter table shops              enable row level security;
alter table services           enable row level security;
alter table opening_hours      enable row level security;
alter table time_slots         enable row level security;
alter table bookings           enable row level security;
alter table reviews            enable row level security;
alter table payment_submissions enable row level security;
alter table notifications      enable row level security;
alter table app_settings       enable row level security;

-- Profiles
drop policy if exists "Users can read own profile" on profiles;
drop policy if exists "Users can update own profile" on profiles;
create policy "Users can read own profile"   on profiles for select using (auth.uid() = id);
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);

-- Shops
drop policy if exists "Anyone can view active shops" on shops;
drop policy if exists "Barbers can view own shop"    on shops;
drop policy if exists "Barbers can manage own shop"  on shops;
drop policy if exists "Admin can manage all shops"   on shops;
create policy "Anyone can view active shops" on shops for select using (is_active = true);
create policy "Barbers can view own shop"    on shops for select using (auth.uid() = owner_id);
create policy "Barbers can manage own shop"  on shops for all    using (auth.uid() = owner_id);
create policy "Admin can manage all shops"   on shops for all    using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

-- Services
drop policy if exists "Anyone can view services"       on services;
drop policy if exists "Shop owners can manage services" on services;
create policy "Anyone can view services"        on services for select using (true);
create policy "Shop owners can manage services" on services for all using (
  exists (select 1 from shops where id = services.shop_id and owner_id = auth.uid())
);

-- Opening hours
drop policy if exists "Anyone can view opening hours" on opening_hours;
drop policy if exists "Shop owners can manage hours"  on opening_hours;
create policy "Anyone can view opening hours" on opening_hours for select using (true);
create policy "Shop owners can manage hours"  on opening_hours for all using (
  exists (select 1 from shops where id = opening_hours.shop_id and owner_id = auth.uid())
);

-- Time slots
drop policy if exists "Anyone can view available slots" on time_slots;
drop policy if exists "Shop owners can manage slots"    on time_slots;
create policy "Anyone can view available slots" on time_slots for select using (true);
create policy "Shop owners can manage slots"    on time_slots for all using (
  exists (select 1 from shops where id = time_slots.shop_id and owner_id = auth.uid())
);

-- Bookings
drop policy if exists "Customers see own bookings"       on bookings;
drop policy if exists "Barbers see their shop bookings"  on bookings;
drop policy if exists "Customers can create bookings"    on bookings;
drop policy if exists "Admin can manage all bookings"    on bookings;
create policy "Customers see own bookings"      on bookings for select using (auth.uid() = customer_id);
create policy "Barbers see their shop bookings" on bookings for select using (
  exists (select 1 from shops where id = bookings.shop_id and owner_id = auth.uid())
);
create policy "Customers can create bookings"   on bookings for insert with check (auth.uid() = customer_id);
create policy "Admin can manage all bookings"   on bookings for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);
create policy "Barbers can update bookings"     on bookings for update using (
  exists (select 1 from shops where id = bookings.shop_id and owner_id = auth.uid())
);

-- Reviews
drop policy if exists "Anyone can read reviews"     on reviews;
drop policy if exists "Customers can write reviews" on reviews;
create policy "Anyone can read reviews"     on reviews for select using (true);
create policy "Customers can write reviews" on reviews for insert with check (auth.uid() = customer_id);

-- Payments
drop policy if exists "Barbers see own payments"    on payment_submissions;
drop policy if exists "Barbers can submit payments" on payment_submissions;
drop policy if exists "Admin manages all payments"  on payment_submissions;
create policy "Barbers see own payments"    on payment_submissions for select using (auth.uid() = barber_id);
create policy "Barbers can submit payments" on payment_submissions for insert with check (auth.uid() = barber_id);
create policy "Admin manages all payments"  on payment_submissions for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

-- Notifications
drop policy if exists "Owners can read own notifications"   on notifications;
drop policy if exists "Owners can update own notifications" on notifications;
drop policy if exists "Admin can manage all notifications"  on notifications;
drop policy if exists "Service role can insert notifications" on notifications;
create policy "Owners can read own notifications"   on notifications for select using (auth.uid() = owner_id);
create policy "Owners can update own notifications" on notifications for update using (auth.uid() = owner_id);
create policy "Admin can manage all notifications"  on notifications for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);
create policy "Service role can insert notifications" on notifications for insert with check (true);

-- App settings
drop policy if exists "Public can read app_settings"    on app_settings;
drop policy if exists "Admin can manage app_settings"   on app_settings;
create policy "Public can read app_settings"  on app_settings for select using (true);
create policy "Admin can manage app_settings" on app_settings for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

-- ── STORAGE BUCKETS ───────────────────────────────────────────
insert into storage.buckets (id, name, public) values ('shop-images',    'shop-images',    true)  on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('payment-proofs', 'payment-proofs', false) on conflict (id) do nothing;

drop policy if exists "Public can view shop images"      on storage.objects;
drop policy if exists "Barbers can upload shop images"   on storage.objects;
drop policy if exists "Barbers can delete own shop images" on storage.objects;
drop policy if exists "Users can upload payment proofs"  on storage.objects;
drop policy if exists "Users can view own payment proofs" on storage.objects;
drop policy if exists "Admins can view all payment proofs" on storage.objects;

create policy "Public can view shop images"
  on storage.objects for select using (bucket_id = 'shop-images');
create policy "Barbers can upload shop images"
  on storage.objects for insert with check (bucket_id = 'shop-images' and auth.role() = 'authenticated');
create policy "Barbers can delete own shop images"
  on storage.objects for delete using (bucket_id = 'shop-images' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "Users can upload payment proofs"
  on storage.objects for insert with check (bucket_id = 'payment-proofs' and auth.role() = 'authenticated');
create policy "Users can view own payment proofs"
  on storage.objects for select using (bucket_id = 'payment-proofs' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "Admins can view all payment proofs"
  on storage.objects for select using (
    bucket_id = 'payment-proofs' and
    exists (select 1 from profiles where id = auth.uid() and role = 'admin')
  );

-- ── AUTO-EXPIRY FUNCTION ──────────────────────────────────────
create or replace function expire_subscriptions()
returns void as $$
begin
  update shops
  set subscription_status = 'expired', is_active = false
  where subscription_status = 'active'
    and subscription_expires_at < now();
end;
$$ language plpgsql security definer;

-- ── EXPIRY NOTIFICATION FUNCTION ─────────────────────────────
create or replace function send_expiry_notifications()
returns void as $$
declare
  shop_record record;
  days_left int;
begin
  for shop_record in
    select s.id as shop_id, s.owner_id, s.name, s.subscription_expires_at
    from shops s
    where s.subscription_status = 'active'
      and s.subscription_expires_at between now() and now() + interval '7 days'
  loop
    days_left := extract(day from (shop_record.subscription_expires_at - now()))::int;
    if not exists (
      select 1 from notifications
      where shop_id = shop_record.shop_id
        and type = 'expiry_warning'
        and created_at > now() - interval '24 hours'
    ) then
      insert into notifications (shop_id, owner_id, type, title, message)
      values (
        shop_record.shop_id, shop_record.owner_id, 'expiry_warning',
        '⚠️ Subscription Expiring Soon',
        case
          when days_left <= 1 then 'Your subscription for ' || shop_record.name || ' expires TOMORROW! Renew now.'
          else 'Your subscription for ' || shop_record.name || ' expires in ' || days_left || ' days. Renew before it expires.'
        end
      );
    end if;
  end loop;

  for shop_record in
    select s.id as shop_id, s.owner_id, s.name
    from shops s
    where s.subscription_status = 'expired'
      and not exists (
        select 1 from notifications
        where shop_id = s.id and type = 'expired'
          and created_at > now() - interval '24 hours'
      )
  loop
    insert into notifications (shop_id, owner_id, type, title, message)
    values (
      shop_record.shop_id, shop_record.owner_id, 'expired',
      '🔴 Subscription Expired',
      'Your subscription for ' || shop_record.name || ' has expired. Your shop is now hidden from customers. Renew now.'
    );
  end loop;
end;
$$ language plpgsql security definer;

-- ── DEFAULT SETTINGS SEED ─────────────────────────────────────
insert into app_settings (key, value) values
  ('admin_password_1',     'zentro@2025'),
  ('admin_password_2',     'admin#secure'),
  ('admin_search_keyword', 'zentro@admin'),
  ('jazzcash_number',      ''),
  ('easypaisa_number',     ''),
  ('tier_basic_name',      'Basic'),
  ('tier_basic_price',     '500'),
  ('tier_basic_desc',      'Listed on explore, up to 5 services, 3 photos'),
  ('tier_pro_name',        'Pro'),
  ('tier_pro_price',       '1000'),
  ('tier_pro_desc',        'Everything in Basic + 15 services, 10 photos, priority listing'),
  ('tier_premium_name',    'Premium'),
  ('tier_premium_price',   '2000'),
  ('tier_premium_desc',    'Everything in Pro + unlimited services & photos, featured badge')
on conflict (key) do nothing;

-- ============================================================
-- MIGRATIONS ONLY (if you already have a database running)
-- Run only the lines below if schema already exists
-- ============================================================

-- Add subscription_tier to shops (if missing)
alter table shops add column if not exists subscription_tier text default 'basic' check (subscription_tier in ('basic', 'pro', 'premium'));

-- Add subscription_tier to payment_submissions (if missing)
alter table payment_submissions add column if not exists subscription_tier text default 'basic';

-- Add custom badge columns (if missing)
alter table shops add column if not exists custom_badge       text default null;
alter table shops add column if not exists custom_badge_color text default null;

-- Add notifications table (if missing)
create table if not exists notifications (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  owner_id uuid references profiles(id) on delete cascade,
  type text not null check (type in ('expiry_warning', 'expired', 'payment_approved', 'payment_rejected')),
  title text not null,
  message text not null,
  is_read boolean default false,
  created_at timestamptz default now()
);
alter table notifications enable row level security;
create policy "Owners can read own notifications"     on notifications for select using (auth.uid() = owner_id);
create policy "Owners can update own notifications"   on notifications for update using (auth.uid() = owner_id);
create policy "Admin can manage all notifications"    on notifications for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);
create policy "Service role can insert notifications" on notifications for insert with check (true);

-- Add barber booking update policy (if missing)
do $$ begin
  if not exists (
    select 1 from pg_policies where tablename = 'bookings' and policyname = 'Barbers can update bookings'
  ) then
    create policy "Barbers can update bookings" on bookings for update using (
      exists (select 1 from shops where id = bookings.shop_id and owner_id = auth.uid())
    );
  end if;
end $$;

-- Seed new tier settings (if missing)
insert into app_settings (key, value) values
  ('tier_basic_name',   'Basic'),
  ('tier_basic_price',  '500'),
  ('tier_basic_desc',   'Listed on explore, up to 5 services, 3 photos'),
  ('tier_pro_name',     'Pro'),
  ('tier_pro_price',    '1000'),
  ('tier_pro_desc',     'Everything in Basic + 15 services, 10 photos, priority listing'),
  ('tier_premium_name', 'Premium'),
  ('tier_premium_price','2000'),
  ('tier_premium_desc', 'Everything in Pro + unlimited services & photos, featured badge')
on conflict (key) do nothing;
