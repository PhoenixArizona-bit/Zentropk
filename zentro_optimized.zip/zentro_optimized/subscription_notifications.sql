-- ============================================
-- ZENTRO: Subscription Notifications & Auto-Expiry
-- Run this in Supabase SQL Editor
-- ============================================

-- ============================================
-- 1. NOTIFICATIONS TABLE
-- ============================================
create table if not exists notifications (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  owner_id uuid references profiles(id) on delete cascade,
  type text not null check (type in ('expiry_warning', 'expired', 'payment_approved', 'payment_rejected')),
  title text not null,
  message text not null,
  is_read boolean default false,
  created_at timestamptz default now()
);

alter table notifications enable row level security;

create policy "Owners can read own notifications"
  on notifications for select
  using (auth.uid() = owner_id);

create policy "Owners can update own notifications"
  on notifications for update
  using (auth.uid() = owner_id);

create policy "Admin can manage all notifications"
  on notifications for all
  using (
    exists (select 1 from profiles where id = auth.uid() and role = 'admin')
  );

-- Allow system/service role to insert notifications
create policy "Service role can insert notifications"
  on notifications for insert
  with check (true);

-- ============================================
-- 2. AUTO-EXPIRY FUNCTION
-- Marks shops as 'expired' when subscription_expires_at has passed
-- ============================================
create or replace function expire_subscriptions()
returns void as $$
begin
  -- Expire shops whose subscription has passed
  update shops
  set subscription_status = 'expired',
      is_active = false
  where subscription_status = 'active'
    and subscription_expires_at < now();
end;
$$ language plpgsql security definer;

-- ============================================
-- 3. SEND EXPIRY WARNING NOTIFICATIONS FUNCTION
-- Creates notifications for shops expiring in 1-7 days
-- Call this daily (via cron or pg_cron)
-- ============================================
create or replace function send_expiry_notifications()
returns void as $$
declare
  shop_record record;
  days_left int;
begin
  -- Loop over active shops expiring within 7 days
  for shop_record in
    select s.id as shop_id, s.owner_id, s.name, s.subscription_expires_at
    from shops s
    where s.subscription_status = 'active'
      and s.subscription_expires_at between now() and now() + interval '7 days'
  loop
    days_left := extract(day from (shop_record.subscription_expires_at - now()))::int;

    -- Only insert if we haven't sent this warning in the last 24 hours
    if not exists (
      select 1 from notifications
      where shop_id = shop_record.shop_id
        and type = 'expiry_warning'
        and created_at > now() - interval '24 hours'
    ) then
      insert into notifications (shop_id, owner_id, type, title, message)
      values (
        shop_record.shop_id,
        shop_record.owner_id,
        'expiry_warning',
        '⚠️ Subscription Expiring Soon',
        case
          when days_left <= 1 then 'Your subscription for ' || shop_record.name || ' expires TOMORROW! Renew now to keep your shop visible.'
          else 'Your subscription for ' || shop_record.name || ' expires in ' || days_left || ' days. Renew before it expires to avoid downtime.'
        end
      );
    end if;
  end loop;

  -- Also notify shops that just expired
  for shop_record in
    select s.id as shop_id, s.owner_id, s.name
    from shops s
    where s.subscription_status = 'expired'
      and not exists (
        select 1 from notifications
        where shop_id = s.id
          and type = 'expired'
          and created_at > now() - interval '24 hours'
      )
  loop
    insert into notifications (shop_id, owner_id, type, title, message)
    values (
      shop_record.shop_id,
      shop_record.owner_id,
      'expired',
      '🔴 Subscription Expired',
      'Your subscription for ' || shop_record.name || ' has expired. Your shop is now hidden from customers. Renew now to go live again.'
    );
  end loop;
end;
$$ language plpgsql security definer;

-- ============================================
-- 4. FUNCTION: Notify on payment approval/rejection
-- Call this from admin portal JS after approving/rejecting
-- ============================================
create or replace function notify_payment_reviewed(
  p_shop_id uuid,
  p_owner_id uuid,
  p_status text,  -- 'approved' or 'rejected'
  p_tier text,
  p_admin_note text default null
)
returns void as $$
begin
  if p_status = 'approved' then
    insert into notifications (shop_id, owner_id, type, title, message)
    values (
      p_shop_id, p_owner_id,
      'payment_approved',
      '✅ Payment Approved!',
      'Your ' || initcap(p_tier) || ' plan payment has been approved. Your shop is now live!'
    );
  elsif p_status = 'rejected' then
    insert into notifications (shop_id, owner_id, type, title, message)
    values (
      p_shop_id, p_owner_id,
      'payment_rejected',
      '❌ Payment Rejected',
      case
        when p_admin_note is not null and p_admin_note != ''
          then 'Your payment was rejected. Admin note: ' || p_admin_note || '. Please resubmit with correct details.'
        else 'Your payment was rejected. Please resubmit with correct transaction details.'
      end
    );
  end if;
end;
$$ language plpgsql security definer;

-- ============================================
-- 5. SCHEDULED JOBS (if pg_cron is enabled on Supabase)
-- Enable pg_cron in Supabase: Dashboard → Extensions → pg_cron
-- ============================================

-- Run auto-expiry every hour
-- select cron.schedule('expire-subscriptions', '0 * * * *', 'select expire_subscriptions()');

-- Run notification sender every day at 9am Pakistan time (4am UTC)
-- select cron.schedule('send-expiry-notifications', '0 4 * * *', 'select send_expiry_notifications()');

