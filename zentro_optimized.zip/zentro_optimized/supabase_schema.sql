-- ============================================
-- ZENTRO - Full Database Schema
-- Run this in Supabase SQL Editor
-- ============================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ============================================
-- PROFILES (barbers + customers + admin)
-- ============================================
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  role text not null check (role in ('customer', 'barber', 'admin')),
  full_name text,
  phone text,
  avatar_url text,
  created_at timestamptz default now()
);

-- Auto-create profile on signup
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, role, full_name, phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'role', 'customer'),
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'phone'
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- ============================================
-- SHOPS
-- ============================================
create table shops (
  id uuid default uuid_generate_v4() primary key,
  owner_id uuid references profiles(id) on delete cascade,
  name text not null,
  description text,
  address text not null,
  city text not null,
  lat double precision,
  lng double precision,
  phone text,
  images text[] default '{}',
  is_active boolean default false,  -- admin must approve
  subscription_status text default 'pending' check (subscription_status in ('pending', 'active', 'expired', 'suspended')),
  subscription_expires_at timestamptz,
  created_at timestamptz default now()
);

-- ============================================
-- SERVICES (each shop has its own services)
-- ============================================
create table services (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  name text not null,
  description text,
  price decimal(10,2) not null,
  duration_minutes int not null default 30,
  is_active boolean default true
);

-- ============================================
-- OPENING HOURS (per shop, per day)
-- ============================================
create table opening_hours (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  day_of_week int not null check (day_of_week between 0 and 6), -- 0=Sunday, 6=Saturday
  open_time time,
  close_time time,
  is_closed boolean default false,
  unique (shop_id, day_of_week)
);

-- ============================================
-- TIME SLOTS (specific bookable slots)
-- ============================================
create table time_slots (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  slot_date date not null,
  start_time time not null,
  end_time time not null,
  is_available boolean default true,
  created_at timestamptz default now(),
  unique (shop_id, slot_date, start_time)
);

-- ============================================
-- BOOKINGS
-- ============================================
create table bookings (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  customer_id uuid references profiles(id) on delete cascade,
  service_id uuid references services(id),
  slot_id uuid references time_slots(id),
  status text default 'pending' check (status in ('pending', 'confirmed', 'cancelled', 'completed')),
  notes text,
  created_at timestamptz default now()
);

-- Mark slot unavailable when booked
create or replace function mark_slot_booked()
returns trigger as $$
begin
  update time_slots set is_available = false where id = new.slot_id;
  return new;
end;
$$ language plpgsql;

create trigger on_booking_created
  after insert on bookings
  for each row execute procedure mark_slot_booked();

-- ============================================
-- REVIEWS
-- ============================================
create table reviews (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  customer_id uuid references profiles(id) on delete cascade,
  booking_id uuid references bookings(id),
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz default now(),
  unique (booking_id)  -- one review per booking
);

-- ============================================
-- PAYMENT SUBMISSIONS (JazzCash / EasyPaisa)
-- ============================================
create table payment_submissions (
  id uuid default uuid_generate_v4() primary key,
  shop_id uuid references shops(id) on delete cascade,
  barber_id uuid references profiles(id) on delete cascade,
  amount decimal(10,2) not null,
  payment_method text not null check (payment_method in ('jazzcash', 'easypaisa')),
  transaction_id text,
  screenshot_url text,
  status text default 'pending' check (status in ('pending', 'approved', 'rejected')),
  admin_note text,
  submitted_at timestamptz default now(),
  reviewed_at timestamptz
);

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================

alter table profiles enable row level security;
alter table shops enable row level security;
alter table services enable row level security;
alter table opening_hours enable row level security;
alter table time_slots enable row level security;
alter table bookings enable row level security;
alter table reviews enable row level security;
alter table payment_submissions enable row level security;

-- Profiles
create policy "Users can read own profile" on profiles for select using (auth.uid() = id);
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);

-- Shops - public can read active shops
create policy "Anyone can view active shops" on shops for select using (is_active = true);
create policy "Barbers can manage own shop" on shops for all using (auth.uid() = owner_id);
create policy "Admin can manage all shops" on shops for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

-- Services - public read
create policy "Anyone can view services" on services for select using (true);
create policy "Shop owners can manage services" on services for all using (
  exists (select 1 from shops where id = services.shop_id and owner_id = auth.uid())
);

-- Opening hours - public read
create policy "Anyone can view opening hours" on opening_hours for select using (true);
create policy "Shop owners can manage hours" on opening_hours for all using (
  exists (select 1 from shops where id = opening_hours.shop_id and owner_id = auth.uid())
);

-- Time slots - public read
create policy "Anyone can view available slots" on time_slots for select using (true);
create policy "Shop owners can manage slots" on time_slots for all using (
  exists (select 1 from shops where id = time_slots.shop_id and owner_id = auth.uid())
);

-- Bookings
create policy "Customers see own bookings" on bookings for select using (auth.uid() = customer_id);
create policy "Barbers see their shop bookings" on bookings for select using (
  exists (select 1 from shops where id = bookings.shop_id and owner_id = auth.uid())
);
create policy "Customers can create bookings" on bookings for insert with check (auth.uid() = customer_id);
create policy "Admin can manage all bookings" on bookings for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

-- Reviews - public read
create policy "Anyone can read reviews" on reviews for select using (true);
create policy "Customers can write reviews" on reviews for insert with check (auth.uid() = customer_id);

-- Payments
create policy "Barbers see own payments" on payment_submissions for select using (auth.uid() = barber_id);
create policy "Barbers can submit payments" on payment_submissions for insert with check (auth.uid() = barber_id);
create policy "Admin manages all payments" on payment_submissions for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

-- ============================================
-- STORAGE BUCKET (for shop images + payment screenshots)
-- ============================================
-- Run these in Supabase Dashboard → Storage:
-- 1. Create bucket called "shop-images" (public)
-- 2. Create bucket called "payment-proofs" (private)

-- ============================================
-- MIGRATION: Make lat/lng nullable
-- (Run this if schema was already applied)
-- ============================================
-- ALTER TABLE shops ALTER COLUMN lat DROP NOT NULL;
-- ALTER TABLE shops ALTER COLUMN lng DROP NOT NULL;

-- ============================================
-- app_settings table (admin passwords etc.)
-- ============================================
create table if not exists app_settings (
  key   text primary key,
  value text not null
);

-- Anyone can read (needed for unauthenticated secret login check)
alter table app_settings enable row level security;
create policy "Public can read app_settings" on app_settings for select using (true);
create policy "Admin can manage app_settings" on app_settings for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

-- Seed default passwords (change these immediately after first deploy)
insert into app_settings (key, value) values
  ('admin_password_1', 'zentro@2025'),
  ('admin_password_2', 'admin#secure'),
  ('admin_search_keyword', 'zentro@admin'),
  ('jazzcash_number', ''),
  ('easypaisa_number', '')
on conflict (key) do nothing;


-- ============================================
-- STORAGE BUCKETS & POLICIES
-- Run this in Supabase SQL editor
-- ============================================

-- Create buckets
insert into storage.buckets (id, name, public)
values ('shop-images', 'shop-images', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('payment-proofs', 'payment-proofs', false)
on conflict (id) do nothing;

-- shop-images: anyone can view, authenticated barbers can upload/delete their own
create policy "Public can view shop images"
  on storage.objects for select
  using (bucket_id = 'shop-images');

create policy "Barbers can upload shop images"
  on storage.objects for insert
  with check (
    bucket_id = 'shop-images' and
    auth.role() = 'authenticated'
  );

create policy "Barbers can delete own shop images"
  on storage.objects for delete
  using (
    bucket_id = 'shop-images' and
    auth.uid()::text = (storage.foldername(name))[1]
  );

-- payment-proofs: only uploader and admin can view, authenticated users can upload
create policy "Users can upload payment proofs"
  on storage.objects for insert
  with check (
    bucket_id = 'payment-proofs' and
    auth.role() = 'authenticated'
  );

create policy "Users can view own payment proofs"
  on storage.objects for select
  using (
    bucket_id = 'payment-proofs' and
    auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Admins can view all payment proofs"
  on storage.objects for select
  using (
    bucket_id = 'payment-proofs' and
    exists (select 1 from profiles where id = auth.uid() and role = 'admin')
  );

-- ============================================
-- FIX: Allow barbers to see their own shop
-- even when is_active = false
-- Run this in Supabase SQL editor
-- ============================================
drop policy if exists "Anyone can view active shops" on shops;

create policy "Anyone can view active shops"
  on shops for select
  using (is_active = true);

create policy "Barbers can view own shop"
  on shops for select
  using (auth.uid() = owner_id);


-- ============================================
-- TIERS: Add subscription_tier to shops and payment_submissions
-- Run in Supabase SQL editor
-- ============================================
alter table shops
  add column if not exists subscription_tier text default 'basic'
    check (subscription_tier in ('basic', 'pro', 'premium'));

alter table payment_submissions
  add column if not exists subscription_tier text default 'basic';

-- Seed default tiers in app_settings
insert into app_settings (key, value) values
  ('tier_basic_name',        'Basic'),
  ('tier_basic_price',       '500'),
  ('tier_basic_desc',        'Listed on explore, up to 5 services, 3 photos'),
  ('tier_pro_name',          'Pro'),
  ('tier_pro_price',         '1000'),
  ('tier_pro_desc',          'Everything in Basic + 15 services, 10 photos, priority listing'),
  ('tier_premium_name',      'Premium'),
  ('tier_premium_price',     '2000'),
  ('tier_premium_desc',      'Everything in Pro + unlimited services & photos, featured badge')
on conflict (key) do nothing;
