import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { signIn, supabase } from '../lib/supabase';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    const { data, error: err } = await signIn(email, password);
    setLoading(false);
    if (err) { setError(err.message); return; }
    // Fetch role from profiles table (not metadata) so admin works
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', data.user.id)
      .maybeSingle();
    const role = profile?.role;
    if (role === 'admin') navigate('/account');
    else if (role === 'barber') navigate('/barber/dashboard');
    else navigate('/shops');
  };

  return (
    <div className="page fade-up" style={{ padding: '0 20px' }}>
      <div style={{ padding: '20px 0 8px' }}>
        <button onClick={() => navigate(-1)} style={{ background: 'none', border: 'none', color: 'var(--text-2)', fontSize: 24, cursor: 'pointer' }}>←</button>
      </div>

      <div style={{ padding: '24px 0 32px' }}>
        <div style={{
          width: 60, height: 60, borderRadius: 18, background: 'var(--brand)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 28, marginBottom: 20, boxShadow: '0 8px 20px var(--brand-glow)',
        }}>✂</div>
        <h1 style={{ fontSize: 28, marginBottom: 8 }}>Welcome back</h1>
        <p style={{ color: 'var(--text-2)', fontSize: 15 }}>Sign in to your Zentro account</p>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Email</label>
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@email.com" required />
        </div>
        <div className="form-group" style={{ marginBottom: 24 }}>
          <label>Password</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
        </div>
        <button type="submit" className="btn-primary" disabled={loading}>
          {loading ? 'Signing in...' : 'Sign In'}
        </button>
      </form>

      <p style={{ textAlign: 'center', marginTop: 24, color: 'var(--text-2)', fontSize: 14 }}>
        No account? <Link to="/register" style={{ color: 'var(--brand)', fontWeight: 700 }}>Create one</Link>
      </p>
    </div>
  );
}
