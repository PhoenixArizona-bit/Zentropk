import React, { useEffect, useState, useRef, useCallback } from 'react';

import { supabase } from '../lib/supabase';

// ─────────────────────────────────────────────────────────────────────────────
// SHA-256 helper (Web Crypto — no external lib needed)
// ─────────────────────────────────────────────────────────────────────────────
async function sha256(msg) {
  if (!crypto?.subtle) {
    let h = 5381;
    for (let i = 0; i < msg.length; i++) h = ((h << 5) + h) ^ msg.charCodeAt(i);
    return (h >>> 0).toString(16).padStart(8, '0').repeat(8);
  }
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

// ─────────────────────────────────────────────────────────────────────────────
// Rate limiter — tracks attempts in memory with exponential backoff
// ─────────────────────────────────────────────────────────────────────────────
const rateLimiter = (() => {
  const RATE_KEY = 'zentro_admin_rate';
  const get = () => { try { return JSON.parse(sessionStorage.getItem(RATE_KEY)) || { count: 0, until: 0 }; } catch { return { count: 0, until: 0 }; } };
  const set = (v) => { try { sessionStorage.setItem(RATE_KEY, JSON.stringify(v)); } catch {} };
  return {
    isLocked: () => get().until > Date.now(),
    lockSeconds: () => Math.max(0, Math.ceil((get().until - Date.now()) / 1000)),
    recordFailure: () => {
      const s = get();
      const count = s.count + 1;
      // Exponential backoff: 30s, 60s, 120s, 300s
      const delays = [30, 60, 120, 300];
      const delay = (delays[Math.min(count - 1, delays.length - 1)] || 300) * 1000;
      set({ count, until: Date.now() + delay });
      return Math.ceil(delay / 1000);
    },
    reset: () => set({ count: 0, until: 0 }),
  };
})();

// ─────────────────────────────────────────────────────────────────────────────
// NO hardcoded passwords — all credentials live in Supabase app_settings only
// If no hash found in DB, login is blocked (forces admin to set credentials first)
// ─────────────────────────────────────────────────────────────────────────────
const SESSION_KEY    = 'zentro_admin_secret';
const SESSION_TTL_MS = 4 * 60 * 60 * 1000; // 4 hours
const MAX_ATTEMPTS   = 4;
const LOCK_SECONDS   = 45;

// ─────────────────────────────────────────────────────────────────────────────
// Pattern lock grid (3×3, nodes 1-9)
// ─────────────────────────────────────────────────────────────────────────────
const PL_SIZE = 240;
const PL_NODE_RADIUS = 18;
const PL_DOT_RADIUS  = 5;
const PL_CELL = PL_SIZE / 3;
const PL_NODES = [
  {id:1,r:0,c:0},{id:2,r:0,c:1},{id:3,r:0,c:2},
  {id:4,r:1,c:0},{id:5,r:1,c:1},{id:6,r:1,c:2},
  {id:7,r:2,c:0},{id:8,r:2,c:1},{id:9,r:2,c:2},
];
function plCenter(node) {
  return { x: node.c * PL_CELL + PL_CELL / 2, y: node.r * PL_CELL + PL_CELL / 2 };
}

function PatternLockInput({ onPatternComplete, disabled, error }) {
  const svgRef = useRef(null);
  const [pattern, setPattern] = useState([]);
  const [currentPos, setCurrentPos] = useState(null);
  const [drawing, setDrawing] = useState(false);
  const [flash, setFlash] = useState(null); // 'error' | null

  const reset = () => { setPattern([]); setCurrentPos(null); setDrawing(false); };

  useEffect(() => {
    if (error) {
      setFlash('error');
      setTimeout(() => { setFlash(null); reset(); }, 600);
    }
  }, [error]); // eslint-disable-line

  const getSVGPos = (e) => {
    const svg = svgRef.current; if (!svg) return null;
    const rect = svg.getBoundingClientRect();
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: (cx - rect.left) * (PL_SIZE / rect.width), y: (cy - rect.top) * (PL_SIZE / rect.height) };
  };
  const getNodeAt = (pos) => PL_NODES.find(n => {
    const c = plCenter(n);
    return Math.hypot(pos.x - c.x, pos.y - c.y) < PL_NODE_RADIUS + 6;
  });

  const startDraw = (e) => {
    if (disabled) return; e.preventDefault();
    const pos = getSVGPos(e); if (!pos) return;
    const node = getNodeAt(pos);
    if (node) { setDrawing(true); setPattern([node.id]); setCurrentPos(pos); }
  };
  const moveDraw = (e) => {
    if (!drawing || disabled) return; e.preventDefault();
    const pos = getSVGPos(e); if (!pos) return;
    setCurrentPos(pos);
    const node = getNodeAt(pos);
    if (node && !pattern.includes(node.id)) setPattern(prev => [...prev, node.id]);
  };
  const endDraw = (e) => {
    if (!drawing || disabled) return; e.preventDefault();
    setDrawing(false); setCurrentPos(null);
    if (pattern.length >= 3) { onPatternComplete(pattern); } else { reset(); }
  };

  const lineColor = flash === 'error' ? '#FF3D00' : '#FF3D00';
  const lines = [];
  for (let i = 0; i < pattern.length - 1; i++) {
    const a = plCenter(PL_NODES.find(n => n.id === pattern[i]));
    const b = plCenter(PL_NODES.find(n => n.id === pattern[i + 1]));
    lines.push(<line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={lineColor} strokeWidth={2.5} strokeOpacity={0.7} />);
  }
  if (drawing && currentPos && pattern.length > 0) {
    const last = plCenter(PL_NODES.find(n => n.id === pattern[pattern.length - 1]));
    lines.push(<line key="cur" x1={last.x} y1={last.y} x2={currentPos.x} y2={currentPos.y} stroke={lineColor} strokeWidth={2.5} strokeOpacity={0.4} strokeDasharray="4 4" />);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 1 }}>
        Draw Pattern
      </div>
      <svg
        ref={svgRef}
        viewBox={`0 0 ${PL_SIZE} ${PL_SIZE}`}
        style={{
          width: PL_SIZE, height: PL_SIZE, touchAction: 'none', userSelect: 'none',
          borderRadius: 20, background: 'var(--bg-input)',
          border: `1.5px solid ${flash === 'error' ? '#FF3D00' : 'var(--border)'}`,
          transition: 'border-color 0.2s', opacity: disabled ? 0.5 : 1,
        }}
        onMouseDown={startDraw} onMouseMove={moveDraw} onMouseUp={endDraw} onMouseLeave={endDraw}
        onTouchStart={startDraw} onTouchMove={moveDraw} onTouchEnd={endDraw}
      >
        {lines}
        {PL_NODES.map(node => {
          const { x, y } = plCenter(node);
          const active = pattern.includes(node.id);
          return (
            <g key={node.id}>
              <circle cx={x} cy={y} r={PL_NODE_RADIUS} fill="none"
                stroke={active ? lineColor : 'var(--border)'}
                strokeWidth={active ? 2 : 1.5} opacity={active ? 1 : 0.5} />
              <circle cx={x} cy={y} r={PL_DOT_RADIUS}
                fill={active ? lineColor : 'var(--text-3)'} opacity={active ? 1 : 0.4} />
              {active && (
                <text x={x} y={y - PL_NODE_RADIUS - 4}
                  textAnchor="middle" fontSize={9}
                  fill={lineColor} fontWeight="bold" opacity={0.8}>
                  {pattern.indexOf(node.id) + 1}
                </text>
              )}
            </g>
          );
        })}
      </svg>
      <div style={{ display: 'flex', gap: 4, minHeight: 12 }}>
        {pattern.map((_, i) => (
          <div key={i} style={{ width: 8, height: 8, borderRadius: '50%', background: flash === 'error' ? '#FF3D00' : 'var(--brand)' }} />
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Inline two-step login gate (password → pattern)
// ─────────────────────────────────────────────────────────────────────────────
function AdminLogin({ onSuccess }) {
  const [step, setStep]           = useState('password'); // 'password' | 'pattern'
  const [password, setPassword]   = useState('');
  const [showPass,  setShowPass]  = useState(false);
  const [patternError, setPatternError] = useState(0); // increment triggers flash
  const [error,     setError]     = useState('');
  const [loading,   setLoading]   = useState(false);
  const [attempts,  setAttempts]  = useState(0);
  const [patternAttempts, setPatternAttempts] = useState(0);
  const [locked,    setLocked]    = useState(false);
  const [lockTimer, setLockTimer] = useState(0);
  const inputRef = useRef(null);

  // Lockout countdown
  useEffect(() => {
    if (!locked) return;
    const iv = setInterval(() => {
      setLockTimer(t => {
        if (t <= 1) { setLocked(false); clearInterval(iv); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [locked]);

  const lockout = (msg) => {
    setLocked(true);
    setLockTimer(LOCK_SECONDS);
    setError(msg || `Too many attempts. Locked for ${LOCK_SECONDS}s.`);
  };

  const handlePasswordSubmit = async () => {
    if (locked || loading) return;
    if (rateLimiter.isLocked()) {
      setError(`Too many failed attempts. Wait ${rateLimiter.lockSeconds()}s.`);
      return;
    }
    if (!password.trim()) { setError('Enter your password.'); return; }
    setLoading(true); setError('');

    let storedHash = null;
    try {
      const { data } = await supabase
        .from('app_settings').select('value').eq('key', 'admin_password_hash').maybeSingle();
      storedHash = data?.value || null;
    } catch (_) {}

    if (!storedHash) {
      setLoading(false);
      setError('Admin credentials not configured. Set up password in Supabase app_settings first.');
      return;
    }

    const inputHash = await sha256(password);
    setLoading(false);

    if (inputHash === storedHash) {
      rateLimiter.reset();
      setError('');
      setPatternAttempts(0);
      setStep('pattern');
    } else {
      const next = attempts + 1;
      setAttempts(next);
      setPassword('');
      if (next >= MAX_ATTEMPTS) {
        const secs = rateLimiter.recordFailure();
        setLocked(true);
        setLockTimer(secs);
        setError(`Too many attempts. Locked for ${secs}s.`);
      } else {
        setError(`Wrong password — ${MAX_ATTEMPTS - next} attempt${MAX_ATTEMPTS - next === 1 ? '' : 's'} left.`);
        setTimeout(() => inputRef.current?.focus(), 50);
      }
    }
  };

  const handlePatternComplete = async (drawnPattern) => {
    if (locked) return;
    const drawnStr = drawnPattern.join('-');
    setLoading(true);

    let storedHash = null;
    try {
      const { data } = await supabase
        .from('app_settings').select('value').eq('key', 'admin_pattern_hash').maybeSingle();
      storedHash = data?.value || null;
    } catch (_) {}

    if (!storedHash) {
      setLoading(false);
      setError('Pattern not configured. Set up pattern in admin settings first.');
      return;
    }

    const inputHash = await sha256(drawnStr);
    setLoading(false);

    if (inputHash === storedHash) {
      rateLimiter.reset();
      sessionStorage.setItem(SESSION_KEY, Date.now().toString());
      onSuccess();
    } else {
      const next = patternAttempts + 1;
      setPatternAttempts(next);
      setPatternError(e => e + 1);
      if (next >= MAX_ATTEMPTS) {
        const secs = rateLimiter.recordFailure();
        setLocked(true);
        setLockTimer(secs);
        setStep('password');
        setError(`Too many failed attempts. Locked for ${secs}s.`);
      } else {
        setError(`Wrong pattern — ${MAX_ATTEMPTS - next} attempt${MAX_ATTEMPTS - next === 1 ? '' : 's'} left.`);
      }
    }
  };

  return (
    <div className="page fade-up" style={{
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      minHeight: '80vh', padding: '0 32px',
    }}>
      {/* Icon */}
      <div style={{
        width: 68, height: 68, borderRadius: 22,
        background: 'linear-gradient(135deg, #FF3D00, #c62800)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 30, marginBottom: 20,
        boxShadow: '0 8px 28px rgba(255,61,0,0.35)',
      }}>🔐</div>

      <h2 style={{ fontFamily: 'Outfit', fontWeight: 800, fontSize: 22, marginBottom: 6 }}>
        {step === 'password' ? 'Admin Portal' : 'Draw Your Pattern'}
      </h2>
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 20, textAlign: 'center' }}>
        {step === 'password' ? 'Step 2 of 3 — Enter your secret password' : 'Step 3 of 3 — Draw your unlock pattern'}
      </p>

      {/* Step indicator — 3 steps, step 1 (corners) already done */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        {[1, 2, 3].map(s => (
          <div key={s} style={{
            width: s === (step === 'password' ? 2 : 3) ? 24 : 8,
            height: 8, borderRadius: 4,
            background: s <= (step === 'password' ? 2 : 3) ? 'var(--brand)' : 'var(--border)',
            transition: 'all 0.3s',
          }} />
        ))}
      </div>

      {/* Password step */}
      {step === 'password' && (
        <div style={{ width: '100%' }}>
          <div style={{ width: '100%', position: 'relative', marginBottom: 14 }}>
            <input
              ref={inputRef}
              type={showPass ? 'text' : 'password'}
              value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handlePasswordSubmit()}
              placeholder="Secret password"
              disabled={locked}
              autoComplete="current-password"
              style={{
                width: '100%', padding: '14px 48px 14px 16px',
                background: 'var(--bg-input)', border: `1.5px solid ${error ? 'rgba(255,61,0,0.5)' : 'var(--border)'}`,
                borderRadius: 14, color: 'var(--text)', fontSize: 15,
                fontFamily: 'inherit', boxSizing: 'border-box',
                opacity: locked ? 0.5 : 1, outline: 'none',
              }}
            />
            <button onClick={() => setShowPass(s => !s)} style={{
              position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)',
              background: 'none', border: 'none', cursor: 'pointer', fontSize: 18, color: 'var(--text-3)',
            }}>{showPass ? '🙈' : '👁️'}</button>
          </div>
          <button
            onClick={handlePasswordSubmit}
            disabled={loading || locked}
            className="btn-primary"
            style={{ opacity: locked ? 0.5 : 1, cursor: locked ? 'not-allowed' : 'pointer' }}
          >
            {loading ? 'Checking...' : locked ? `🔒 ${lockTimer}s` : 'Next →'}
          </button>
        </div>
      )}

      {/* Pattern step */}
      {step === 'pattern' && (
        <PatternLockInput
          onPatternComplete={handlePatternComplete}
          disabled={locked || loading}
          error={patternError}
        />
      )}

      {(error || locked) && (
        <div style={{
          width: '100%', padding: '11px 16px', borderRadius: 12, marginTop: 14,
          background: 'rgba(255,61,0,0.1)', border: '1px solid rgba(255,61,0,0.25)',
          color: '#FF3D00', fontSize: 13, fontWeight: 600, textAlign: 'center',
        }}>
          {locked ? `🔒 Too many attempts — wait ${lockTimer}s` : `⚠️ ${error}`}
        </div>
      )}

      {/* Back button */}
      <button
        onClick={() => step === 'pattern' ? setStep('password') : undefined}
        style={{
          marginTop: 20, background: 'none', border: 'none',
          color: 'var(--text-3)', fontSize: 13, cursor: 'pointer',
          display: step === 'pattern' ? 'block' : 'none',
        }}
      >← Back to password</button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Mini pattern setter used inside Settings tab
// ─────────────────────────────────────────────────────────────────────────────
const AP_SIZE = 180;
const AP_CELL = AP_SIZE / 3;
const AP_NODES = [
  {id:1,r:0,c:0},{id:2,r:0,c:1},{id:3,r:0,c:2},
  {id:4,r:1,c:0},{id:5,r:1,c:1},{id:6,r:1,c:2},
  {id:7,r:2,c:0},{id:8,r:2,c:1},{id:9,r:2,c:2},
];
function nc(node) { return { x: node.c * AP_CELL + AP_CELL/2, y: node.r * AP_CELL + AP_CELL/2 }; }

function AdminPatternSetter({ onPatternSet, onPatternClear }) {
  const svgRef = React.useRef(null);
  const [pattern, setPattern] = React.useState([]);
  const [pos, setPos] = React.useState(null);
  const [drawing, setDrawing] = React.useState(false);
  const [confirmed, setConfirmed] = React.useState(false);

  const getSVGPos = (e) => {
    const svg = svgRef.current; if (!svg) return null;
    const rect = svg.getBoundingClientRect();
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: (cx - rect.left) * (AP_SIZE / rect.width), y: (cy - rect.top) * (AP_SIZE / rect.height) };
  };
  const getNode = (p) => AP_NODES.find(n => { const c = nc(n); return Math.hypot(p.x-c.x, p.y-c.y) < 22; });

  const start = (e) => { e.preventDefault(); const p = getSVGPos(e); if (!p) return; const n = getNode(p); if (n) { setDrawing(true); setPattern([n.id]); setPos(p); setConfirmed(false); onPatternClear(); } };
  const move  = (e) => { if (!drawing) return; e.preventDefault(); const p = getSVGPos(e); if (!p) return; setPos(p); const n = getNode(p); if (n && !pattern.includes(n.id)) setPattern(prev => [...prev, n.id]); };
  const end   = (e) => { if (!drawing) return; e.preventDefault(); setDrawing(false); setPos(null); if (pattern.length >= 4) { setConfirmed(true); onPatternSet(pattern); } else { setPattern([]); } };
  const reset = () => { setPattern([]); setPos(null); setDrawing(false); setConfirmed(false); onPatternClear(); };

  const lines = [];
  for (let i = 0; i < pattern.length - 1; i++) {
    const a = nc(AP_NODES.find(n=>n.id===pattern[i])), b = nc(AP_NODES.find(n=>n.id===pattern[i+1]));
    lines.push(<line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#FF3D00" strokeWidth={2} strokeOpacity={0.7} />);
  }
  if (drawing && pos && pattern.length > 0) {
    const last = nc(AP_NODES.find(n=>n.id===pattern[pattern.length-1]));
    lines.push(<line key="cur" x1={last.x} y1={last.y} x2={pos.x} y2={pos.y} stroke="#FF3D00" strokeWidth={2} strokeOpacity={0.4} strokeDasharray="4 4" />);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 10 }}>
      <svg ref={svgRef} viewBox={`0 0 ${AP_SIZE} ${AP_SIZE}`}
        style={{ width: AP_SIZE, height: AP_SIZE, touchAction: 'none', userSelect: 'none', borderRadius: 16, background: 'var(--bg-input)', border: `1.5px solid ${confirmed ? '#22c55e' : 'var(--border)'}` }}
        onMouseDown={start} onMouseMove={move} onMouseUp={end} onMouseLeave={end}
        onTouchStart={start} onTouchMove={move} onTouchEnd={end}
      >
        {lines}
        {AP_NODES.map(node => { const {x,y} = nc(node); const active = pattern.includes(node.id);
          return <g key={node.id}>
            <circle cx={x} cy={y} r={14} fill="none" stroke={active ? '#FF3D00' : 'var(--border)'} strokeWidth={active?2:1.5} opacity={active?1:0.5} />
            <circle cx={x} cy={y} r={4} fill={active ? '#FF3D00' : 'var(--text-3)'} opacity={active?1:0.4} />
          </g>;
        })}
      </svg>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        {confirmed && <span style={{ fontSize: 12, color: '#22c55e', fontWeight: 700 }}>✓ Pattern recorded ({pattern.length} nodes)</span>}
        {pattern.length > 0 && <button onClick={reset} style={{ background: 'none', border: 'none', color: 'var(--text-3)', fontSize: 12, cursor: 'pointer', textDecoration: 'underline' }}>Clear</button>}
        {!confirmed && !drawing && pattern.length === 0 && <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Draw on the grid above</span>}
        {!confirmed && !drawing && pattern.length > 0 && pattern.length < 4 && <span style={{ fontSize: 12, color: '#FF3D00' }}>Need at least 4 nodes</span>}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Main AdminPortal component
// ─────────────────────────────────────────────────────────────────────────────
export default function AdminPortal() {

  // Check if the in-session token is still valid (set by AdminLogin on success)
  const isSessionValid = () => {
    const token = sessionStorage.getItem(SESSION_KEY);
    return token && (Date.now() - parseInt(token)) < SESSION_TTL_MS;
  };

  const [authed, setAuthed] = useState(isSessionValid);

  const [tab, setTab]           = useState('overview');
  const [stats, setStats]       = useState({});
  const [shops, setShops]       = useState([]);
  const [payments, setPayments] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [users, setUsers]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [toast, setToast]       = useState({ type: '', text: '' });

  // Settings state
  const [pass1, setPass1]               = useState('');
  const [confirmPass1, setConfirmPass1] = useState('');
  const [newPattern, setNewPattern]     = useState([]);
  const [patternSet, setPatternSet]     = useState(false);
  const [savingPass, setSavingPass]     = useState(false);
  const [secretKeyword, setSecretKeyword]     = useState('');
  const [savedKeyword, setSavedKeyword]       = useState('');
  const [savingKeyword, setSavingKeyword]     = useState(false);
  const [jazzNumber,    setJazzNumber]        = useState('');
  const [easyNumber,    setEasyNumber]        = useState('');
  const [jazzName,      setJazzName]          = useState('');
  const [easyName,      setEasyName]          = useState('');
  const [savingNumbers, setSavingNumbers]     = useState(false);
  const [tierSettings,  setTierSettings]      = useState({
    basic:   { name: 'Basic',   price: '500',  desc: 'Listed on explore, up to 5 services, 3 photos',                     qr_enabled: false },
    pro:     { name: 'Pro',     price: '1000', desc: 'Everything in Basic + 15 services, 10 photos, priority listing',     qr_enabled: true  },
    premium: { name: 'Premium', price: '2000', desc: 'Everything in Pro + unlimited services & photos, featured badge',    qr_enabled: true  },
  });
  const [savingTiers,   setSavingTiers]       = useState(false);

  const [processingPayment, setProcessingPayment] = useState(null);
  const [bookingsPage, setBookingsPage] = useState(0);
  const [usersPage, setUsersPage]       = useState(0);
  const PAGE_SIZE = 20;

  const showToast = (type, text) => {
    setToast({ type, text });
    setTimeout(() => setToast({ type: '', text: '' }), 3000);
  };

  // Only fetch once authed
  useEffect(() => { if (authed) fetchAll(); }, [authed]); // eslint-disable-line

  const fetchAll = async () => {
    setLoading(true);

    const [, , , ] = await Promise.all([
      supabase.from('shops').select('*').order('created_at', { ascending: false })
        .then(({ data }) => {
          const sd = data || [];
          setShops(sd);
          setStats(prev => ({ ...prev, totalShops: sd.length, activeShops: sd.filter(s => s.is_active).length }));
        }),

      supabase.from('payment_submissions').select('*, shops(name), profiles(full_name)').order('submitted_at', { ascending: false })
        .then(({ data }) => {
          const pd = data || [];
          setPayments(pd);
          setStats(prev => ({ ...prev, pendingPayments: pd.filter(p => p.status === 'pending').length }));
        }),

      supabase.from('bookings').select('*, profiles(full_name), shops(name), services(name), time_slots(slot_date, start_time)', { count: 'exact' })
        .order('created_at', { ascending: false }).range(bookingsPage * PAGE_SIZE, (bookingsPage + 1) * PAGE_SIZE - 1)
        .then(({ data, count }) => {
          const bd = data || [];
          setBookings(bd);
          setStats(prev => ({ ...prev, totalBookings: count || 0 }));
        }),

      supabase.from('profiles').select('*').order('created_at', { ascending: false })
        .then(({ data }) => {
          const ud = data || [];
          setUsers(ud);
          setStats(prev => ({ ...prev, totalCustomers: ud.filter(u => u.role === 'customer').length }));
        }),
    ]);

    // Load secret keyword, payment numbers, and tiers
    supabase.from('app_settings').select('key, value')
      .in('key', [
        'admin_search_keyword', 'jazzcash_number', 'easypaisa_number',
        'jazzcash_name', 'easypaisa_name',
        'tier_basic_name', 'tier_basic_price', 'tier_basic_desc', 'tier_basic_qr_enabled',
        'tier_pro_name',   'tier_pro_price',   'tier_pro_desc',   'tier_pro_qr_enabled',
        'tier_premium_name','tier_premium_price','tier_premium_desc','tier_premium_qr_enabled',
      ])
      .then(({ data }) => {
        if (!data) return;
        const g = (k) => data.find(d => d.key === k)?.value || '';
        const gb = (k, def) => { const v = data.find(d => d.key === k)?.value; return v !== undefined ? v === 'true' : def; };
        const kw = g('admin_search_keyword') || 'zentro@admin';
        setSecretKeyword(kw); setSavedKeyword(kw);
        setJazzNumber(g('jazzcash_number'));
        setEasyNumber(g('easypaisa_number'));
        setJazzName(g('jazzcash_name'));
        setEasyName(g('easypaisa_name'));
        setTierSettings({
          basic:   { name: g('tier_basic_name')   || 'Basic',   price: g('tier_basic_price')   || '500',  desc: g('tier_basic_desc')   || '', qr_enabled: gb('tier_basic_qr_enabled', false) },
          pro:     { name: g('tier_pro_name')     || 'Pro',     price: g('tier_pro_price')     || '1000', desc: g('tier_pro_desc')     || '', qr_enabled: gb('tier_pro_qr_enabled', true)  },
          premium: { name: g('tier_premium_name') || 'Premium', price: g('tier_premium_price') || '2000', desc: g('tier_premium_desc') || '', qr_enabled: gb('tier_premium_qr_enabled', true) },
        });
      });

    setLoading(false);
  };

  const approveShop = async (shopId, active) => {
    const { error } = await supabase.from('shops').update({ is_active: active }).eq('id', shopId);
    if (error) { showToast('error', 'Failed to update shop: ' + error.message); return; }
    showToast('success', active ? 'Shop approved ✓' : 'Shop deactivated ✓');
    fetchAll();
  };

  const setSubscription = async (shopId, status) => {
    const { error } = await supabase.from('shops').update({ subscription_status: status }).eq('id', shopId);
    if (error) { showToast('error', 'Failed to update subscription: ' + error.message); return; }
    showToast('success', 'Subscription updated ✓');
    fetchAll();
  };

  const reviewPayment = async (paymentId, shopId, status, note, grantedTier) => {
    if (processingPayment) return;
    setProcessingPayment(paymentId);
    const { error: payErr } = await supabase
      .from('payment_submissions')
      .update({ status, admin_note: note, reviewed_at: new Date().toISOString() })
      .eq('id', paymentId);
    if (payErr) { showToast('error', 'Failed to review payment: ' + payErr.message); setProcessingPayment(null); return; }

    // Get shop owner_id for notification
    const { data: shopData } = await supabase.from('shops').select('owner_id').eq('id', shopId).single();
    const ownerId = shopData?.owner_id;

    if (status === 'approved') {
      const { error: shopErr } = await supabase.from('shops').update({
        subscription_status: 'active',
        subscription_tier: grantedTier || 'basic',
        is_active: true,
        subscription_expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      }).eq('id', shopId);
      if (shopErr) {
        showToast('error', 'Payment approved but failed to activate shop: ' + shopErr.message);
      } else {
        // Send approval notification
        if (ownerId) {
          await supabase.from('notifications').insert({
            shop_id: shopId,
            owner_id: ownerId,
            type: 'payment_approved',
            title: '✅ Payment Approved!',
            message: `Your ${(grantedTier || 'basic')} plan payment has been approved. Your shop is now live for 30 days!`,
          });
        }
        showToast('success', `Payment approved — ${(grantedTier || 'basic').toUpperCase()} plan granted!`);
      }
    } else {
      // Send rejection notification
      if (ownerId) {
        await supabase.from('notifications').insert({
          shop_id: shopId,
          owner_id: ownerId,
          type: 'payment_rejected',
          title: '❌ Payment Rejected',
          message: note
            ? `Your payment was rejected. Admin note: "${note}". Please resubmit with correct details.`
            : 'Your payment was rejected. Please resubmit with the correct transaction ID and screenshot.',
        });
      }
      showToast('success', 'Payment rejected.');
    }
    setProcessingPayment(null);
    fetchAll();
  };

  const saveCredentials = async () => {
    if (!pass1 && newPattern.length === 0) { showToast('error', 'Enter a new password or set a new pattern'); return; }
    if (pass1 && pass1.length < 6) { showToast('error', 'Password must be at least 6 characters'); return; }
    if (pass1 && pass1 !== confirmPass1) { showToast('error', 'Passwords do not match'); return; }
    if (newPattern.length > 0 && newPattern.length < 4) { showToast('error', 'Pattern must connect at least 4 nodes'); return; }
    setSavingPass(true);
    const updates = [];
    if (pass1) updates.push({ key: 'admin_password_hash', value: await sha256(pass1) });
    if (newPattern.length > 0) updates.push({ key: 'admin_pattern_hash', value: await sha256(newPattern.join('-')) });
    const { error } = await supabase.from('app_settings').upsert(updates, { onConflict: 'key' });
    setSavingPass(false);
    if (error) { showToast('error', 'Failed to save: ' + error.message); return; }
    setPass1(''); setConfirmPass1(''); setNewPattern([]); setPatternSet(false);
    showToast('success', 'Credentials updated ✓');
  };

  const saveNumbers = async () => {
    if (!jazzNumber.trim() && !easyNumber.trim()) { showToast('error', 'Enter at least one number'); return; }
    setSavingNumbers(true);
    const updates = [];
    if (jazzNumber.trim()) updates.push({ key: 'jazzcash_number', value: jazzNumber.trim() });
    if (easyNumber.trim()) updates.push({ key: 'easypaisa_number', value: easyNumber.trim() });
    if (jazzName.trim())   updates.push({ key: 'jazzcash_name',   value: jazzName.trim() });
    if (easyName.trim())   updates.push({ key: 'easypaisa_name',  value: easyName.trim() });
    const { error } = await supabase.from('app_settings').upsert(updates, { onConflict: 'key' });
    setSavingNumbers(false);
    if (error) { showToast('error', 'Failed to save: ' + error.message); return; }
    showToast('success', 'Payment details updated ✓');
  };

  const saveTiers = async () => {
    setSavingTiers(true);
    const updates = ['basic', 'pro', 'premium'].flatMap(key => [
      { key: `tier_${key}_name`,       value: tierSettings[key].name       || '' },
      { key: `tier_${key}_price`,      value: tierSettings[key].price      || '0' },
      { key: `tier_${key}_desc`,       value: tierSettings[key].desc       || '' },
      { key: `tier_${key}_qr_enabled`, value: String(!!tierSettings[key].qr_enabled) },
    ]);
    const { error } = await supabase.from('app_settings').upsert(updates, { onConflict: 'key' });
    setSavingTiers(false);
    if (error) { showToast('error', 'Failed to save tiers: ' + error.message); return; }
    showToast('success', 'Subscription tiers updated ✓');
  };

  const saveKeyword = async () => {
    if (!secretKeyword.trim()) { showToast('error', 'Keyword cannot be empty'); return; }
    if (secretKeyword.trim().length < 6) { showToast('error', 'Keyword must be at least 6 characters'); return; }
    setSavingKeyword(true);
    const { error } = await supabase.from('app_settings')
      .upsert([{ key: 'admin_search_keyword', value: secretKeyword.trim() }], { onConflict: 'key' });
    setSavingKeyword(false);
    if (error) { showToast('error', 'Failed to save: ' + error.message); return; }
    setSavedKeyword(secretKeyword.trim());
    showToast('success', 'Secret keyword updated ✓');
  };

  const handleLogout = () => {
    sessionStorage.removeItem(SESSION_KEY);
    setAuthed(false);
  };

  const deleteBooking = async (bookingId) => {
    if (!window.confirm('Delete this booking permanently?')) return;
    const { error } = await supabase.from('bookings').delete().eq('id', bookingId);
    if (error) { showToast('error', 'Failed to delete booking: ' + error.message); return; }
    showToast('success', 'Booking deleted ✓');
    setBookings(prev => prev.filter(b => b.id !== bookingId));
    setStats(prev => ({ ...prev, totalBookings: (prev.totalBookings || 1) - 1 }));
  };

  if (!authed) return <AdminLogin onSuccess={() => setAuthed(true)} />;

  const tabs = [
    { key: 'overview',  icon: '📊', label: 'Overview' },
    { key: 'payments',  icon: '💳', label: 'Payments', badge: stats.pendingPayments },
    { key: 'shops',     icon: '💈', label: 'Shops' },
    { key: 'bookings',  icon: '📅', label: 'Bookings' },
    { key: 'users',     icon: '👥', label: 'Users' },
    { key: 'settings',  icon: '⚙️', label: 'Settings' },
  ];

  if (loading) return (
    <div className="loading-screen">
      <div className="loading-logo">🛡️ Admin</div>
      <div className="spinner" />
    </div>
  );

  return (
    <div className="page fade-up" style={{ paddingBottom: 140 }}>
      {/* Toast */}
      {toast.text && (
        <div className={`alert alert-${toast.type}`} style={{ margin: '0 20px 12px' }}>{toast.text}</div>
      )}

      {/* Header */}
      <div className="top-header">
        <div className="logo-text">🛡️ <span>Admin</span></div>
        <button
          onClick={handleLogout}
          style={{
            padding: '7px 14px', borderRadius: 100,
            border: '1.5px solid var(--border)', background: 'transparent',
            color: 'var(--text-2)', fontFamily: 'Plus Jakarta Sans, sans-serif',
            fontWeight: 700, fontSize: 12, cursor: 'pointer',
          }}
        >🚪 Logout</button>
      </div>

      {/* Tab Bar */}
      <div style={{ display: 'flex', overflowX: 'auto', gap: 8, padding: '0 20px 16px', scrollbarWidth: 'none' }}>
        {tabs.map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            style={{
              flexShrink: 0, padding: '8px 16px', borderRadius: 100, border: 'none',
              background: tab === t.key ? 'var(--brand)' : 'var(--bg-input)',
              color: tab === t.key ? '#fff' : 'var(--text-2)',
              fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: 13,
              cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
              transition: 'all 0.2s',
            }}
          >
            {t.icon} {t.label}
            {t.badge > 0 && (
              <span style={{
                background: tab === t.key ? '#fff' : 'var(--brand)',
                color: tab === t.key ? 'var(--brand)' : '#fff',
                borderRadius: 100, fontSize: 10, fontWeight: 800,
                padding: '1px 6px', minWidth: 18, textAlign: 'center',
              }}>{t.badge}</span>
            )}
          </button>
        ))}
      </div>

      <div style={{ padding: '0 20px' }}>

        {/* OVERVIEW */}
        {tab === 'overview' && (
          <div className="fade-up">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
              {[
                { label: 'Total Shops',      value: stats.totalShops,      icon: '💈', color: 'var(--brand)' },
                { label: 'Active Shops',     value: stats.activeShops,     icon: '✅', color: '#00C864' },
                { label: 'Pending Payments', value: stats.pendingPayments, icon: '⏳', color: 'var(--accent)' },
                { label: 'Total Bookings',   value: stats.totalBookings,   icon: '📅', color: 'var(--brand)' },
                { label: 'Customers',        value: stats.totalCustomers,  icon: '👥', color: 'var(--text-2)' },
              ].map((s, i) => (
                <div key={i} className="card" style={{ padding: 16 }}>
                  <div style={{ fontSize: 24, marginBottom: 8 }}>{s.icon}</div>
                  <div style={{ fontSize: 28, fontWeight: 800, fontFamily: 'Outfit, sans-serif', color: s.color }}>
                    {s.value ?? <span style={{ fontSize: 16, color: 'var(--text-3)' }}>…</span>}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-3)', fontWeight: 600, marginTop: 2 }}>{s.label}</div>
                </div>
              ))}
            </div>
            {stats.pendingPayments > 0 && (
              <div className="alert alert-error" style={{ cursor: 'pointer' }} onClick={() => setTab('payments')}>
                ⚠️ {stats.pendingPayments} payment(s) waiting for review — tap to review
              </div>
            )}
            <button onClick={fetchAll} style={{
              marginTop: 12, padding: '10px 20px', borderRadius: 12,
              border: '1.5px solid var(--border)', background: 'var(--bg-input)',
              color: 'var(--text-2)', fontWeight: 700, fontSize: 13, cursor: 'pointer',
              fontFamily: 'Plus Jakarta Sans, sans-serif',
            }}>🔄 Refresh Data</button>
          </div>
        )}

        {/* PAYMENTS */}
        {tab === 'payments' && (
          <div className="fade-up">
            <p className="section-label" style={{ marginBottom: 16 }}>Payment Submissions</p>
            {payments.length === 0 && <p style={{ color: 'var(--text-3)', textAlign: 'center', marginTop: 40 }}>No payments yet.</p>}
            {payments.map(pay => (
              <PaymentRow key={pay.id} pay={pay} onReview={reviewPayment} processing={processingPayment === pay.id} />
            ))}
          </div>
        )}

        {/* SHOPS */}
        {tab === 'shops' && (
          <div className="fade-up">
            <p className="section-label" style={{ marginBottom: 16 }}>All Shops</p>
            {shops.length === 0 && <p style={{ color: 'var(--text-3)', textAlign: 'center', marginTop: 40 }}>No shops yet.</p>}
            {shops.map(shop => (
              <div key={shop.id} className="card" style={{ padding: 16, marginBottom: 12 }}>
                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontWeight: 700, fontSize: 16, fontFamily: 'Outfit, sans-serif', marginBottom: 4 }}>{shop.name}</div>
                  <div style={{ color: 'var(--text-3)', fontSize: 13 }}>{shop.address}, {shop.city}</div>
                </div>
                <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
                  <StatusBadge active={shop.is_active} label={shop.is_active ? 'Active' : 'Inactive'} />
                  <SubBadge status={shop.subscription_status} />
                  {shop.subscription_tier && shop.subscription_tier !== 'basic' && <TierBadge tier={shop.subscription_tier} tiers={tierSettings} />}
                  {shop.custom_badge && (
                    <span style={{
                      padding: '4px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700,
                      background: shop.custom_badge_color ? `${shop.custom_badge_color}22` : 'rgba(255,61,0,0.1)',
                      color: shop.custom_badge_color || '#FF3D00',
                      border: `1px solid ${shop.custom_badge_color || '#FF3D00'}55`,
                    }}>🏷 {shop.custom_badge}</span>
                  )}
                </div>
                {/* Custom badge editor */}
                <AdminBadgeEditor shop={shop} onSave={async (id, badge, color) => {
                  await supabase.from('shops').update({ custom_badge: badge || null, custom_badge_color: color || null }).eq('id', id);
                  fetchAll();
                  showToast('success', badge ? `Badge "${badge}" set ✓` : 'Badge removed ✓');
                }} />
                <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                  <button
                    onClick={() => approveShop(shop.id, !shop.is_active)}
                    style={{
                      flex: 1, padding: '10px', borderRadius: 12, border: 'none',
                      background: shop.is_active ? 'rgba(255,61,0,0.1)' : 'rgba(0,200,100,0.1)',
                      color: shop.is_active ? 'var(--brand)' : '#00C864',
                      fontWeight: 700, fontSize: 13,
                      fontFamily: 'Plus Jakarta Sans, sans-serif', cursor: 'pointer',
                    }}
                  >{shop.is_active ? 'Deactivate' : 'Activate'}</button>
                  <select
                    value={shop.subscription_status}
                    onChange={e => setSubscription(shop.id, e.target.value)}
                    style={{
                      flex: 1, padding: '10px', background: 'var(--bg-input)',
                      border: '1.5px solid var(--border)', color: 'var(--text)',
                      borderRadius: 12, fontSize: 13, fontFamily: 'Plus Jakarta Sans, sans-serif',
                    }}
                  >
                    <option value="pending">Pending</option>
                    <option value="active">Active</option>
                    <option value="expired">Expired</option>
                    <option value="suspended">Suspended</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* BOOKINGS */}
        {tab === 'bookings' && (
          <div className="fade-up">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <p className="section-label" style={{ margin: 0 }}>All Bookings ({stats.totalBookings || 0})</p>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <button disabled={bookingsPage === 0} onClick={() => { setBookingsPage(p => p - 1); fetchAll(); }} style={{ padding: '4px 12px', borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--bg-input)', color: 'var(--text-2)', fontWeight: 700, cursor: bookingsPage === 0 ? 'not-allowed' : 'pointer', opacity: bookingsPage === 0 ? 0.4 : 1 }}>‹</button>
                <span style={{ fontSize: 12, color: 'var(--text-3)' }}>pg {bookingsPage + 1}</span>
                <button disabled={bookings.length < PAGE_SIZE} onClick={() => { setBookingsPage(p => p + 1); fetchAll(); }} style={{ padding: '4px 12px', borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--bg-input)', color: 'var(--text-2)', fontWeight: 700, cursor: bookings.length < PAGE_SIZE ? 'not-allowed' : 'pointer', opacity: bookings.length < PAGE_SIZE ? 0.4 : 1 }}>›</button>
              </div>
            </div>
            {bookings.length === 0 && <p style={{ color: 'var(--text-3)', textAlign: 'center', marginTop: 40 }}>No bookings yet.</p>}
            {bookings.map(bk => {
              const t = bk.time_slots?.start_time;
              const timeLabel = t ? (() => { const [h,m] = t.split(':').map(Number); const ap = h>=12?'PM':'AM'; return `${h%12||12}:${String(m).padStart(2,'0')} ${ap}`; })() : '';
              return (
              <div key={bk.id} className="card" style={{ padding: 16, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 14 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 15, fontFamily: 'Outfit, sans-serif' }}>{bk.profiles?.full_name || '—'}</div>
                  <div style={{ color: 'var(--text-3)', fontSize: 12, marginTop: 2 }}>{bk.shops?.name} · {bk.services?.name}</div>
                  <div style={{ color: 'var(--text-3)', fontSize: 12, marginTop: 2 }}>
                    {bk.time_slots?.slot_date} {timeLabel}
                  </div>
                </div>
                <BookingBadge status={bk.status} />
                <button onClick={() => deleteBooking(bk.id)} style={{ padding: '6px 10px', borderRadius: 10, border: 'none', background: 'rgba(255,61,0,0.1)', color: 'var(--brand)', fontWeight: 700, fontSize: 14, cursor: 'pointer', flexShrink: 0 }} title="Delete booking">🗑</button>
              </div>
              );
            })}
          </div>
        )}

        {/* USERS */}
        {tab === 'users' && (
          <div className="fade-up">
            <p className="section-label" style={{ marginBottom: 16 }}>All Users</p>
            {users.length === 0 && <p style={{ color: 'var(--text-3)', textAlign: 'center', marginTop: 40 }}>No users yet.</p>}
            {users.map(u => (
              <div key={u.id} className="card" style={{ padding: 16, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 14 }}>
                <div style={{
                  width: 44, height: 44, borderRadius: 14,
                  background: 'var(--brand-glow)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 18, flexShrink: 0,
                }}>
                  {u.role === 'admin' ? '🛡️' : u.role === 'barber' ? '💈' : '👤'}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 15, fontFamily: 'Outfit, sans-serif', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{u.full_name || '—'}</div>
                  <div style={{ color: 'var(--text-3)', fontSize: 12, marginTop: 2 }}>{u.phone || 'No phone'}</div>
                </div>
                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                  <RoleBadge role={u.role} />
                  <div style={{ color: 'var(--text-3)', fontSize: 11, marginTop: 4 }}>{new Date(u.created_at).toLocaleDateString()}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* SETTINGS */}
        {tab === 'settings' && (
          <div className="fade-up">
            <p className="section-label" style={{ marginBottom: 16 }}>Settings</p>

            {/* Powers */}
            <div className="card" style={{ padding: 16, marginBottom: 16 }}>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: 15, marginBottom: 12 }}>🛡️ Admin Powers</div>
              {[
                '✅ Approve or deactivate any barber shop',
                '✅ Manage subscriptions (active/suspended/expired)',
                '✅ Review & approve/reject payment submissions',
                '✅ View all bookings across the platform',
                '✅ View all registered users',
              ].map((p, i) => (
                <div key={i} style={{ fontSize: 13, color: 'var(--text-2)', padding: '6px 0', borderBottom: i < 4 ? '1px solid var(--border)' : 'none' }}>{p}</div>
              ))}
            </div>

            {/* Subscription Tiers */}
            <div className="card" style={{ padding: 20, marginBottom: 16 }}>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 4 }}>📦 Subscription Tiers</div>
              <div style={{ color: 'var(--text-3)', fontSize: 13, marginBottom: 16 }}>Edit the name, price and description for each plan. Barbers see these when paying.</div>
              {['basic', 'pro', 'premium'].map(key => (
                <div key={key} style={{ marginBottom: 20, paddingBottom: 20, borderBottom: key !== 'premium' ? '1px solid var(--border)' : 'none' }}>
                  <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 10, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5 }}>
                    {key === 'basic' ? '🥉' : key === 'pro' ? '🥈' : '🥇'} {key}
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 8 }}>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label>Name</label>
                      <input value={tierSettings[key].name} onChange={e => setTierSettings(prev => ({ ...prev, [key]: { ...prev[key], name: e.target.value } }))} placeholder="e.g. Basic" />
                    </div>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label>Price (Rs./mo)</label>
                      <input type="number" value={tierSettings[key].price} onChange={e => setTierSettings(prev => ({ ...prev, [key]: { ...prev[key], price: e.target.value } }))} placeholder="500" />
                    </div>
                  </div>
                  <div className="form-group" style={{ margin: 0 }}>
                    <label>Description</label>
                    <input value={tierSettings[key].desc} onChange={e => setTierSettings(prev => ({ ...prev, [key]: { ...prev[key], desc: e.target.value } }))} placeholder="What's included..." />
                  </div>
                  {/* QR Code Feature Toggle */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 10, padding: '8px 12px', background: 'var(--bg-input)', borderRadius: 10 }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700 }}>📲 Branded QR Code</div>
                      <div style={{ fontSize: 11, color: 'var(--text-3)' }}>Allow shops on this plan to generate QR codes</div>
                    </div>
                    <button
                      onClick={() => setTierSettings(prev => ({ ...prev, [key]: { ...prev[key], qr_enabled: !prev[key].qr_enabled } }))}
                      style={{
                        width: 44, height: 24, borderRadius: 12, border: 'none', cursor: 'pointer',
                        background: tierSettings[key].qr_enabled ? '#FF3D00' : 'var(--border)',
                        position: 'relative', transition: 'background 0.2s', flexShrink: 0,
                      }}
                    >
                      <span style={{
                        position: 'absolute', top: 3, left: tierSettings[key].qr_enabled ? 23 : 3,
                        width: 18, height: 18, borderRadius: '50%', background: '#fff',
                        transition: 'left 0.2s', display: 'block',
                      }} />
                    </button>
                  </div>
                </div>
              ))}
              <button onClick={saveTiers} disabled={savingTiers} className="btn-primary" style={{ maxWidth: 220 }}>
                {savingTiers ? 'Saving...' : 'Save Tiers'}
              </button>
            </div>

            {/* Payment Numbers */}
            <div className="card" style={{ padding: 20, marginBottom: 16 }}>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 4 }}>💳 Payment Details</div>
              <div style={{ color: 'var(--text-3)', fontSize: 13, marginBottom: 16 }}>
                Account name and number shown to barbers on the payment page.
              </div>

              <div style={{ background: 'var(--bg-input)', borderRadius: 12, padding: '14px 16px', marginBottom: 14 }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#FF6B00', marginBottom: 10 }}>🟠 JazzCash</div>
                <div className="form-group" style={{ marginBottom: 10 }}>
                  <label>Account Name</label>
                  <input
                    type="text"
                    value={jazzName}
                    onChange={e => setJazzName(e.target.value)}
                    placeholder="e.g. Muhammad Ali"
                  />
                </div>
                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label>Account Number</label>
                  <input
                    type="tel"
                    value={jazzNumber}
                    onChange={e => setJazzNumber(e.target.value)}
                    placeholder="e.g. 0300-1234567"
                  />
                </div>
              </div>

              <div style={{ background: 'var(--bg-input)', borderRadius: 12, padding: '14px 16px', marginBottom: 16 }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#00A651', marginBottom: 10 }}>🟢 EasyPaisa</div>
                <div className="form-group" style={{ marginBottom: 10 }}>
                  <label>Account Name</label>
                  <input
                    type="text"
                    value={easyName}
                    onChange={e => setEasyName(e.target.value)}
                    placeholder="e.g. Muhammad Ali"
                  />
                </div>
                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label>Account Number</label>
                  <input
                    type="tel"
                    value={easyNumber}
                    onChange={e => setEasyNumber(e.target.value)}
                    placeholder="e.g. 0300-7654321"
                  />
                </div>
              </div>

              <button
                onClick={saveNumbers}
                disabled={savingNumbers}
                className="btn-primary"
                style={{ maxWidth: 220 }}
              >
                {savingNumbers ? 'Saving...' : 'Save Payment Details'}
              </button>
            </div>

            {/* Secret Keyword */}
            <div className="card" style={{ padding: 20, marginBottom: 16 }}>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 4 }}>🔑 Secret Search Keyword</div>
              <div style={{ color: 'var(--text-3)', fontSize: 13, marginBottom: 16 }}>
                Type this in the Explore search bar and press Enter to open the admin portal. Current: <strong style={{ color: 'var(--brand)' }}>{savedKeyword}</strong>
              </div>
              <div className="form-group" style={{ marginBottom: 14 }}>
                <label>New Keyword</label>
                <input
                  type="text"
                  value={secretKeyword}
                  onChange={e => setSecretKeyword(e.target.value)}
                  placeholder="e.g. zentro@admin"
                  autoComplete="off"
                  autoCorrect="off"
                  spellCheck="false"
                />
              </div>
              <button
                onClick={saveKeyword}
                disabled={savingKeyword}
                className="btn-primary"
                style={{ maxWidth: 220 }}
              >
                {savingKeyword ? 'Saving...' : 'Save Keyword'}
              </button>
            </div>

            {/* Credentials */}
            <div className="card" style={{ padding: 20, marginBottom: 16 }}>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 700, fontSize: 16, marginBottom: 4 }}>🔐 Change Login Password</div>
              <div style={{ color: 'var(--text-3)', fontSize: 13, marginBottom: 20 }}>
                Stored as SHA-256 hashes — never plain text.
              </div>
              <div className="form-group" style={{ marginBottom: 10 }}>
                <label>New Password</label>
                <input type="password" value={pass1} onChange={e => setPass1(e.target.value)} placeholder="Min 6 characters" />
              </div>
              <div className="form-group" style={{ marginBottom: 20 }}>
                <label>Confirm Password</label>
                <input type="password" value={confirmPass1} onChange={e => setConfirmPass1(e.target.value)} placeholder="Repeat password" />
              </div>
              <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 700, fontSize: 15, marginBottom: 8 }}>🔷 Change Pattern Lock</div>
              <div style={{ color: 'var(--text-3)', fontSize: 13, marginBottom: 14 }}>Draw a new pattern (minimum 4 nodes).</div>
              <AdminPatternSetter
                onPatternSet={(p) => { setNewPattern(p); setPatternSet(true); }}
                onPatternClear={() => { setNewPattern([]); setPatternSet(false); }}
              />
              <button
                onClick={saveCredentials}
                disabled={savingPass}
                className="btn-primary"
                style={{ maxWidth: 220, marginTop: 20 }}
              >
                {savingPass ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Sub-components
// ─────────────────────────────────────────────────────────────────────────────
function PaymentRow({ pay, onReview, processing }) {
  const [note, setNote] = useState('');
  const [expanded, setExpanded] = useState(false);
  const [grantedTier, setGrantedTier] = useState(pay.subscription_tier || 'basic');

  return (
    <div className="card" style={{ padding: 16, marginBottom: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 15, fontFamily: 'Outfit, sans-serif' }}>{pay.shops?.name || '—'}</div>
          <div style={{ color: 'var(--text-3)', fontSize: 13, marginTop: 2 }}>{pay.profiles?.full_name} · {pay.payment_method}</div>
          {pay.subscription_tier && (
            <div style={{ marginTop: 4 }}>
              <span style={{
                padding: '2px 10px', borderRadius: 100, fontSize: 11, fontWeight: 800,
                background: pay.subscription_tier === 'premium' ? 'rgba(255,184,0,0.15)' : pay.subscription_tier === 'pro' ? 'rgba(255,61,0,0.1)' : 'var(--bg-input)',
                color: pay.subscription_tier === 'premium' ? '#FFB800' : pay.subscription_tier === 'pro' ? 'var(--brand)' : 'var(--text-3)',
              }}>
                {pay.subscription_tier?.toUpperCase()} plan requested
              </span>
            </div>
          )}
          <div style={{ color: 'var(--text-3)', fontSize: 12, marginTop: 2 }}>TXN: {pay.transaction_id || '—'}</div>
          <div style={{ color: 'var(--text-3)', fontSize: 12 }}>{new Date(pay.submitted_at).toLocaleDateString()}</div>
          {pay.subscription_tier && (
            <div style={{ marginTop: 6 }}><TierBadge tier={pay.subscription_tier} tiers={{}} /></div>
          )}
        </div>
        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <div style={{ fontWeight: 800, fontSize: 17, color: 'var(--brand)', fontFamily: 'Outfit, sans-serif' }}>Rs. {pay.amount}</div>
          <SubBadge status={pay.status} />
        </div>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        {pay.screenshot_url && (
          <a href={pay.screenshot_url} target="_blank" rel="noreferrer" style={{
            flex: 1, padding: '10px', borderRadius: 12, border: '1.5px solid var(--border)',
            color: 'var(--text-2)', fontWeight: 700, fontSize: 13, textAlign: 'center',
            fontFamily: 'Plus Jakarta Sans, sans-serif',
          }}>📷 Screenshot</a>
        )}
        {pay.status === 'pending' && (
          <button onClick={() => setExpanded(!expanded)} style={{
            flex: 1, padding: '10px', borderRadius: 12, border: 'none',
            background: 'var(--bg-input)', color: 'var(--text)', fontWeight: 700, fontSize: 13,
            fontFamily: 'Plus Jakarta Sans, sans-serif', cursor: 'pointer',
          }}>
            {expanded ? 'Cancel' : 'Review'}
          </button>
        )}
      </div>
      {expanded && pay.status === 'pending' && (
        <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--border)' }}>
          {/* Plan to grant — admin decides regardless of what was requested */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-2)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 }}>
              Grant Plan
              {pay.subscription_tier && (
                <span style={{ marginLeft: 8, fontSize: 11, fontWeight: 600, color: 'var(--text-3)', textTransform: 'none', letterSpacing: 0 }}>
                  (requested: {pay.subscription_tier})
                </span>
              )}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {['basic', 'pro', 'premium'].map(tier => (
                <button
                  key={tier}
                  onClick={() => setGrantedTier(tier)}
                  style={{
                    flex: 1, padding: '10px 0', borderRadius: 12, border: 'none',
                    fontWeight: 700, fontSize: 13, cursor: 'pointer',
                    fontFamily: 'Plus Jakarta Sans, sans-serif',
                    background: grantedTier === tier
                      ? tier === 'premium' ? 'linear-gradient(135deg, #FFB800, #FF6B00)'
                        : tier === 'pro' ? 'linear-gradient(135deg, #FF3D00, #c62800)'
                        : 'var(--brand)'
                      : 'var(--bg-input)',
                    color: grantedTier === tier ? '#fff' : 'var(--text-3)',
                    boxShadow: grantedTier === tier ? '0 2px 10px rgba(0,0,0,0.15)' : 'none',
                  }}
                >
                  {tier === 'premium' ? '⭐' : tier === 'pro' ? '🔥' : '✓'} {tier.charAt(0).toUpperCase() + tier.slice(1)}
                </button>
              ))}
            </div>
          </div>
          <div className="form-group" style={{ marginBottom: 12 }}>
            <label>Admin Note (optional)</label>
            <input value={note} onChange={e => setNote(e.target.value)} placeholder="e.g. Paid Rs.1500 — granted Pro" />
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={() => onReview(pay.id, pay.shop_id, 'approved', note, grantedTier)} disabled={processing} style={{
              flex: 1, padding: '12px', borderRadius: 14, border: 'none',
              background: 'rgba(0,200,100,0.15)', color: '#00C864',
              fontWeight: 700, fontSize: 14, fontFamily: 'Plus Jakarta Sans, sans-serif',
              cursor: processing ? 'not-allowed' : 'pointer', opacity: processing ? 0.6 : 1,
            }}>{processing ? '...' : `Approve as ${grantedTier.toUpperCase()}`}</button>
            <button onClick={() => onReview(pay.id, pay.shop_id, 'rejected', note, null)} disabled={processing} style={{
              flex: 1, padding: '12px', borderRadius: 14, border: 'none',
              background: 'rgba(255,61,0,0.1)', color: 'var(--brand)',
              fontWeight: 700, fontSize: 14, fontFamily: 'Plus Jakarta Sans, sans-serif',
              cursor: processing ? 'not-allowed' : 'pointer', opacity: processing ? 0.6 : 1,
            }}>{processing ? '...' : 'Reject'}</button>
          </div>
        </div>
      )}
    </div>
  );
}

function TierBadge({ tier, tiers }) {
  const colors = {
    basic:   { bg: 'rgba(136,136,136,0.15)', color: '#888' },
    pro:     { bg: 'rgba(255,61,0,0.1)',     color: '#FF3D00' },
    premium: { bg: 'rgba(255,184,0,0.15)',   color: '#FFB800' },
  };
  const icons = { basic: '🥉', pro: '🥈', premium: '🥇' };
  const c = colors[tier] || colors.basic;
  const name = tiers?.[tier]?.name || tier;
  return (
    <span style={{ padding: '4px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: c.bg, color: c.color }}>
      {icons[tier]} {name}
    </span>
  );
}

function StatusBadge({ active, label }) {
  return (
    <span style={{
      padding: '4px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700,
      background: active ? 'rgba(0,200,100,0.12)' : 'rgba(0,0,0,0.06)',
      color: active ? '#00C864' : 'var(--text-3)',
    }}>{label}</span>
  );
}

function SubBadge({ status }) {
  const colors = {
    active:    { bg: 'rgba(0,200,100,0.12)',  color: '#00C864' },
    pending:   { bg: 'rgba(255,184,0,0.15)',  color: '#FFB800' },
    expired:   { bg: 'rgba(0,0,0,0.06)',      color: 'var(--text-3)' },
    suspended: { bg: 'rgba(255,61,0,0.1)',    color: 'var(--brand)' },
    approved:  { bg: 'rgba(0,200,100,0.12)',  color: '#00C864' },
    rejected:  { bg: 'rgba(255,61,0,0.1)',    color: 'var(--brand)' },
  };
  const c = colors[status] || colors.pending;
  return (
    <span style={{ padding: '4px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: c.bg, color: c.color }}>{status}</span>
  );
}

function BookingBadge({ status }) {
  const colors = {
    confirmed: { bg: 'rgba(0,200,100,0.12)', color: '#00C864' },
    pending:   { bg: 'rgba(255,184,0,0.15)', color: '#FFB800' },
    cancelled: { bg: 'rgba(255,61,0,0.1)',   color: 'var(--brand)' },
    completed: { bg: 'rgba(0,0,0,0.06)',     color: 'var(--text-3)' },
  };
  const c = colors[status] || colors.pending;
  return (
    <span style={{ padding: '4px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: c.bg, color: c.color, flexShrink: 0 }}>{status}</span>
  );
}

function RoleBadge({ role }) {
  const colors = {
    admin:    { bg: 'rgba(255,61,0,0.1)',    color: 'var(--brand)' },
    barber:   { bg: 'rgba(0,200,100,0.12)', color: '#00C864' },
    customer: { bg: 'var(--bg-input)',       color: 'var(--text-3)' },
  };
  const c = colors[role] || colors.customer;
  return (
    <span style={{ padding: '4px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: c.bg, color: c.color }}>{role}</span>
  );
}

const BADGE_PRESETS = [
  { label: 'Pro',       color: '#FF3D00' },
  { label: 'Featured',  color: '#7C3AED' },
  { label: 'New',       color: '#0EA5E9' },
  { label: 'Top Rated', color: '#00C864' },
  { label: 'Hot 🔥',    color: '#FF6B00' },
];

function AdminBadgeEditor({ shop, onSave }) {
  const [open, setOpen] = React.useState(false);
  const [badgeText, setBadgeText] = React.useState(shop.custom_badge || '');
  const [badgeColor, setBadgeColor] = React.useState(shop.custom_badge_color || '#FF3D00');
  const [saving, setSaving] = React.useState(false);

  const handleSave = async () => {
    setSaving(true);
    await onSave(shop.id, badgeText.trim(), badgeColor);
    setSaving(false);
    setOpen(false);
  };

  const handleRemove = async () => {
    setSaving(true);
    await onSave(shop.id, '', '');
    setBadgeText('');
    setSaving(false);
    setOpen(false);
  };

  if (!open) return (
    <button
      onClick={() => setOpen(true)}
      style={{
        width: '100%', padding: '8px', borderRadius: 10,
        border: '1.5px dashed var(--border)', background: 'transparent',
        color: 'var(--text-3)', fontWeight: 600, fontSize: 12, cursor: 'pointer',
        marginBottom: 2,
      }}
    >
      🏷 {shop.custom_badge ? `Edit badge: "${shop.custom_badge}"` : 'Add custom badge'}
    </button>
  );

  return (
    <div style={{ background: 'var(--bg-input)', borderRadius: 12, padding: 14, marginBottom: 2 }}>
      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-2)', marginBottom: 10 }}>Custom Badge</div>

      {/* Presets */}
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
        {BADGE_PRESETS.map(p => (
          <button
            key={p.label}
            onClick={() => { setBadgeText(p.label); setBadgeColor(p.color); }}
            style={{
              padding: '4px 10px', borderRadius: 100, border: 'none',
              background: badgeText === p.label ? `${p.color}33` : 'var(--bg-card)',
              color: p.color, fontWeight: 700, fontSize: 11, cursor: 'pointer',
              border: badgeText === p.label ? `1.5px solid ${p.color}` : '1.5px solid var(--border)',
            }}
          >{p.label}</button>
        ))}
      </div>

      {/* Custom text + color */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
        <input
          value={badgeText}
          onChange={e => setBadgeText(e.target.value)}
          placeholder="Badge text (e.g. Pro, Featured)"
          maxLength={15}
          style={{
            flex: 1, padding: '8px 12px', borderRadius: 10,
            border: '1.5px solid var(--border)', background: 'var(--bg-card)',
            color: 'var(--text)', fontSize: 13,
          }}
        />
        <input
          type="color"
          value={badgeColor}
          onChange={e => setBadgeColor(e.target.value)}
          title="Badge color"
          style={{ width: 40, height: 38, borderRadius: 10, border: '1.5px solid var(--border)', cursor: 'pointer', padding: 2, background: 'var(--bg-card)' }}
        />
      </div>

      {/* Preview */}
      {badgeText && (
        <div style={{ marginBottom: 10, display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 11, color: 'var(--text-3)' }}>Preview:</span>
          <span style={{
            padding: '3px 10px', borderRadius: 6,
            background: `linear-gradient(135deg, ${badgeColor}dd, ${badgeColor}99)`,
            fontSize: 10, fontWeight: 900, color: '#fff',
            letterSpacing: 1.5, textTransform: 'uppercase',
          }}>{badgeText}</span>
        </div>
      )}

      <div style={{ display: 'flex', gap: 8 }}>
        <button onClick={handleSave} disabled={saving} style={{ flex: 1, padding: '8px', borderRadius: 10, border: 'none', background: 'rgba(0,200,100,0.15)', color: '#00C864', fontWeight: 700, fontSize: 12, cursor: 'pointer' }}>
          {saving ? '...' : '✓ Save Badge'}
        </button>
        {shop.custom_badge && (
          <button onClick={handleRemove} disabled={saving} style={{ flex: 1, padding: '8px', borderRadius: 10, border: 'none', background: 'rgba(255,61,0,0.1)', color: 'var(--brand)', fontWeight: 700, fontSize: 12, cursor: 'pointer' }}>
            Remove
          </button>
        )}
        <button onClick={() => setOpen(false)} style={{ padding: '8px 14px', borderRadius: 10, border: '1.5px solid var(--border)', background: 'transparent', color: 'var(--text-3)', fontWeight: 600, fontSize: 12, cursor: 'pointer' }}>
          Cancel
        </button>
      </div>
    </div>
  );
}
