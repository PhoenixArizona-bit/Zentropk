import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, uploadImage } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const FULL_DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// ── Inline toggle switch ──────────────────────────────────────────
function Toggle({ checked, onChange }) {
  return (
    <div
      onClick={() => onChange(!checked)}
      style={{
        width: 44, height: 26, borderRadius: 13, cursor: 'pointer', flexShrink: 0,
        background: checked ? 'var(--brand)' : 'var(--bg-input)',
        border: '1.5px solid var(--border)',
        position: 'relative', transition: 'background 0.2s',
      }}
    >
      <div style={{
        position: 'absolute', top: 3,
        left: checked ? 20 : 3,
        width: 16, height: 16, borderRadius: '50%',
        background: checked ? '#fff' : 'var(--text-3)',
        transition: 'left 0.2s',
        boxShadow: '0 1px 4px rgba(0,0,0,0.18)',
      }} />
    </div>
  );
}

// ── Section wrapper ───────────────────────────────────────────────
function Section({ icon, title, children }) {
  return (
    <div style={{ marginBottom: 32 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
        <div style={{
          width: 32, height: 32, borderRadius: 10,
          background: 'var(--brand-glow)', color: 'var(--brand)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16,
        }}>{icon}</div>
        <h2 style={{ fontSize: 16, fontWeight: 800, fontFamily: 'Outfit, sans-serif' }}>{title}</h2>
      </div>
      {children}
    </div>
  );
}

export default function BarberSetup() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  const [shopId, setShopId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [savingHours, setSavingHours] = useState(false);
  const [addingSrv, setAddingSrv] = useState(false);
  const [uploadingImg, setUploadingImg] = useState(false);
  const [toast, setToast] = useState({ type: '', text: '' });

  const [shop, setShop] = useState({
    name: '', description: '', address: '', city: '', phone: '', lat: '', lng: '',
  });
  const [images, setImages] = useState([]);
  const [services, setServices] = useState([]);
  const [newSrv, setNewSrv] = useState({ name: '', price: '', duration_minutes: 30 });
  const [hours, setHours] = useState(
    DAYS.map((_, i) => ({ day_of_week: i, open_time: '09:00', close_time: '20:00', is_closed: i === 0 }))
  );

  useEffect(() => { if (user) loadExisting(); }, [user]);

  const loadExisting = async () => {
    const { data: s } = await supabase.from('shops').select('*').eq('owner_id', user.id).single();
    if (!s) return;
    setShopId(s.id);
    setShop({
      name: s.name || '', description: s.description || '',
      address: s.address || '', city: s.city || '',
      phone: s.phone || '', lat: s.lat ?? '', lng: s.lng ?? '',
    });
    setImages(s.images || []);
    const [{ data: srvs }, { data: hrs }] = await Promise.all([
      supabase.from('services').select('*').eq('shop_id', s.id),
      supabase.from('opening_hours').select('*').eq('shop_id', s.id),
    ]);
    setServices(srvs || []);
    if (hrs?.length) {
      setHours(DAYS.map((_, i) => hrs.find(h => h.day_of_week === i) || { day_of_week: i, open_time: '09:00', close_time: '20:00', is_closed: false }));
    }
  };

  const showToast = (type, text) => {
    setToast({ type, text });
    setTimeout(() => setToast({ type: '', text: '' }), 2800);
  };

  // ── Save shop + auto-navigate on first save ───────────────────
  const saveShop = async () => {
    if (!shop.name.trim() || !shop.address.trim() || !shop.city.trim()) {
      showToast('error', 'Name, address and city are required.');
      return;
    }
    setSaving(true);
    const payload = {
      ...shop,
      images,
      lat: shop.lat !== '' ? parseFloat(shop.lat) : null,
      lng: shop.lng !== '' ? parseFloat(shop.lng) : null,
    };

    let error;
    if (shopId) {
      ({ error } = await supabase.from('shops').update(payload).eq('id', shopId));
    } else {
      const { data, error: insertError } = await supabase
        .from('shops')
        .insert({ ...payload, owner_id: user.id, is_active: false, subscription_status: 'pending' })
        .select()
        .single();
      error = insertError;
      if (data) setShopId(data.id);
    }

    setSaving(false);
    if (error) {
      showToast('error', 'Failed to save: ' + error.message);
    } else {
      showToast('success', 'Shop saved ✓');
    }
  };

  // ── Hours ─────────────────────────────────────────────────────
  const updateHour = (i, field, value) => {
    const updated = [...hours];
    updated[i] = { ...updated[i], [field]: value };
    setHours(updated);
  };

  const saveHours = async () => {
    if (!shopId) { showToast('error', 'Save shop details first.'); return; }
    setSavingHours(true);
    const results = await Promise.all(
      hours.map(h => supabase.from('opening_hours').upsert({ ...h, shop_id: shopId }, { onConflict: 'shop_id,day_of_week' }))
    );
    setSavingHours(false);
    const failed = results.find(r => r.error);
    if (failed) {
      showToast('error', 'Failed to save hours: ' + failed.error.message);
    } else {
      showToast('success', 'Hours saved ✓');
    }
  };

  // ── Services ──────────────────────────────────────────────────
  const addService = async () => {
    if (!shopId) { showToast('error', 'Save shop details first.'); return; }
    if (!newSrv.name.trim() || !newSrv.price) { showToast('error', 'Name and price required.'); return; }
    setAddingSrv(true);
    const { data, error } = await supabase
      .from('services')
      .insert({ ...newSrv, shop_id: shopId, price: parseFloat(newSrv.price), is_active: true })
      .select().single();
    setAddingSrv(false);
    if (error) {
      showToast('error', 'Failed to add service: ' + error.message);
    } else {
      if (data) setServices(prev => [...prev, data]);
      setNewSrv({ name: '', price: '', duration_minutes: 30 });
      showToast('success', 'Service added ✓');
    }
  };

  const removeService = async (id) => {
    const { error } = await supabase.from('services').delete().eq('id', id);
    if (error) { showToast('error', 'Failed to remove service: ' + error.message); return; }
    setServices(prev => prev.filter(s => s.id !== id));
    showToast('success', 'Service removed ✓');
  };

  // ── Images ────────────────────────────────────────────────────
  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file || !shopId) return;
    setUploadingImg(true);
    const path = `${user.id}/${Date.now()}_${file.name}`;
    const { url, error: uploadError } = await uploadImage('shop-images', path, file);
    if (uploadError || !url) {
      showToast('error', 'Image upload failed: ' + (uploadError?.message || 'unknown error'));
    } else {
      const updated = [...images, url];
      setImages(updated);
      const { error: dbError } = await supabase.from('shops').update({ images: updated }).eq('id', shopId);
      if (dbError) showToast('error', 'Saved image but failed to update shop: ' + dbError.message);
      else showToast('success', 'Photo added ✓');
    }
    setUploadingImg(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeImage = async (i) => {
    const updated = images.filter((_, j) => j !== i);
    if (shopId) {
      const { error } = await supabase.from('shops').update({ images: updated }).eq('id', shopId);
      if (error) { showToast('error', 'Failed to remove photo: ' + error.message); return; }
    }
    setImages(updated);
    if (shopId) showToast('success', 'Photo removed ✓');
  };

  return (
    <div className="page fade-up" style={{ padding: '0 20px', paddingBottom: 120 }}>
      {/* Header */}
      <div className="top-header">
        <button onClick={() => navigate(-1)} style={{ background: 'none', border: 'none', color: 'var(--text-2)', fontSize: 22, cursor: 'pointer' }}>←</button>
        <div className="logo-text">Shop <span>Setup</span></div>
        <div style={{ width: 32 }} />
      </div>

      {/* Toast */}
      {toast.text && (
        <div className={`alert alert-${toast.type}`} style={{ marginBottom: 20 }}>{toast.text}</div>
      )}

      {/* ── 1. SHOP DETAILS ── */}
      <Section icon="🏪" title="Shop Details">
        <div className="form-group">
          <label>Shop Name *</label>
          <input value={shop.name} onChange={e => setShop({ ...shop, name: e.target.value })} placeholder="e.g. Royal Cuts" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div className="form-group">
            <label>City *</label>
            <input value={shop.city} onChange={e => setShop({ ...shop, city: e.target.value })} placeholder="Lahore" />
          </div>
          <div className="form-group">
            <label>Phone</label>
            <input value={shop.phone} onChange={e => setShop({ ...shop, phone: e.target.value })} placeholder="03xx-xxxxxxx" type="tel" />
          </div>
        </div>

        <div className="form-group">
          <label>Address *</label>
          <input value={shop.address} onChange={e => setShop({ ...shop, address: e.target.value })} placeholder="Street address" />
        </div>

        <div className="form-group">
          <label>Description</label>
          <textarea
            value={shop.description}
            onChange={e => setShop({ ...shop, description: e.target.value })}
            rows={2}
            placeholder="A short description of your shop..."
            style={{ borderRadius: 14, padding: 14, width: '100%', background: 'var(--bg-input)', border: '1.5px solid var(--border)', color: 'var(--text)', fontSize: 15, fontFamily: 'Plus Jakarta Sans, sans-serif', resize: 'none', outline: 'none' }}
          />
        </div>

        {/* Coordinates — collapsed behind a hint */}
        <div style={{ background: 'var(--bg-input)', borderRadius: 14, padding: '12px 14px', marginBottom: 16, fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>
          📍 <strong>Map pin (optional):</strong> Open{' '}
          <a href="https://www.google.com/maps" target="_blank" rel="noreferrer" style={{ color: 'var(--brand)' }}>Google Maps</a>
          , right-click your shop → copy the two numbers shown.
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div className="form-group">
            <label>Latitude</label>
            <input value={shop.lat} onChange={e => setShop({ ...shop, lat: e.target.value })} placeholder="31.5204" inputMode="decimal" />
          </div>
          <div className="form-group">
            <label>Longitude</label>
            <input value={shop.lng} onChange={e => setShop({ ...shop, lng: e.target.value })} placeholder="74.3587" inputMode="decimal" />
          </div>
        </div>

        <button className="btn-primary" onClick={saveShop} disabled={saving}>
          {saving ? 'Saving...' : shopId ? 'Save Changes' : 'Create Shop'}
        </button>
      </Section>

      {/* ── 2. PHOTOS ── */}
      <Section icon="📷" title="Photos">
        {images.length > 0 && (
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
            {images.map((url, i) => (
              <div key={i} style={{ position: 'relative' }}>
                <img src={url} alt="" style={{ width: 88, height: 68, objectFit: 'cover', borderRadius: 12 }} />
                <button
                  onClick={() => removeImage(i)}
                  style={{ position: 'absolute', top: 3, right: 3, background: 'rgba(0,0,0,0.65)', color: '#fff', border: 'none', borderRadius: '50%', width: 22, height: 22, cursor: 'pointer', fontSize: 13, display: 'flex', alignItems: 'center', justifyContent: 'center', lineHeight: 1 }}
                >×</button>
              </div>
            ))}
          </div>
        )}

        <button
          onClick={() => shopId && fileInputRef.current?.click()}
          disabled={!shopId || uploadingImg}
          style={{
            width: '100%', padding: '14px', borderRadius: 16, cursor: shopId ? 'pointer' : 'not-allowed',
            border: '2px dashed var(--border)', background: 'transparent',
            color: shopId ? 'var(--text-2)' : 'var(--text-3)',
            fontWeight: 600, fontSize: 14, fontFamily: 'Plus Jakarta Sans, sans-serif',
          }}
        >
          {uploadingImg ? '⏳ Uploading...' : !shopId ? '← Save shop details first' : '+ Add Photo'}
        </button>
        <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} style={{ display: 'none' }} />
      </Section>

      {/* ── 3. SERVICES ── */}
      <Section icon="✂️" title="Services">
        {/* Add service row */}
        <div className="card" style={{ padding: 16, marginBottom: 16 }}>
          <div className="form-group" style={{ marginBottom: 12 }}>
            <label>Service Name</label>
            <input
              value={newSrv.name}
              onChange={e => setNewSrv({ ...newSrv, name: e.target.value })}
              placeholder="e.g. Haircut & Beard"
              onKeyDown={e => e.key === 'Enter' && addService()}
            />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
            <div className="form-group" style={{ margin: 0 }}>
              <label>Price (Rs.)</label>
              <input type="number" value={newSrv.price} onChange={e => setNewSrv({ ...newSrv, price: e.target.value })} placeholder="500" inputMode="numeric" />
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label>Duration</label>
              <select value={newSrv.duration_minutes} onChange={e => setNewSrv({ ...newSrv, duration_minutes: parseInt(e.target.value) })}>
                {[15, 20, 30, 45, 60, 90].map(m => <option key={m} value={m}>{m} min</option>)}
              </select>
            </div>
          </div>
          <button className="btn-primary" onClick={addService} disabled={addingSrv || !shopId}>
            {addingSrv ? 'Adding...' : !shopId ? 'Save shop first' : '+ Add Service'}
          </button>
        </div>

        {services.length === 0 ? (
          <p style={{ color: 'var(--text-3)', textAlign: 'center', padding: '20px 0', fontSize: 14 }}>No services yet — add one above.</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {services.map(srv => (
              <div key={srv.id} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '14px 16px', background: 'var(--bg-card)',
                border: '1px solid var(--border)', borderRadius: 16,
              }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{srv.name}</div>
                  <div style={{ color: 'var(--text-3)', fontSize: 13, marginTop: 2 }}>
                    {srv.duration_minutes} min · <span style={{ color: 'var(--brand)', fontWeight: 700 }}>Rs. {srv.price}</span>
                  </div>
                </div>
                <button
                  onClick={() => removeService(srv.id)}
                  style={{ padding: '6px 12px', borderRadius: 10, border: 'none', background: 'rgba(255,61,0,0.1)', color: 'var(--brand)', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}
                >Remove</button>
              </div>
            ))}
          </div>
        )}
      </Section>

      {/* ── 4. OPENING HOURS ── */}
      <Section icon="🕐" title="Opening Hours">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {hours.map((h, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 0', borderBottom: '1px solid var(--border)' }}>
              {/* Day name */}
              <span style={{ width: 36, fontWeight: 700, fontSize: 13, color: h.is_closed ? 'var(--text-3)' : 'var(--text)', flexShrink: 0 }}>
                {DAYS[i]}
              </span>

              {/* Time inputs or "Closed" */}
              {h.is_closed ? (
                <span style={{ flex: 1, color: 'var(--text-3)', fontSize: 13 }}>Closed</span>
              ) : (
                <div style={{ flex: 1, display: 'flex', gap: 6, alignItems: 'center' }}>
                  <input
                    type="time" value={h.open_time}
                    onChange={e => updateHour(i, 'open_time', e.target.value)}
                    style={{ flex: 1, padding: '8px 10px', fontSize: 13, borderRadius: 10, minWidth: 0 }}
                  />
                  <span style={{ color: 'var(--text-3)', fontSize: 12, flexShrink: 0 }}>–</span>
                  <input
                    type="time" value={h.close_time}
                    onChange={e => updateHour(i, 'close_time', e.target.value)}
                    style={{ flex: 1, padding: '8px 10px', fontSize: 13, borderRadius: 10, minWidth: 0 }}
                  />
                </div>
              )}

              {/* Closed toggle */}
              <Toggle checked={h.is_closed} onChange={v => updateHour(i, 'is_closed', v)} />
            </div>
          ))}
        </div>

        <button className="btn-primary" style={{ marginTop: 20 }} onClick={saveHours} disabled={savingHours}>
          {savingHours ? 'Saving...' : 'Save Hours'}
        </button>
      </Section>
    </div>
  );
}
