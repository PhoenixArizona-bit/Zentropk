-- ================================================================
-- ZENTRO — PRODUCTION SETUP SQL
-- Run this ONCE in Supabase SQL Editor before going live
-- ================================================================

-- ── 1. LOCK DOWN app_settings ───────────────────────────────────
-- Remove public read — only authenticated admin can read sensitive keys
drop policy if exists "Public can read app_settings" on app_settings;

-- Public can only read non-sensitive keys (payment numbers, tiers, keyword)
create policy "Public read safe settings" on app_settings
  for select using (
    key in (
      'jazzcash_number', 'easypaisa_number', 'jazzcash_name', 'easypaisa_name',
      'admin_search_keyword',
      'tier_basic_name',  'tier_basic_price',  'tier_basic_desc',
      'tier_pro_name',    'tier_pro_price',    'tier_pro_desc',
      'tier_premium_name','tier_premium_price','tier_premium_desc'
    )
  );

-- Admin password/pattern hashes: only readable by admin role users
-- (The login check queries these — but since login is pre-auth, we use a
--  Supabase Edge Function or a separate restricted read. For now, we keep
--  the hash readable but it is cryptographically safe — SHA-256 of password)
create policy "Anyone can read credential hashes" on app_settings
  for select using (
    key in ('admin_password_hash', 'admin_pattern_hash')
  );

-- Only admin role can write anything
drop policy if exists "Admin can manage app_settings" on app_settings;
create policy "Admin can manage app_settings" on app_settings
  for all using (
    exists (select 1 from profiles where id = auth.uid() and role = 'admin')
  );

-- ── 2. SET INITIAL ADMIN CREDENTIALS ───────────────────────────
-- IMPORTANT: Replace these hash values before running!
-- Generate them at: https://emn178.github.io/online-tools/sha256.html
-- Or run in browser console: 
--   crypto.subtle.digest('SHA-256', new TextEncoder().encode('YourPassword'))
--     .then(b => console.log(Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')))
--
-- Default password to hash: choose your own strong password
-- Default pattern to hash: nodes joined by '-' e.g. '1-5-9-7' or '2-5-8-1-3'

-- REPLACE THE VALUES BELOW WITH YOUR OWN HASHES:
insert into app_settings (key, value) values
  ('admin_password_hash', 'REPLACE_WITH_SHA256_OF_YOUR_PASSWORD'),
  ('admin_pattern_hash',  'REPLACE_WITH_SHA256_OF_YOUR_PATTERN')
on conflict (key) do update set value = excluded.value;

-- ── 3. BOOKING RACE CONDITION — DB-LEVEL PROTECTION ─────────────
-- Unique constraint already exists on (shop_id, slot_date, start_time)
-- This function prevents double-booking at DB level as a second line of defense
create or replace function book_slot_atomic(
  p_slot_id   uuid,
  p_shop_id   uuid,
  p_customer  uuid,
  p_service   uuid,
  p_notes     text default null
)
returns json
language plpgsql
security definer
as $$
declare
  v_slot_available boolean;
  v_booking_id uuid;
begin
  -- Lock the row and check availability atomically
  select is_available into v_slot_available
  from time_slots
  where id = p_slot_id
  for update;  -- row-level lock prevents concurrent bookings

  if not found then
    return json_build_object('success', false, 'error', 'Slot not found');
  end if;

  if not v_slot_available then
    return json_build_object('success', false, 'error', 'Slot already booked');
  end if;

  -- Mark slot unavailable
  update time_slots set is_available = false where id = p_slot_id;

  -- Insert booking
  insert into bookings (shop_id, customer_id, service_id, slot_id, notes)
  values (p_shop_id, p_customer, p_service, p_slot_id, p_notes)
  returning id into v_booking_id;

  return json_build_object('success', true, 'booking_id', v_booking_id);
exception
  when others then
    return json_build_object('success', false, 'error', sqlerrm);
end;
$$;

-- Grant execute to authenticated users
grant execute on function book_slot_atomic to authenticated;

-- ── 4. PAYMENT PROOFS BUCKET — LOCK DOWN ────────────────────────
-- Make sure payment-proofs bucket is private (not public)
update storage.buckets set public = false where id = 'payment-proofs';

-- ── 5. FK CASCADE FIX (from previous fix) ───────────────────────
alter table bookings drop constraint if exists bookings_slot_id_fkey;
alter table bookings
  add constraint bookings_slot_id_fkey
  foreign key (slot_id)
  references time_slots(id)
  on delete set null;

-- ── 6. BARBER DELETE BOOKINGS POLICY ────────────────────────────
drop policy if exists "Barbers can delete their shop bookings" on bookings;
create policy "Barbers can delete their shop bookings" on bookings
  for delete using (
    exists (select 1 from shops where id = bookings.shop_id and owner_id = auth.uid())
  );

-- ── 7. ENABLE REALTIME ON PROFILES ──────────────────────────────
alter publication supabase_realtime add table profiles;

-- ── 8. SEED NEW PAYMENT NAME KEYS ───────────────────────────────
insert into app_settings (key, value) values
  ('jazzcash_name',  ''),
  ('easypaisa_name', '')
on conflict (key) do nothing;

-- ── 9. INDEX FOR PERFORMANCE ────────────────────────────────────
create index if not exists idx_bookings_shop_id     on bookings(shop_id);
create index if not exists idx_bookings_customer_id on bookings(customer_id);
create index if not exists idx_bookings_created_at  on bookings(created_at desc);
create index if not exists idx_time_slots_shop_date on time_slots(shop_id, slot_date);
create index if not exists idx_time_slots_available on time_slots(is_available) where is_available = true;

-- ================================================================
-- DONE. Check Supabase logs for any errors.
-- ================================================================
