# ✂ Zentro — Barber Booking Platform
### Complete Setup Guide

---

## What's Included

| Feature | Status |
|---------|--------|
| Customer map view (Leaflet + OpenStreetMap) | ✅ Free, no API key |
| Shop listing with photos & services | ✅ |
| Time slot booking system | ✅ |
| Customer reviews | ✅ |
| Barber portal (bookings, setup, slot manager) | ✅ |
| Admin portal (full control) | ✅ |
| JazzCash / EasyPaisa payment system | ✅ Manual approval |
| Supabase backend (free tier) | ✅ |
| Netlify hosting | ✅ Free |

---

## Step 1 — Set Up Supabase (Free Database)

1. Go to **https://supabase.com** and create a free account
2. Click **New Project**, give it a name like "zentro"
3. Wait for it to set up (~2 min)
4. Go to **SQL Editor** (left sidebar)
5. Paste the entire contents of `supabase_schema.sql` and click **Run**
6. Go to **Storage** → Create two buckets:
   - `shop-images` — set to **Public**
   - `payment-proofs` — set to **Private**
7. Go to **Settings → API**
8. Copy your **Project URL** and **anon public** key

---

## Step 2 — Configure Environment Variables

1. Copy `.env.example` to `.env`:
   ```
   cp .env.example .env
   ```
2. Open `.env` and fill in your values:
   ```
   REACT_APP_SUPABASE_URL=https://your-project-id.supabase.co
   REACT_APP_SUPABASE_ANON_KEY=your-anon-key-here
   ```

---

## Step 3 — Create Your Admin Account

1. Run the app locally: `npm install && npm start`
2. Go to `/register` and register with your email
3. In Supabase → **Table Editor** → `profiles` table
4. Find your user and change `role` from `customer` to `admin`
5. Now go to `/admin` — you have full admin access

---

## Step 4 — Deploy to Netlify

1. Push this project to **GitHub**
2. Go to **https://netlify.com** → New Site → Import from GitHub
3. Build settings:
   - Build command: `npm run build`
   - Publish directory: `build`
4. Go to **Site Settings → Environment Variables** and add:
   - `REACT_APP_SUPABASE_URL` = your Supabase URL
   - `REACT_APP_SUPABASE_ANON_KEY` = your anon key
5. Deploy! ✅

---

## How Barbers Register & Pay

1. Barber goes to `/register?role=barber`
2. After registering, they set up their shop at `/barber/setup`
3. Shop is created but **NOT visible** until admin approves + subscription active
4. Barber goes to `/barber/payment`
5. They send **Rs. 500** to JazzCash/EasyPaisa: **0134-8433928**
6. They enter Transaction ID + upload screenshot
7. **You review in Admin Portal → Payments → Approve**
8. Shop automatically becomes active and visible on the map ✅

---

## Payment Numbers in the App

Both payment numbers are set to: **0134-8433928**

To change the monthly fee, search for `MONTHLY_FEE = 500` in:
- `src/pages/BarberPayment.js`

---

## Map Setup (Zero Configuration Needed)

The app uses **Leaflet + OpenStreetMap**:
- ✅ 100% free
- ✅ No API key
- ✅ No credit card
- ✅ Works out of the box

Default map center is **Lahore** (31.5204, 74.3587). To change it, edit `src/pages/Shops.js`:
```js
const [center] = useState([31.5204, 74.3587]); // Change to your city
```

To get coordinates for a shop: go to Google Maps, right-click any location, and the coordinates appear at the top. Copy them.

---

## User Roles

| Role | Access |
|------|--------|
| `customer` | Browse shops, book, leave reviews |
| `barber` | Dashboard, setup, slot manager, payment |
| `admin` | Everything — shops, payments, users, bookings |

---

## File Structure

```
src/
  pages/
    Home.js           — Landing page
    Login.js          — Login
    Register.js       — Register (customer or barber)
    Shops.js          — Map + list of shops
    ShopDetail.js     — Book a slot + reviews
    BarberDashboard.js — Barber home
    BarberSetup.js    — Shop details, services, hours
    BarberSlots.js    — Time slot manager
    BarberPayment.js  — JazzCash/EasyPaisa submission
    AdminPortal.js    — Full admin control
    MyBookings.js     — Customer booking history
  components/
    Navbar.js
  hooks/
    useAuth.js        — Auth context
  lib/
    supabase.js       — Supabase client + helpers
  styles/
    global.css
```
