import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

// ── Default fallback if plans_config hasn't been saved yet ───────────────────
const DEFAULTS = {
  basic:   { name: 'Basic',   price: 999,  photos: 3,  qr: false, badge: false, priority: false },
  pro:     { name: 'Pro',     price: 2499, photos: 10, qr: true,  badge: false, priority: true  },
  premium: { name: 'Premium', price: 4999, photos: 30, qr: true,  badge: true,  priority: true  },
};

/**
 * Returns live plan perks for a specific shop's tier.
 * Reads plans_config from app_settings so admin changes apply instantly.
 *
 * Usage:
 *   const { perks, plansConfig, loading } = usePlanPerks(shop?.subscription_tier);
 *   perks.qr       → true/false
 *   perks.photos   → 5, 10, 30 etc.
 *   perks.badge    → true/false
 *   perks.priority → true/false
 */
export function usePlanPerks(tier) {
  const [plansConfig, setPlansConfig] = useState(DEFAULTS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from('app_settings')
      .select('value')
      .eq('key', 'plans_config')
      .maybeSingle()
      .then(({ data }) => {
        if (data?.value) {
          try {
            const parsed = JSON.parse(data.value);
            // Merge with defaults so any missing fields still have a sensible value
            const merged = {};
            for (const t of ['basic', 'pro', 'premium']) {
              merged[t] = { ...DEFAULTS[t], ...(parsed[t] || {}) };
            }
            setPlansConfig(merged);
          } catch {}
        }
        setLoading(false);
      });
  }, []);

  const perks = plansConfig[tier] || plansConfig['basic'];

  return { perks, plansConfig, loading };
}
