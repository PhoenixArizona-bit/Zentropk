import { useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';

const VAPID_PUBLIC_KEY = 'BOkEgSbaLyuDuXwjC-8VtQ6G3wRmA1ItNHPnCS_k8TuL9CsKVD6uEZ-J9ghv_L4s5hu1q2BrpysawZcpNeQRFqE';

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64  = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw     = window.atob(base64);
  return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
}

export function usePush(userId) {
  const asked = useRef(false);

  useEffect(() => {
    if (!userId || asked.current) return;
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;

    // Don't ask inside WebView / Appilix
    const ua = navigator.userAgent;
    if (/\bwv\b/.test(ua) || /Version\/[\d.]+ Chrome/.test(ua)) return;

    asked.current = true;

    // Small delay so app loads first
    const t = setTimeout(() => registerPush(userId), 3000);
    return () => clearTimeout(t);
  }, [userId]);
}

async function registerPush(userId) {
  try {
    // Register SW
    const reg = await navigator.serviceWorker.register('/sw.js');
    await navigator.serviceWorker.ready;

    // Check existing permission
    if (Notification.permission === 'denied') return;

    // Request permission
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') return;

    // Subscribe
    const sub = await reg.pushManager.subscribe({
      userVisibleOnly:      true,
      applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
    });

    const subJson = sub.toJSON();

    // Save to Supabase
    await supabase.from('push_subscriptions').upsert({
      user_id:  userId,
      endpoint: subJson.endpoint,
      p256dh:   subJson.keys.p256dh,
      auth:     subJson.keys.auth,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'endpoint' });

  } catch (err) {
    console.warn('[Push] Registration failed:', err);
  }
}
