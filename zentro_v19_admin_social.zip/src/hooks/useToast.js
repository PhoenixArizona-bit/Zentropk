import { useState, useCallback } from 'react';

export function useToast() {
  const [toast, setToast] = useState(null);

  const showToast = useCallback((type, text) => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 3000);
  }, []);

  const icon = () => {
    if (toast?.type === 'success') return (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
    );
    if (toast?.type === 'error') return (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    );
    return (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
    );
  };

  const ToastEl = toast ? (
    <div style={{
      position: 'fixed', bottom: 90, left: '50%', transform: 'translateX(-50%)',
      background: toast.type === 'success' ? 'var(--brand)' : toast.type === 'error' ? 'var(--error)' : 'var(--bg-card)',
      color: '#fff', padding: '10px 18px', borderRadius: 100, zIndex: 9999,
      display: 'flex', alignItems: 'center', gap: 8,
      fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 14,
      boxShadow: 'var(--shadow-lg)', whiteSpace: 'nowrap',
    }}>
      {icon()} {toast.text}
    </div>
  ) : null;

  return { showToast, ToastEl };
}
