import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

// ── Brand-resistant SVG social icons ─────────────────────────────────────────
function TikTokIcon({ size = 20, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.19 8.19 0 0 0 4.79 1.53V6.78a4.85 4.85 0 0 1-1.02-.09z"/>
    </svg>
  );
}

function InstagramIcon({ size = 20, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" xmlns="http://www.w3.org/2000/svg">
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
    </svg>
  );
}

function FacebookIcon({ size = 20, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg">
      <path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.235 2.686.235v2.97h-1.514c-1.491 0-1.956.93-1.956 1.883v2.268h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/>
    </svg>
  );
}

function WhatsAppIcon({ size = 20, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
    </svg>
  );
}

function YouTubeIcon({ size = 20, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg">
      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
    </svg>
  );
}

function TwitterXIcon({ size = 20, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.742l7.745-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
    </svg>
  );
}

export const SOCIAL_PLATFORMS = [
  { key: 'tiktok',    label: 'TikTok',    Icon: TikTokIcon,    color: '#010101', placeholder: 'https://tiktok.com/@zentropk_official' },
  { key: 'instagram', label: 'Instagram', Icon: InstagramIcon, color: '#E1306C', placeholder: 'https://instagram.com/zentropk' },
  { key: 'facebook',  label: 'Facebook',  Icon: FacebookIcon,  color: '#1877F2', placeholder: 'https://facebook.com/zentropk' },
  { key: 'whatsapp',  label: 'WhatsApp',  Icon: WhatsAppIcon,  color: '#25D366', placeholder: 'https://wa.me/923001234567' },
  { key: 'youtube',   label: 'YouTube',   Icon: YouTubeIcon,   color: '#FF0000', placeholder: 'https://youtube.com/@zentropk' },
  { key: 'twitter',   label: 'X (Twitter)', Icon: TwitterXIcon, color: '#000000', placeholder: 'https://x.com/zentropk' },
];

// ── Fetch social links from app_settings ─────────────────────────────────────
let _cachedSocials = null;
let _cacheTs = 0;

export async function fetchSocialLinks() {
  if (_cachedSocials && Date.now() - _cacheTs < 5 * 60 * 1000) return _cachedSocials;
  const { data } = await supabase
    .from('app_settings')
    .select('value')
    .eq('key', 'social_links')
    .maybeSingle();
  try {
    _cachedSocials = data?.value ? JSON.parse(data.value) : {};
  } catch { _cachedSocials = {}; }
  _cacheTs = Date.now();
  return _cachedSocials;
}

export function invalidateSocialCache() { _cachedSocials = null; }

// ── SocialBar component ───────────────────────────────────────────────────────
export default function SocialBar({ style = {} }) {
  const [links, setLinks] = useState({});

  useEffect(() => {
    fetchSocialLinks().then(setLinks);
  }, []);

  const active = SOCIAL_PLATFORMS.filter(p => links[p.key]?.enabled && links[p.key]?.url?.trim());
  if (active.length === 0) return null;

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      gap: 12, flexWrap: 'wrap', padding: '20px 0 8px',
      ...style,
    }}>
      {active.map(({ key, label, Icon, color }) => (
        <a
          key={key}
          href={links[key].url}
          target="_blank"
          rel="noopener noreferrer"
          title={label}
          style={{
            width: 42, height: 42, borderRadius: 13,
            background: 'var(--bg-input)',
            border: '1.5px solid var(--border)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: color, transition: 'all 0.18s',
            textDecoration: 'none', flexShrink: 0,
          }}
          onMouseEnter={e => {
            e.currentTarget.style.borderColor = color;
            e.currentTarget.style.background = color + '18';
            e.currentTarget.style.transform = 'translateY(-2px)';
          }}
          onMouseLeave={e => {
            e.currentTarget.style.borderColor = 'var(--border)';
            e.currentTarget.style.background = 'var(--bg-input)';
            e.currentTarget.style.transform = 'translateY(0)';
          }}
        >
          <Icon size={18} color={color} />
        </a>
      ))}
    </div>
  );
}
