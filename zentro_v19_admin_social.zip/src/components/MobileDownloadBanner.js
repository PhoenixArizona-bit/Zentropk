import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';

const APKPURE_URL = 'https://apkpure.com/zentro/com.zentro.app/download';

const IconDownload = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
    <polyline points="7 10 12 15 17 10"/>
    <line x1="12" y1="15" x2="12" y2="3"/>
  </svg>
);

const IconClose = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
);

function isAndroidBrowser() {
  const ua = navigator.userAgent;

  // Skip if any WebView signal present
  const isWebView = (
    /\bwv\b/.test(ua) ||                          // standard Android WebView token
    /Version\/[\d.]+ Chrome/.test(ua) ||           // WebView pattern: Version/x Chrome
    ua.includes('Appilix') ||
    ua.includes('WebView') ||
    ua.includes('com.zentro.app') ||               // Zentro's own APK WebView UA
    // URL param set by Appilix or any wrapper
    new URLSearchParams(window.location.search).get('source') === 'app' ||
    new URLSearchParams(window.location.search).has('appilix') ||
    // If opened standalone (added to home screen as PWA)
    window.navigator.standalone === true ||
    window.matchMedia('(display-mode: standalone)').matches
  );

  if (isWebView) return false;
  return /Android/i.test(ua);
}

export default function MobileDownloadBanner() {
  const [visible, setVisible]     = useState(false);
  const [countdown, setCountdown] = useState(10);
  const location  = useLocation();
  const countRef  = useRef(null);

  // Don't show on /download page itself
  const isDownloadPage = location.pathname === '/download';

  useEffect(() => {
    if (!isAndroidBrowser() || isDownloadPage) return;

    // Check if user already dismissed this session
    if (sessionStorage.getItem('zentro_banner_dismissed')) return;

    // Small delay before showing
    const show = setTimeout(() => setVisible(true), 1500);
    return () => clearTimeout(show);
  }, [isDownloadPage]);

  useEffect(() => {
    if (!visible) return;

    setCountdown(10);
    countRef.current = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(countRef.current);
          window.open(APKPURE_URL, '_blank', 'noopener,noreferrer');
          setVisible(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(countRef.current);
  }, [visible]);

  const dismiss = () => {
    sessionStorage.setItem('zentro_banner_dismissed', '1');
    clearInterval(countRef.current);
    setVisible(false);
  };

  const goDownload = () => {
    clearInterval(countRef.current);
    setVisible(false);
    window.open(APKPURE_URL, '_blank', 'noopener,noreferrer');
  };

  if (!visible) return null;

  return (
    <div style={s.overlay}>
      <div style={s.banner}>
        {/* Progress bar */}
        <div style={s.progressTrack}>
          <div
            style={{
              ...s.progressBar,
              width: `${(countdown / 10) * 100}%`,
              transition: 'width 1s linear',
            }}
          />
        </div>

        <div style={s.row}>
          {/* App icon */}
          <div style={s.appIcon}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0080FF" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
              <line x1="20" y1="4" x2="8.12" y2="15.88"/>
              <line x1="14.47" y1="14.48" x2="20" y2="20"/>
              <line x1="8.12" y1="8.12" x2="12" y2="12"/>
            </svg>
          </div>

          {/* Text */}
          <div style={s.textBlock}>
            <div style={s.title}>
              <span><span style={s.white}>Zen</span><span style={s.blue}>tro</span></span>
              <span style={s.appBadge}>App</span>
            </div>
            <div style={s.sub}>Download karo — barber booking aasaan karo</div>
          </div>

          {/* Countdown + close */}
          <div style={s.actions}>
            <button style={s.closeBtn} onClick={dismiss}>
              <IconClose />
            </button>
          </div>
        </div>

        <div style={s.bottomRow}>
          <span style={s.countdownText}>
            {countdown}s mein redirect ho raha hai...
          </span>
          <button style={s.dlBtn} onClick={goDownload}>
            <IconDownload />
            <span>Download</span>
          </button>
        </div>
      </div>
    </div>
  );
}

const s = {
  overlay: {
    position: 'fixed',
    bottom: 72, // above bottom nav
    left: 12,
    right: 12,
    zIndex: 9999,
    animation: 'slideUp 0.35s cubic-bezier(0.34,1.56,0.64,1)',
  },
  banner: {
    background: '#060E1E',
    border: '1px solid rgba(0,128,255,0.3)',
    borderRadius: 20,
    padding: '12px 14px 14px',
    boxShadow: '0 8px 40px rgba(0,0,0,0.5), 0 0 0 1px rgba(0,128,255,0.1)',
    overflow: 'hidden',
    position: 'relative',
  },
  progressTrack: {
    height: 2,
    background: 'rgba(0,128,255,0.15)',
    borderRadius: 2,
    marginBottom: 12,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    background: 'linear-gradient(90deg, #0080FF, #00c6ff)',
    borderRadius: 2,
  },
  row: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
  },
  appIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    background: 'rgba(0,128,255,0.1)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    border: '1px solid rgba(0,128,255,0.2)',
  },
  textBlock: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    fontFamily: "'Sora', sans-serif",
    fontWeight: 700,
    fontSize: 16,
    display: 'flex',
    alignItems: 'center',
    gap: 6,
    letterSpacing: '-0.3px',
  },
  white: { color: '#fff', letterSpacing: '-0.3px' },
  blue:  { color: '#0080FF', letterSpacing: '-0.3px' },
  appBadge: {
    fontSize: 10,
    fontWeight: 600,
    background: 'rgba(0,128,255,0.15)',
    color: '#0080FF',
    borderRadius: 6,
    padding: '2px 7px',
    fontFamily: "'Sora', sans-serif",
  },
  sub: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.45)',
    marginTop: 2,
    lineHeight: 1.4,
  },
  actions: {
    flexShrink: 0,
  },
  closeBtn: {
    background: 'rgba(255,255,255,0.08)',
    border: 'none',
    borderRadius: 8,
    width: 30,
    height: 30,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    color: 'rgba(255,255,255,0.5)',
  },
  bottomRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 12,
    paddingTop: 10,
    borderTop: '1px solid rgba(255,255,255,0.06)',
  },
  countdownText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.35)',
  },
  dlBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    background: 'linear-gradient(135deg, #0080FF, #0066cc)',
    color: '#fff',
    border: 'none',
    borderRadius: 50,
    padding: '8px 16px',
    fontSize: 13,
    fontWeight: 700,
    fontFamily: "'Sora', sans-serif",
    cursor: 'pointer',
    boxShadow: '0 4px 14px rgba(0,128,255,0.35)',
  },
};
