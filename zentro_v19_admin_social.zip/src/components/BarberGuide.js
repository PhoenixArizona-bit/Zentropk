// BarberGuide — permanent in-app guide for barbers
// Shown as a "Guide" tab inside the barber Account tabs

const GUIDE_SECTIONS = [
  {
    title: 'Shop Setup',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
        <polyline points="9 22 9 12 15 12 15 22"/>
      </svg>
    ),
    steps: [
      { label: 'Account → Setup tab mein jao' },
      { label: 'Shop naam, address, aur city fill karo' },
      { label: 'Map par apni exact location pin karo' },
      { label: 'Kam se kam 1 service add karo (naam + price)' },
      { label: 'Photos upload karo (acha cover photo lagao)' },
      { label: 'Save karo — profile ready!' },
    ],
  },
  {
    title: 'Time Slots',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <polyline points="12 6 12 12 16 14"/>
      </svg>
    ),
    steps: [
      { label: 'Account → Slots tab mein jao' },
      { label: 'Date select karo jis din kaam karna hai' },
      { label: 'Start time aur end time set karo' },
      { label: 'Slot duration choose karo (e.g. 30 min)' },
      { label: 'Generate Slots press karo' },
      { label: 'Customers ab woh slots book kar sakenge' },
    ],
  },
  {
    title: 'Payment & Activation',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
        <line x1="1" y1="10" x2="23" y2="10"/>
      </svg>
    ),
    steps: [
      { label: 'Account → Payment tab mein jao' },
      { label: 'Plan select karo: Basic / Pro / Premium' },
      { label: 'JazzCash ya Easypaisa number par amount bhejo' },
      { label: 'Transaction ID aur screenshot upload karo' },
      { label: 'Admin 24 ghante mein approve karta hai' },
      { label: 'Approve hone par shop live ho jaayegi!' },
    ],
  },
  {
    title: 'Bookings Manage Karo',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
        <line x1="16" y1="2" x2="16" y2="6"/>
        <line x1="8" y1="2" x2="8" y2="6"/>
        <line x1="3" y1="10" x2="21" y2="10"/>
      </svg>
    ),
    steps: [
      { label: 'Dashboard tab mein Today ke bookings nazar aate hain' },
      { label: 'Pending booking: Confirm ya Cancel karo' },
      { label: 'Customer aane ke baad Mark Complete karo' },
      { label: 'Upcoming tab mein future bookings hain' },
      { label: 'Past tab mein history rehti hai' },
    ],
  },
  {
    title: 'Pro Tips',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FFB800" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
      </svg>
    ),
    steps: [
      { label: 'Achi photos lagate ho toh zyada bookings milti hain' },
      { label: 'Slots har roz update karo — customers active shops prefer karte hain' },
      { label: 'Premium plan lene par priority listing milti hai (zyada visibility!)' },
      { label: 'QR code print karo aur shop par lagao — walk-in customers seedha book kar sakte hain' },
      { label: 'Har customer ko confirm karo — cancelled bookings rating affect karti hain' },
    ],
  },
  {
    title: 'Plans Comparison',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="12" y1="20" x2="12" y2="10"/>
        <line x1="18" y1="20" x2="18" y2="4"/>
        <line x1="6" y1="20" x2="6" y2="16"/>
      </svg>
    ),
    table: [
      { feature: 'Monthly Price',     basic: 'Rs 999',    pro: 'Rs 2,499',  premium: 'Rs 4,999' },
      { feature: 'Photos Upload',     basic: '3',         pro: '10',        premium: '30' },
      { feature: 'QR Code',           basic: '—',         pro: '✓',         premium: '✓' },
      { feature: 'Priority Listing',  basic: '—',         pro: '✓',         premium: '✓' },
      { feature: 'Premium Badge',     basic: '—',         pro: '—',         premium: '✓' },
    ],
  },
];

function CheckIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2.5" strokeLinecap="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>
  );
}

function GuideSection({ section }) {
  const [open, setOpen] = useState(false);

  return (
    <div style={{
      borderRadius: 16, overflow: 'hidden',
      border: `1.5px solid ${open ? 'var(--border-brand)' : 'var(--border)'}`,
      background: 'var(--bg-card)', marginBottom: 10,
      transition: 'border-color 0.2s',
    }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', background: 'none', border: 'none', cursor: 'pointer',
          padding: '14px 16px',
          display: 'flex', alignItems: 'center', gap: 12, textAlign: 'left',
          color: 'var(--text-1)',
        }}
      >
        <div style={{
          width: 38, height: 38, borderRadius: 12, flexShrink: 0,
          background: 'var(--brand-glow)', border: '1px solid var(--border-brand)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {section.icon}
        </div>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, flex: 1 }}>
          {section.title}
        </span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round"
          style={{ transition: 'transform 0.25s', transform: open ? 'rotate(180deg)' : 'rotate(0deg)', flexShrink: 0 }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      {open && (
        <div style={{ padding: '0 16px 16px' }}>
          {section.table ? (
            // Plans comparison table
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr>
                    {['Feature', 'Basic', 'Pro', 'Premium'].map((h, i) => (
                      <th key={h} style={{
                        padding: '8px 6px', textAlign: i === 0 ? 'left' : 'center',
                        fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 11,
                        color: i === 0 ? 'var(--text-3)' : ['', '#8EA0BC', 'var(--brand)', '#FFB800'][i],
                        borderBottom: '1.5px solid var(--border)',
                        textTransform: 'uppercase', letterSpacing: 0.5,
                      }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {section.table.map((row, i) => (
                    <tr key={i}>
                      <td style={{ padding: '9px 6px', color: 'var(--text-2)', fontWeight: 600, borderBottom: '1px solid var(--border)' }}>{row.feature}</td>
                      {[row.basic, row.pro, row.premium].map((val, j) => (
                        <td key={j} style={{
                          padding: '9px 6px', textAlign: 'center',
                          color: val === '—' ? 'var(--text-3)' : val === '✓' ? 'var(--brand)' : 'var(--text-1)',
                          fontWeight: 700, borderBottom: '1px solid var(--border)',
                        }}>{val}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            // Step list
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 4 }}>
              {section.steps.map((step, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                  <div style={{
                    width: 22, height: 22, borderRadius: 7, flexShrink: 0,
                    background: 'var(--brand-glow)', border: '1px solid var(--border-brand)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    marginTop: 1,
                  }}>
                    <span style={{ fontSize: 10, fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--brand)' }}>{i + 1}</span>
                  </div>
                  <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.55, fontFamily: 'var(--font-display)', fontWeight: 500, flex: 1 }}>
                    {step.label}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

import { useState } from 'react';

export default function BarberGuide() {
  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <p style={{ fontSize: 11, fontWeight: 800, letterSpacing: 1.2, textTransform: 'uppercase', color: 'var(--brand)', marginBottom: 4, fontFamily: 'var(--font-display)' }}>
          Barber Guide
        </p>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: 'var(--text-1)', marginBottom: 6 }}>
          Sab Kuch Seekho
        </h2>
        <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5, fontFamily: 'var(--font-display)' }}>
          Neeche har section tap karo — step-by-step guide hai.
        </p>
      </div>

      {GUIDE_SECTIONS.map((section, i) => (
        <GuideSection key={i} section={section} />
      ))}

      <div style={{ height: 20 }} />
    </div>
  );
}
