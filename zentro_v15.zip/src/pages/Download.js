import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

const APK_URL = 'https://drive.google.com/uc?export=download&id=1QqrshsimmDX-L6QWCELHiNhgFBsEWwID';

// ── Confetti ──────────────────────────────────────────────────────
const COLORS = ['#0080FF', '#00c6ff', '#ffffff', '#004FC4', '#60b8ff', '#0066cc'];

function Confetti({ active, onDone }) {
  const canvasRef = useRef(null);
  const rafRef    = useRef(null);
  const pieces    = useRef([]);

  useEffect(() => {
    if (!active) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;

    // Spawn pieces
    pieces.current = Array.from({ length: 120 }, (_, i) => ({
      x:    Math.random() * canvas.width,
      y:    -10 - Math.random() * 100,
      w:    6 + Math.random() * 8,
      h:    3 + Math.random() * 4,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      rot:  Math.random() * Math.PI * 2,
      vx:   (Math.random() - 0.5) * 4,
      vy:   3 + Math.random() * 5,
      vr:   (Math.random() - 0.5) * 0.2,
      opacity: 1,
    }));

    let done = false;
    const tick = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      let alive = 0;
      for (const p of pieces.current) {
        p.x  += p.vx;
        p.y  += p.vy;
        p.rot += p.vr;
        p.vy += 0.15; // gravity
        if (p.y > canvas.height * 0.7) p.opacity -= 0.03;
        if (p.opacity <= 0) continue;
        alive++;
        ctx.save();
        ctx.globalAlpha = Math.max(0, p.opacity);
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        ctx.restore();
      }
      if (alive > 0) {
        rafRef.current = requestAnimationFrame(tick);
      } else if (!done) {
        done = true;
        onDone?.();
      }
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [active, onDone]);

  if (!active) return null;
  return (
    <canvas ref={canvasRef} style={{
      position: 'fixed', inset: 0, zIndex: 99999,
      pointerEvents: 'none',
    }} />
  );
}

// ── SVG Icons ────────────────────────────────────────────────────
const IconDownload = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
    <polyline points="7 10 12 15 17 10"/>
    <line x1="12" y1="15" x2="12" y2="3"/>
  </svg>
);

const IconMap = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0080FF" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
    <circle cx="12" cy="10" r="3"/>
  </svg>
);

const IconCalendar = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0080FF" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="3"/>
    <line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/>
    <line x1="3" y1="10" x2="21" y2="10"/>
    <rect x="8" y="14" width="3" height="3" rx="0.5" fill="#0080FF" stroke="none"/>
  </svg>
);

const IconQR = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0080FF" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
    <rect x="3" y="14" width="7" height="7" rx="1"/>
    <rect x="5" y="5" width="3" height="3" fill="#0080FF" stroke="none" rx="0.3"/>
    <rect x="16" y="5" width="3" height="3" fill="#0080FF" stroke="none" rx="0.3"/>
    <rect x="5" y="16" width="3" height="3" fill="#0080FF" stroke="none" rx="0.3"/>
    <line x1="14" y1="14" x2="14" y2="14"/><rect x="14" y="14" width="3" height="3" rx="0.5"/>
    <line x1="18" y1="14" x2="21" y2="14"/><line x1="21" y1="14" x2="21" y2="21"/>
    <line x1="14" y1="18" x2="18" y2="18"/><line x1="18" y1="18" x2="18" y2="21"/>
  </svg>
);

const IconBell = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0080FF" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
    <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
  </svg>
);

const IconStar = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="#0080FF" stroke="#0080FF" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
  </svg>
);

const IconScissors = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0080FF" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
    <line x1="20" y1="4" x2="8.12" y2="15.88"/>
    <line x1="14.47" y1="14.48" x2="20" y2="20"/>
    <line x1="8.12" y1="8.12" x2="12" y2="12"/>
  </svg>
);

const IconAndroid = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.523 15.341a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5zm-11.046 0a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5zM3.547 7.5h16.906A1.547 1.547 0 0 1 22 9.047v6.406A1.547 1.547 0 0 1 20.453 17H3.547A1.547 1.547 0 0 1 2 15.453V9.047A1.547 1.547 0 0 1 3.547 7.5zM15.5 3.5l1.5 2.5H7L8.5 3.5m3.5-1 .5.866M12 2.5l-.5.866"/>
    <path d="M8.5 3.5 7 6h10l-1.5-2.5M8 3l-1 1.5M16 3l1 1.5" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
  </svg>
);

const IconChevronRight = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="9 18 15 12 9 6"/>
  </svg>
);

// ── Screenshot data ───────────────────────────────────────────────
const SCREENSHOTS = [
  { label: 'Home',        src: '/screenshots/screen1.png' },
  { label: 'Live Map',    src: '/screenshots/screen2.png' },
  { label: 'Live Map',    src: '/screenshots/screen3.png' },
  { label: 'Barber Hub',  src: '/screenshots/screen4.png' },
  { label: 'Shop Pin',    src: '/screenshots/screen5.png' },
];

// ── Features ─────────────────────────────────────────────────────
const FEATURES = [
  { icon: <IconMap />,      title: 'Live Map Discovery',   desc: 'Apne qareeb tamam barber shops GPS se dhundo — list, map ya split view mein.' },
  { icon: <IconCalendar />, title: 'Online Booking',       desc: 'Slot choose karo, book karo — koi call nahi, koi wait nahi.' },
  { icon: <IconBell />,     title: 'Instant Notifications',desc: 'Har nayi booking ka real-time alert barber ko milta hai.' },
  { icon: <IconQR />,       title: 'Branded QR Code',      desc: 'Barber apna QR share kare — customer scan kare aur seedha book kare.' },
  { icon: <IconStar />,     title: 'Reviews System',       desc: 'Customers apne experience rate kar sakte hain — quality maintain hoti hai.' },
  { icon: <IconScissors />, title: 'Barber Dashboard',     desc: 'Bookings, slots, payments — sab ek jagah manage karo.' },
];

// ── Install Steps ─────────────────────────────────────────────────
const STEPS = [
  { n: '01', text: 'Neeche "Download APK" button dabao' },
  { n: '02', text: 'APK file download hogi — browser notification check karo' },
  { n: '03', text: 'Settings → Unknown sources → Allow' },
  { n: '04', text: 'APK install karo aur Zentro enjoy karo!' },
];

export default function Download() {
  const scrollRef = useRef(null);
  const [confetti, setConfetti] = useState(false);

  const handleDownload = useCallback(() => {
    const a = document.createElement('a');
    a.href = APK_URL;
    a.download = 'zentro.apk';
    a.click();
    setConfetti(true);
  }, []);

  return (
    <div style={s.page}>
      <Confetti active={confetti} onDone={() => setConfetti(false)} />

      {/* ── Hero ── */}
      <section style={s.hero}>
        <div style={s.heroBadge}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="#4CAF50"><circle cx="12" cy="12" r="10"/></svg>
          <span>Pakistan Ka Pehla Barber Booking App</span>
        </div>
        <h1 style={s.heroTitle}>
          <span style={s.white}>Zentro </span>
          <span style={s.blue}>Download</span>
          <span style={s.white}> Karo</span>
        </h1>
        <p style={s.heroSub}>Apne Android phone par install karo — bilkul free</p>

        <button style={s.dlBtn} onClick={handleDownload}>
          <IconDownload />
          <span>Download APK</span>
          <IconAndroid />
        </button>

        <p style={s.dlNote}>Android 5.0+ required · Free download</p>
      </section>

      {/* ── Screenshots ── */}
      <section style={s.section}>
        <h2 style={s.sectionTitle}>App Screenshots</h2>
        <div ref={scrollRef} style={s.screenshotRow}>
          {SCREENSHOTS.map((sc, i) => (
            <div key={i} style={s.screenshotCard}>
              <div style={s.screenshotFrame}>
                <img
                  src={sc.src}
                  alt={sc.label}
                  style={s.screenshotImg}
                  onError={e => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex'; }}
                />
                {/* Fallback placeholder */}
                <div style={{ ...s.screenshotPlaceholder, display: 'none' }}>
                  <IconScissors />
                  <span style={{ color: 'var(--text-3)', fontSize: 12, marginTop: 8 }}>{sc.label}</span>
                </div>
              </div>
              <span style={s.screenshotLabel}>{sc.label}</span>
            </div>
          ))}
        </div>
        <p style={s.scrollHint}>← swipe to see more →</p>
      </section>

      {/* ── Features ── */}
      <section style={s.section}>
        <h2 style={s.sectionTitle}>Kya Kya Milega?</h2>
        <div style={s.featuresGrid}>
          {FEATURES.map((f, i) => (
            <div key={i} style={s.featureCard}>
              <div style={s.featureIcon}>{f.icon}</div>
              <div>
                <div style={s.featureTitle}>{f.title}</div>
                <div style={s.featureDesc}>{f.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Install Steps ── */}
      <section style={{ ...s.section, ...s.stepsSection }}>
        <h2 style={{ ...s.sectionTitle, color: '#fff' }}>Kaise Install Karein?</h2>
        <div style={s.stepsGrid}>
          {STEPS.map((st, i) => (
            <div key={i} style={s.stepCard}>
              <div style={s.stepNum}>{st.n}</div>
              <div style={s.stepText}>{st.text}</div>
              {i < STEPS.length - 1 && <div style={s.stepArrow}><IconChevronRight /></div>}
            </div>
          ))}
        </div>
      </section>

      {/* ── Bottom CTA ── */}
      <section style={s.ctaSection}>
        <div style={s.ctaInner}>
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#0080FF" strokeWidth="1.5">
            <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
            <line x1="20" y1="4" x2="8.12" y2="15.88"/>
            <line x1="14.47" y1="14.48" x2="20" y2="20"/>
            <line x1="8.12" y1="8.12" x2="12" y2="12"/>
          </svg>
          <h3 style={s.ctaTitle}>Abhi Download Karo — <span style={s.blue}>FREE hai!</span></h3>
          <p style={s.ctaSub}>Koi subscription nahi, koi hidden charges nahi</p>
          <button style={s.dlBtn} onClick={handleDownload}>
            <IconDownload />
            <span>Download APK</span>
          </button>
        </div>
      </section>

    </div>
  );
}

// ── Styles ────────────────────────────────────────────────────────
const s = {
  page: {
    minHeight: '100vh',
    background: 'var(--bg)',
    paddingBottom: 80,
    fontFamily: 'var(--font-body)',
  },
  hero: {
    background: 'linear-gradient(160deg, #060E1E 0%, #091525 60%, #0a1a35 100%)',
    padding: '56px 24px 48px',
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 16,
  },
  heroBadge: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    background: 'rgba(0,128,255,0.12)',
    border: '1px solid rgba(0,128,255,0.25)',
    borderRadius: 40,
    padding: '5px 14px',
    fontSize: 12,
    color: 'rgba(255,255,255,0.75)',
    fontFamily: 'var(--font-display)',
    letterSpacing: 0.3,
  },
  heroTitle: {
    fontFamily: 'var(--font-display)',
    fontWeight: 800,
    fontSize: 'clamp(32px, 8vw, 48px)',
    lineHeight: 1.15,
    margin: 0,
  },
  white: { color: '#ffffff' },
  blue:  { color: '#0080FF' },
  heroSub: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 15,
    maxWidth: 300,
    lineHeight: 1.6,
  },
  dlBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 10,
    background: 'linear-gradient(135deg, #0080FF, #0066cc)',
    color: '#fff',
    border: 'none',
    borderRadius: 50,
    padding: '14px 28px',
    fontSize: 16,
    fontWeight: 700,
    fontFamily: 'var(--font-display)',
    cursor: 'pointer',
    boxShadow: '0 8px 28px rgba(0,128,255,0.4)',
    transition: 'transform 0.15s, box-shadow 0.15s',
    marginTop: 8,
  },
  dlNote: {
    color: 'rgba(255,255,255,0.35)',
    fontSize: 12,
    marginTop: -4,
  },
  section: {
    padding: '36px 20px 8px',
    maxWidth: 600,
    margin: '0 auto',
  },
  sectionTitle: {
    fontFamily: 'var(--font-display)',
    fontWeight: 800,
    fontSize: 22,
    color: 'var(--text-1)',
    marginBottom: 20,
  },
  screenshotRow: {
    display: 'flex',
    gap: 14,
    overflowX: 'auto',
    paddingBottom: 12,
    scrollSnapType: 'x mandatory',
    WebkitOverflowScrolling: 'touch',
    scrollbarWidth: 'none',
    msOverflowStyle: 'none',
  },
  screenshotCard: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 8,
    flexShrink: 0,
    scrollSnapAlign: 'start',
  },
  screenshotFrame: {
    width: 160,
    height: 284,
    borderRadius: 20,
    overflow: 'hidden',
    background: '#0a1220',
    border: '2px solid rgba(0,128,255,0.2)',
    boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
    position: 'relative',
  },
  screenshotImg: {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  screenshotPlaceholder: {
    position: 'absolute',
    inset: 0,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  screenshotLabel: {
    fontSize: 12,
    color: 'var(--text-3)',
    fontWeight: 600,
  },
  scrollHint: {
    textAlign: 'center',
    color: 'var(--text-3)',
    fontSize: 12,
    marginTop: 8,
    letterSpacing: 0.5,
  },
  featuresGrid: {
    display: 'flex',
    flexDirection: 'column',
    gap: 14,
  },
  featureCard: {
    display: 'flex',
    gap: 16,
    alignItems: 'flex-start',
    background: 'var(--bg-card)',
    borderRadius: 'var(--radius)',
    padding: '16px 18px',
    boxShadow: 'var(--shadow-card)',
    border: '1px solid var(--border)',
  },
  featureIcon: {
    flexShrink: 0,
    width: 48,
    height: 48,
    borderRadius: 14,
    background: 'rgba(0,128,255,0.08)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureTitle: {
    fontFamily: 'var(--font-display)',
    fontWeight: 700,
    fontSize: 15,
    color: 'var(--text-1)',
    marginBottom: 4,
  },
  featureDesc: {
    fontSize: 13,
    color: 'var(--text-2)',
    lineHeight: 1.55,
  },
  stepsSection: {
    background: 'linear-gradient(135deg, #060E1E, #091828)',
    maxWidth: '100%',
    padding: '36px 24px 40px',
    marginTop: 24,
  },
  stepsGrid: {
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
    maxWidth: 560,
    margin: '0 auto',
  },
  stepCard: {
    display: 'flex',
    alignItems: 'center',
    gap: 16,
    background: 'rgba(0,128,255,0.08)',
    border: '1px solid rgba(0,128,255,0.15)',
    borderRadius: 'var(--radius)',
    padding: '14px 18px',
    position: 'relative',
  },
  stepNum: {
    fontFamily: 'var(--font-display)',
    fontWeight: 900,
    fontSize: 20,
    color: '#0080FF',
    flexShrink: 0,
    width: 36,
  },
  stepText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.85)',
    lineHeight: 1.5,
    flex: 1,
  },
  stepArrow: {
    color: 'rgba(0,128,255,0.4)',
    flexShrink: 0,
  },
  ctaSection: {
    padding: '40px 24px',
    textAlign: 'center',
  },
  ctaInner: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 12,
    maxWidth: 400,
    margin: '0 auto',
    background: 'var(--bg-card)',
    borderRadius: 24,
    padding: '32px 24px',
    boxShadow: 'var(--shadow-md)',
    border: '1px solid var(--border)',
  },
  ctaTitle: {
    fontFamily: 'var(--font-display)',
    fontWeight: 800,
    fontSize: 20,
    color: 'var(--text-1)',
    lineHeight: 1.3,
  },
  ctaSub: {
    fontSize: 13,
    color: 'var(--text-2)',
  },
};
