import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import Navbar from './components/Navbar';
import ErrorBoundary from './components/ErrorBoundary';
import './styles/global.css';

const Home            = lazy(() => import('./pages/Home'));
const Shops           = lazy(() => import('./pages/Shops'));
const ShopDetail      = lazy(() => import('./pages/ShopDetail'));
const Account         = lazy(() => import('./pages/Account'));
const Login           = lazy(() => import('./pages/Login'));
const Register        = lazy(() => import('./pages/Register'));
const MyBookings      = lazy(() => import('./pages/MyBookings'));
const BarberDashboard = lazy(() => import('./pages/BarberDashboard'));
const BarberSetup     = lazy(() => import('./pages/BarberSetup'));
const BarberSlots     = lazy(() => import('./pages/BarberSlots'));
const BarberPayment   = lazy(() => import('./pages/BarberPayment'));

const Spinner = () => (
  <div className="loading-screen">
    <div className="loading-logo">✂ Zentro</div>
    <div className="spinner" />
    <p className="loading-tagline">Pakistan's Barber Booking Platform</p>
  </div>
);

function ProtectedRoute({ children, allowedRoles }) {
  const { user, profile, authReady } = useAuth();

  // Always wait for auth to fully resolve before deciding anything
  if (!authReady) return <Spinner />;

  // Not logged in
  if (!user) return <Navigate to="/account" replace />;

  // Profile still loading — wait, never redirect yet
  if (!profile) return <Spinner />;

  // Logged in but wrong role
  if (allowedRoles && !allowedRoles.includes(profile.role)) {
    console.log('Role check failed:', profile.role, 'allowed:', allowedRoles);
    return <Navigate to="/shops" replace />;
  }

  return children;
}

function AppRoutes() {
  return (
    <div id="app-shell">
      <Suspense fallback={<Spinner />}>
        <Routes>
          <Route path="/"                 element={<Home />} />
          <Route path="/shops"            element={<Shops />} />
          <Route path="/shops/:id"        element={<ShopDetail />} />
          <Route path="/account"          element={<Account />} />
          <Route path="/login"            element={<Login />} />
          <Route path="/register"         element={<Register />} />
          <Route path="/bookings"         element={<ProtectedRoute allowedRoles={['customer']}><MyBookings /></ProtectedRoute>} />
          <Route path="/barber/dashboard" element={<ProtectedRoute allowedRoles={['barber']}><BarberDashboard /></ProtectedRoute>} />
          <Route path="/barber/setup"     element={<ProtectedRoute allowedRoles={['barber']}><BarberSetup /></ProtectedRoute>} />
          <Route path="/barber/slots"     element={<ProtectedRoute allowedRoles={['barber']}><BarberSlots /></ProtectedRoute>} />
          <Route path="/barber/payment"   element={<ProtectedRoute allowedRoles={['barber']}><BarberPayment /></ProtectedRoute>} />
          <Route path="*"                 element={<Navigate to="/shops" replace />} />
        </Routes>
      </Suspense>
      <Navbar />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </ErrorBoundary>
    </BrowserRouter>
  );
}
