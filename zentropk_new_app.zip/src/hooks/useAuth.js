import React, { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import { supabase, getProfile } from '../lib/supabase';

const AuthContext = createContext({});

const readCachedProfile = () => {
  try { return JSON.parse(localStorage.getItem('zentro_profile')); }
  catch { return null; }
};

const writeCachedProfile = (profile) => {
  try {
    if (profile) localStorage.setItem('zentro_profile', JSON.stringify(profile));
    else localStorage.removeItem('zentro_profile');
  } catch {}
};

export const AuthProvider = ({ children }) => {
  const [user, setUser]           = useState(null);
  const [profile, setProfile]     = useState(readCachedProfile); // pre-fill UI from cache
  const [authReady, setAuthReady] = useState(false); // always wait for getSession — never trust cache alone
  const resolved = useRef(false);
  const currentUserId = useRef(null);

  const loadProfile = useCallback(async (userId) => {
    try {
      const { data, error } = await getProfile(userId);
      if (!error && data) {
        setProfile(data);
        writeCachedProfile(data);
      } else {
        const cached = readCachedProfile();
        if (cached && cached.id === userId) {
          setProfile(cached);
        } else {
          setProfile(null);
          writeCachedProfile(null);
        }
      }
    } catch (_) {
      const cached = readCachedProfile();
      if (cached && cached.id === userId) setProfile(cached);
    } finally {
      setAuthReady(true);
    }
  }, []);

  useEffect(() => {
    let ignore = false;

    // Safety timeout — unblock UI after 4s if Supabase never responds
    const timeout = setTimeout(() => {
      if (!ignore && !resolved.current) {
        console.warn('Auth timeout — unblocking UI');
        resolved.current = true;
        setAuthReady(true);
      }
    }, 4000);

    supabase.auth.getSession().then(async ({ data: { session } }) => {
      clearTimeout(timeout);
      resolved.current = true;
      if (ignore) return;
      const u = session?.user ?? null;
      setUser(u);
      currentUserId.current = u?.id ?? null;
      if (u) {
        await loadProfile(u.id);
      } else {
        writeCachedProfile(null);
        setProfile(null);
        setAuthReady(true);
      }
    }).catch(() => {
      clearTimeout(timeout);
      if (!ignore) {
        const cached = readCachedProfile();
        if (cached) setProfile(cached);
        setAuthReady(true);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (ignore) return;
      const u = session?.user ?? null;
      setUser(u);
      currentUserId.current = u?.id ?? null;
      if (u) {
        await loadProfile(u.id);
      } else {
        writeCachedProfile(null);
        setProfile(null);
        setAuthReady(true);
      }
    });

    // Re-fetch profile when tab becomes visible (handles stale state & admin changes)
    const handleVisibilityChange = async () => {
      if (document.visibilityState === 'visible' && currentUserId.current) {
        try {
          const { data: { session } } = await supabase.auth.getSession();
          const u = session?.user ?? null;
          if (u) {
            setUser(u);
            const { data } = await getProfile(u.id);
            if (data) {
              setProfile(data);
              writeCachedProfile(data);
            }
          }
        } catch (_) {}
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Real-time listener: if admin changes the profile table, reflect immediately
    let realtimeSub = null;
    supabase.auth.getSession().then(({ data: { session } }) => {
      const uid = session?.user?.id;
      if (!uid || ignore) return;
      realtimeSub = supabase
        .channel(`profile-changes-${uid}`)
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${uid}`,
        }, (payload) => {
          if (payload.new) {
            setProfile(payload.new);
            writeCachedProfile(payload.new);
          }
        })
        .subscribe();
    });

    return () => {
      ignore = true;
      clearTimeout(timeout);
      subscription.unsubscribe();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (realtimeSub) supabase.removeChannel(realtimeSub);
    };
  }, []); // eslint-disable-line

  return (
    <AuthContext.Provider value={{ user, profile, authReady, setProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
