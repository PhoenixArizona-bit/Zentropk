import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, uploadImage } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

function JazzCashLogo({ size = 32 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="14" fill="#C8102E"/>
      <text x="32" y="42" textAnchor="middle" fontFamily="Arial Black, sans-serif" fontWeight="900" fontSize="18" fill="#FFD700">JC</text>
    </svg>
  );
}
function EasyPaisaLogo({ size = 32 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="14" fill="#00A651"/>
      <text x="32" y="42" textAnchor="middle" fontFamily="Arial Black, sans-serif" fontWeight="900" fontSize="18" fill="#FFFFFF">EP</text>
    </svg>
  );
}

const TIER_KEYS = ['basic', 'pro', 'premium'];
const TIER_ICONS = { basic: '🥉', pro: '🥈', premium: '🥇' };
const TIER_COLORS = {
  basic:   { border: 'var(--border)',   bg: 'var(--bg-card)',    text: 'var(--text)',   badge: '#888' },
  pro:     { border: '#FF3D00',         bg: 'var(--brand-glow)', text: 'var(--brand)',  badge: '#FF3D00' },
  premium: { border: '#FFB800',         bg: 'rgba(255,184,0,0.08)', text: '#FFB800',   badge: '#FFB800' },
};

export default function BarberPayment() {
  const { user } = useAuth();
  const navigate  = useNavigate();
  const fileRef   = useRef(null);

  const [shopId,       setShopId]       = useState(null);
  const [currentTier,  setCurrentTier]  = useState(null);
  const [submissions,  setSubmissions]  = useState([]);
  const [method,       setMethod]       = useState('jazzcash');
  const [selectedTier, setSelectedTier] = useState(null);
  const [txnId,        setTxnId]        = useState('');
  const [screenshot,   setScreenshot]   = useState(null);
  const [uploading,    setUploading]    = useState(false);
  const [msg,          setMsg]          = useState({ type: '', text: '' });
  const [jazzNumber,   setJazzNumber]   = useState('');
  const [easyNumber,   setEasyNumber]   = useState('');
  const [jazzName,     setJazzName]     = useState('');
  const [easyName,     setEasyName]     = useState('');
  const [tiers,        setTiers]        = useState({
    basic:   { name: 'Basic',   price: '500',  desc: 'Listed on explore, up to 5 services, 3 photos' },
    pro:     { name: 'Pro',     price: '1000', desc: 'Everything in Basic + 15 services, 10 photos, priority listing' },
    premium: { name: 'Premium', price: '2000', desc: 'Everything in Pro + unlimited services & photos, featured badge' },
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => { if (user) loadData(); }, [user]);

  const loadData = async () => {
    setLoading(true);
    // Load all settings
    const { data: settings } = await supabase
      .from('app_settings').select('key, value')
      .in('key', [
        'jazzcash_number', 'easypaisa_number',
        'jazzcash_name', 'easypaisa_name',
        'tier_basic_name', 'tier_basic_price', 'tier_basic_desc',
        'tier_pro_name',   'tier_pro_price',   'tier_pro_desc',
        'tier_premium_name','tier_premium_price','tier_premium_desc',
      ]);

    if (settings) {
      const g = (k) => settings.find(s => s.key === k)?.value || '';
      setJazzNumber(g('jazzcash_number'));
      setEasyNumber(g('easypaisa_number'));
      setJazzName(g('jazzcash_name'));
      setEasyName(g('easypaisa_name'));
      setTiers({
        basic:   { name: g('tier_basic_name')   || 'Basic',   price: g('tier_basic_price')   || '500',  desc: g('tier_basic_desc')   || '' },
        pro:     { name: g('tier_pro_name')     || 'Pro',     price: g('tier_pro_price')     || '1000', desc: g('tier_pro_desc')     || '' },
        premium: { name: g('tier_premium_name') || 'Premium', price: g('tier_premium_price') || '2000', desc: g('tier_premium_desc') || '' },
      });
    }

    const { data: shop } = await supabase.from('shops').select('id, subscription_tier').eq('owner_id', user.id).single();
    if (shop) {
      setShopId(shop.id);
      setCurrentTier(shop.subscription_tier || null);
      setSelectedTier(null); // barber must actively choose
      const { data: subs } = await supabase
        .from('payment_submissions').select('*')
        .eq('shop_id', shop.id).order('submitted_at', { ascending: false });
      setSubmissions(subs || []);
    }
    setLoading(false);
  };

  const showMsg = (type, text) => { setMsg({ type, text }); setTimeout(() => setMsg({ type: '', text: '' }), 4000); };

  const handleSubmit = async () => {
    if (!txnId.trim()) { showMsg('error', 'Please enter your transaction ID.'); return; }
    if (!shopId) { showMsg('error', 'Shop not found. Please set up your shop first.'); return; }
    setUploading(true);
    let screenshotUrl = null;
    if (screenshot) {
      const path = `${user.id}/${Date.now()}_payment.jpg`;
      const { url } = await uploadImage('payment-proofs', path, screenshot);
      screenshotUrl = url;
    }
    const amount = parseFloat(tiers[selectedTier]?.price || 500);
    const { error } = await supabase.from('payment_submissions').insert({
      shop_id: shopId, barber_id: user.id,
      amount, payment_method: method,
      transaction_id: txnId.trim(),
      screenshot_url: screenshotUrl,
      subscription_tier: selectedTier,
    });
    setUploading(false);
    if (error) { showMsg('error', error.message); return; }
    showMsg('success', 'Payment submitted! Admin will verify within 24 hours.');
    setTxnId(''); setScreenshot(null);
    if (fileRef.current) fileRef.current.value = '';
    loadData();
  };

  const activeNumber = method === 'jazzcash' ? jazzNumber : easyNumber;
  const activeName   = method === 'jazzcash' ? jazzName   : easyName;
  const statusStyle = (s) => ({
    approved: { bg: 'rgba(0,200,100,0.12)', color: '#00C864' },
    pending:  { bg: 'rgba(255,184,0,0.15)', color: '#FFB800' },
    rejected: { bg: 'rgba(255,61,0,0.1)',   color: 'var(--brand)' },
  }[s] || { bg: 'var(--bg-input)', color: 'var(--text-3)' });

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;

  return (
    <div className="page fade-up" style={{ padding: '0 20px', paddingBottom: 120 }}>
      <div className="top-header">
        <button onClick={() => navigate(-1)} style={{ background: 'none', border: 'none', color: 'var(--text-2)', fontSize: 22, cursor: 'pointer' }}>←</button>
        <div className="logo-text">💳 <span>Subscription</span></div>
        <div style={{ width: 32 }} />
      </div>

      {msg.text && <div className={`alert alert-${msg.type}`} style={{ marginBottom: 16 }}>{msg.text}</div>}

      {/* Current plan */}
      {currentTier && (
        <div style={{
          background: 'var(--bg-card)', border: `1.5px solid ${TIER_COLORS[currentTier]?.border || 'var(--border)'}`,
          borderRadius: 16, padding: '14px 18px', marginBottom: 20,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', fontWeight: 600, marginBottom: 2 }}>CURRENT PLAN</div>
            <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: 18, color: TIER_COLORS[currentTier]?.text }}>
              {TIER_ICONS[currentTier]} {tiers[currentTier]?.name}
            </div>
          </div>
          <div style={{ fontWeight: 800, fontSize: 20, color: TIER_COLORS[currentTier]?.text, fontFamily: 'Outfit, sans-serif' }}>
            Rs. {tiers[currentTier]?.price}<span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-3)' }}>/mo</span>
          </div>
        </div>
      )}

      {/* Tier selector */}
      <p className="section-label" style={{ marginBottom: 12 }}>Choose a Plan</p>
      {!selectedTier && (
        <div style={{ background: 'rgba(255,184,0,0.1)', border: '1px solid #FFB800', borderRadius: 12, padding: '10px 14px', marginBottom: 12, fontSize: 13, color: '#FFB800', fontWeight: 600 }}>
          👆 Select the plan you want to subscribe to
        </div>
      )}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
        {TIER_KEYS.map(key => {
          const t = tiers[key];
          const c = TIER_COLORS[key];
          const selected = selectedTier === key;
          return (
            <div
              key={key}
              onClick={() => setSelectedTier(key)}
              style={{
                padding: '16px 18px', borderRadius: 16, cursor: 'pointer',
                border: selected ? `2.5px solid ${c.border}` : '1.5px solid var(--border)',
                background: selected ? c.bg : 'var(--bg-card)',
                transition: 'all 0.15s',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
              }}
            >
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{ fontSize: 20 }}>{TIER_ICONS[key]}</span>
                  <span style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: 16, color: selected ? c.text : 'var(--text)' }}>{t.name}</span>
                  {currentTier === key && (
                    <span style={{ fontSize: 10, fontWeight: 700, background: c.badge, color: '#fff', borderRadius: 100, padding: '2px 8px' }}>CURRENT</span>
                  )}
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-3)', lineHeight: 1.5 }}>{t.desc}</div>
              </div>
              <div style={{ textAlign: 'right', flexShrink: 0 }}>
                <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: 18, color: selected ? c.text : 'var(--text)' }}>Rs. {t.price}</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)' }}>/month</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Payment method */}
      <p className="section-label" style={{ marginBottom: 12 }}>Select Payment Method</p>
      <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
        {[
          { id: 'jazzcash', Logo: JazzCashLogo, name: 'JazzCash', number: jazzNumber, acctName: jazzName },
          { id: 'easypaisa', Logo: EasyPaisaLogo, name: 'EasyPaisa', number: easyNumber, acctName: easyName },
        ].map(({ id, Logo, name, number, acctName }) => (
          <div key={id} onClick={() => setMethod(id)} style={{
            flex: 1, padding: 14, borderRadius: 16, cursor: 'pointer',
            border: method === id ? '2.5px solid var(--brand)' : '1.5px solid var(--border)',
            background: method === id ? 'var(--brand-glow)' : 'var(--bg-card)',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
          }}>
            <Logo size={40} />
            <div style={{ fontWeight: 800, fontSize: 13, fontFamily: 'Outfit, sans-serif', color: method === id ? 'var(--brand)' : 'var(--text)' }}>{name}</div>
            {acctName && <div style={{ fontWeight: 700, fontSize: 12, color: 'var(--text-2)', textAlign: 'center' }}>{acctName}</div>}
            <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--brand)', textAlign: 'center' }}>{number || 'Not set'}</div>
          </div>
        ))}
      </div>

      {/* Send-to number */}
      {activeNumber ? (
        <div style={{
          background: 'var(--bg-card)', border: '1.5px solid var(--brand)',
          borderRadius: 16, padding: '14px 20px', marginBottom: 20,
        }}>
          <div style={{ color: 'var(--text-3)', fontSize: 12, fontWeight: 600, marginBottom: 6 }}>
            Send Rs. {tiers[selectedTier]?.price || '—'} to:
          </div>
          {activeName && (
            <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--text)', marginBottom: 4 }}>
              👤 {activeName}
            </div>
          )}
          <div style={{ color: 'var(--brand)', fontWeight: 800, fontSize: 22, fontFamily: 'Outfit, sans-serif', letterSpacing: 1 }}>
            {activeNumber}
          </div>
        </div>
      ) : (
        <div style={{ background: 'rgba(255,184,0,0.1)', border: '1px solid #FFB800', borderRadius: 14, padding: '12px 16px', marginBottom: 20, fontSize: 13, color: '#FFB800', fontWeight: 600 }}>
          ⚠️ Payment number not set yet. Contact admin.
        </div>
      )}

      {/* Submit form */}
      <div className="card" style={{ padding: 20, marginBottom: 24 }}>
        <p className="section-label" style={{ marginBottom: 14 }}>Submit Payment Proof</p>
        <div className="form-group">
          <label>Transaction ID *</label>
          <input value={txnId} onChange={e => setTxnId(e.target.value)} placeholder="e.g. TXN123456789" onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
        </div>
        <div className="form-group">
          <label>Screenshot (recommended)</label>
          <button onClick={() => fileRef.current?.click()} style={{
            width: '100%', padding: '12px 16px', borderRadius: 14,
            border: '2px dashed var(--border)', background: 'transparent',
            color: screenshot ? '#00C864' : 'var(--text-2)',
            fontWeight: 600, fontSize: 14, cursor: 'pointer', fontFamily: 'Plus Jakarta Sans, sans-serif',
          }}>
            {screenshot ? `✓ ${screenshot.name}` : '+ Upload Screenshot'}
          </button>
          <input ref={fileRef} type="file" accept="image/*" onChange={e => setScreenshot(e.target.files[0])} style={{ display: 'none' }} />
        </div>
        <button className="btn-primary" onClick={handleSubmit} disabled={uploading || !txnId.trim() || !selectedTier}>
          {uploading ? '⏳ Submitting...' : selectedTier ? `Submit ${tiers[selectedTier]?.name} Plan Payment` : 'Select a Plan First'}
        </button>
      </div>

      {/* Payment history */}
      {submissions.length > 0 && (
        <div>
          <p className="section-label" style={{ marginBottom: 12 }}>Payment History</p>
          {submissions.map(sub => {
            const sc = statusStyle(sub.status);
            const tierKey = sub.subscription_tier || 'basic';
            return (
              <div key={sub.id} className="card" style={{ padding: 16, marginBottom: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                      <span style={{ fontWeight: 700, fontSize: 15 }}>{sub.payment_method === 'jazzcash' ? 'JazzCash' : 'EasyPaisa'}</span>
                      <span style={{ fontSize: 11, fontWeight: 700, background: TIER_COLORS[tierKey]?.badge || '#888', color: '#fff', borderRadius: 100, padding: '2px 8px' }}>
                        {TIER_ICONS[tierKey]} {tiers[tierKey]?.name || tierKey}
                      </span>
                    </div>
                    <div style={{ color: 'var(--text-3)', fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>TXN: {sub.transaction_id}</div>
                    <div style={{ color: 'var(--text-3)', fontSize: 11, marginTop: 2 }}>{new Date(sub.submitted_at).toLocaleDateString()}</div>
                    {sub.admin_note && <div style={{ color: 'var(--text-2)', fontSize: 12, marginTop: 6, fontStyle: 'italic' }}>Admin: "{sub.admin_note}"</div>}
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontWeight: 800, fontSize: 16, color: 'var(--brand)', fontFamily: 'Outfit, sans-serif' }}>Rs. {sub.amount}</div>
                    <span style={{ padding: '3px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: sc.bg, color: sc.color, display: 'inline-block', marginTop: 6, textTransform: 'capitalize' }}>{sub.status}</span>
                  </div>
                </div>
                {sub.screenshot_url && (
                  <a href={sub.screenshot_url} style={{ display: 'block', marginTop: 12 }}>
                    <img src={sub.screenshot_url} alt="Payment screenshot" style={{ width: '100%', maxHeight: 180, objectFit: 'cover', borderRadius: 12 }} />
                  </a>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
