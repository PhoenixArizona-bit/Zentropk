import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase, cachedQuery, invalidateCache } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { format, addDays } from 'date-fns';

function toAmPm(time) {
  if (!time) return '';
  const [h, m] = time.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 || 12;
  return `${hour}:${String(m).padStart(2, '0')} ${ampm}`;
}

const DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

export default function ShopDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [shop, setShop] = useState(null);
  const [services, setServices] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [hours, setHours] = useState([]);
  const [slots, setSlots] = useState([]);
  const [tab, setTab] = useState('book');
  const [imgIdx, setImgIdx] = useState(0);

  const [selectedService, setSelectedService] = useState(null);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [notes, setNotes] = useState('');
  const [booking, setBooking] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { fetchShopData(); }, [id]);
  useEffect(() => { if (id) fetchSlots(); }, [id, selectedDate]);

  const fetchShopData = async () => {
    const cached = await cachedQuery(`shop:${id}`, 30_000, async () => {
      const [shopRes, srvRes, revRes, hrsRes] = await Promise.all([
        supabase.from('shops').select('*').eq('id', id).single(),
        supabase.from('services').select('id,name,price,duration_minutes,is_active').eq('shop_id', id).eq('is_active', true),
        supabase.from('reviews').select('id,rating,comment,created_at,profiles(full_name)').eq('shop_id', id).order('created_at', { ascending: false }),
        supabase.from('opening_hours').select('*').eq('shop_id', id),
      ]);
      return {
        shop: shopRes.data,
        services: srvRes.data || [],
        reviews: revRes.data || [],
        hours: hrsRes.data || [],
      };
    });
    setShop(cached.shop);
    setServices(cached.services);
    setReviews(cached.reviews);
    setHours(cached.hours);
  };

  const fetchSlots = async () => {
    const { data: slotData } = await supabase
      .from('time_slots').select('*')
      .eq('shop_id', id).eq('slot_date', selectedDate).eq('is_available', true)
      .order('start_time');
    setSlots(slotData || []);
  };

  const fetchAll = () => { fetchShopData(); fetchSlots(); };

  const avgRating = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : null;

  const next7Days = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(new Date(), i);
    return { date: format(d, 'yyyy-MM-dd'), label: i === 0 ? 'Today' : format(d, 'EEE d') };
  });

  const handleBook = async () => {
    if (!user) { navigate('/login'); return; }
    if (!selectedService || !selectedSlot) { setError('Please select a service and time slot.'); return; }
    setBooking(true); setError('');

    // Atomic claim: only updates if still available — prevents race conditions
    const { data: claimed, error: claimErr } = await supabase
      .from('time_slots')
      .update({ is_available: false })
      .eq('id', selectedSlot)
      .eq('is_available', true)   // <-- atomic guard: only succeeds if still free
      .select('id');

    if (claimErr || !claimed || claimed.length === 0) {
      setBooking(false);
      setError('This slot was just booked by someone else. Please choose another time.');
      fetchSlots();
      return;
    }

    const { error: err } = await supabase.from('bookings').insert({
      shop_id: id,
      customer_id: user.id,
      service_id: selectedService,
      slot_id: selectedSlot,
      notes,
    });

    setBooking(false);
    if (err) {
      // Restore slot — booking insert failed
      await supabase.from('time_slots').update({ is_available: true }).eq('id', selectedSlot);
      setError('Booking failed. Please try again.');
      return;
    }
    invalidateCache(`shop:${id}`);
    setSuccess('Booking confirmed! The barber will see your appointment.');
    setSelectedSlot(null);
    fetchAll();
  };

  if (!shop) return <div className="loading-screen"><div className="spinner" /></div>;

  const imgs = shop.images || [];

  return (
    <div className="page fade-up" style={{ paddingBottom: 100 }}>
      {/* Hero image */}
      <div style={{ position: 'relative', height: 240, background: 'var(--bg-input)', overflow: 'hidden' }}>
        {imgs.length > 0
          ? <img src={imgs[imgIdx]} alt={shop.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          : <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 64 }}>💈</div>
        }
        {/* Back button */}
        <button onClick={() => navigate(-1)} style={{ position: 'absolute', top: 16, left: 16, width: 38, height: 38, borderRadius: 12, background: 'rgba(0,0,0,0.5)', border: 'none', color: '#fff', fontSize: 18, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', backdropFilter: 'blur(8px)' }}>←</button>
        {/* Image dots */}
        {imgs.length > 1 && (
          <div style={{ position: 'absolute', bottom: 12, left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 6 }}>
            {imgs.map((_, i) => (
              <button key={i} onClick={() => setImgIdx(i)} style={{ width: i === imgIdx ? 20 : 8, height: 8, borderRadius: 4, border: 'none', background: i === imgIdx ? '#fff' : 'rgba(255,255,255,0.5)', cursor: 'pointer', transition: 'all 0.2s', padding: 0 }} />
            ))}
          </div>
        )}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 80, background: 'linear-gradient(transparent, rgba(0,0,0,0.7))' }} />
      </div>

      {/* Shop info */}
      <div style={{ padding: '16px 20px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8, gap: 10 }}>
          <h1 style={{ fontFamily: 'Outfit, sans-serif', fontSize: 22, fontWeight: 800, flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{shop.name}</h1>
          {shop.subscription_tier === 'premium' && (
            <span style={{
              flexShrink: 0,
              background: 'linear-gradient(135deg, #FFB800, #FF6B00)',
              borderRadius: 6, padding: '3px 10px',
              fontSize: 10, fontWeight: 900, color: '#fff',
              boxShadow: '0 2px 10px rgba(255,184,0,0.5)',
              letterSpacing: 1.5, textTransform: 'uppercase',
            }}>PREMIUM</span>
          )}
          {shop.subscription_tier === 'pro' && (
            <span style={{
              flexShrink: 0,
              background: 'linear-gradient(135deg, #FF3D00, #c62800)',
              borderRadius: 6, padding: '3px 10px',
              fontSize: 10, fontWeight: 900, color: '#fff',
              boxShadow: '0 2px 10px rgba(255,61,0,0.4)',
              letterSpacing: 1.5, textTransform: 'uppercase',
            }}>PRO</span>
          )}
          {avgRating && (
            <div style={{ background: 'var(--brand)', color: '#fff', borderRadius: 10, padding: '4px 10px', fontWeight: 800, fontSize: 14, display: 'flex', alignItems: 'center', gap: 4 }}>
              ★ {avgRating}
            </div>
          )}
        </div>
        <div style={{ color: 'var(--text-3)', fontSize: 14, marginBottom: 4 }}>📍 {shop.address}, {shop.city}</div>
        {shop.phone && <div style={{ color: 'var(--text-3)', fontSize: 14, marginBottom: 16 }}>📞 {shop.phone}</div>}

        {/* Tab bar */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 20, overflowX: 'auto', scrollbarWidth: 'none' }}>
          {[
            { key: 'book', label: '📅 Book' },
            { key: 'info', label: 'ℹ️ Info' },
            { key: 'reviews', label: `★ Reviews (${reviews.length})` },
          ].map(t => (
            <button key={t.key} onClick={() => setTab(t.key)} style={{
              flexShrink: 0, padding: '8px 16px', borderRadius: 100,
              border: 'none', fontWeight: 700, fontSize: 13, cursor: 'pointer',
              background: tab === t.key ? 'var(--brand)' : 'var(--bg-input)',
              color: tab === t.key ? '#fff' : 'var(--text-2)',
              fontFamily: 'Plus Jakarta Sans, sans-serif',
            }}>{t.label}</button>
          ))}
        </div>

        {/* BOOK TAB */}
        {tab === 'book' && (
          <div className="fade-up">
            {success && <div className="alert alert-success">{success}</div>}
            {error && <div className="alert alert-error">{error}</div>}

            <p className="section-label" style={{ marginBottom: 12 }}>1. Choose a Service</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 24 }}>
              {services.map(srv => (
                <div key={srv.id} onClick={() => setSelectedService(srv.id)} style={{
                  padding: 16, borderRadius: 16, cursor: 'pointer', transition: 'all 0.2s',
                  border: selectedService === srv.id ? '2px solid var(--brand)' : '2px solid var(--border)',
                  background: selectedService === srv.id ? 'var(--brand-glow)' : 'var(--bg-card)',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15 }}>{srv.name}</div>
                    <div style={{ color: 'var(--text-3)', fontSize: 13, marginTop: 2 }}>{srv.duration_minutes} min</div>
                  </div>
                  <div style={{ fontWeight: 800, fontSize: 16, color: 'var(--brand)', fontFamily: 'Outfit, sans-serif' }}>Rs. {srv.price}</div>
                </div>
              ))}
            </div>

            <p className="section-label" style={{ marginBottom: 12 }}>2. Choose a Date</p>
            <div style={{ display: 'flex', gap: 8, overflowX: 'auto', marginBottom: 24, scrollbarWidth: 'none', paddingBottom: 4 }}>
              {next7Days.map(d => (
                <button key={d.date} onClick={() => { setSelectedDate(d.date); setSelectedSlot(null); }} style={{
                  flexShrink: 0, padding: '8px 14px', borderRadius: 12, border: 'none', cursor: 'pointer',
                  background: selectedDate === d.date ? 'var(--brand)' : 'var(--bg-input)',
                  color: selectedDate === d.date ? '#fff' : 'var(--text-2)',
                  fontWeight: 700, fontSize: 13, fontFamily: 'Plus Jakarta Sans, sans-serif',
                }}>{d.label}</button>
              ))}
            </div>

            <p className="section-label" style={{ marginBottom: 12 }}>3. Choose a Time</p>
            {slots.length === 0
              ? <p style={{ color: 'var(--text-3)', fontSize: 14, marginBottom: 24 }}>No slots available for this date.</p>
              : (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 24 }}>
                  {slots.map(slot => (
                    <button key={slot.id} onClick={() => setSelectedSlot(slot.id)} style={{
                      padding: '12px 8px', borderRadius: 14, border: 'none', cursor: 'pointer',
                      background: selectedSlot === slot.id ? 'var(--brand)' : 'var(--bg-input)',
                      color: selectedSlot === slot.id ? '#fff' : 'var(--text)',
                      fontWeight: 700, fontSize: 15, fontFamily: 'Outfit, sans-serif', transition: 'all 0.15s',
                    }}>{toAmPm(slot.start_time)}</button>
                  ))}
                </div>
              )
            }

            <div className="form-group">
              <label>Notes (optional)</label>
              <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Any special requests..." rows={3} style={{ borderRadius: 14, padding: 14, width: '100%', background: 'var(--bg-input)', border: '1.5px solid var(--border)', color: 'var(--text)', fontSize: 15, fontFamily: 'Plus Jakarta Sans, sans-serif', resize: 'none', outline: 'none' }} />
            </div>

            <button className="btn-primary" onClick={handleBook} disabled={booking || !selectedService || !selectedSlot} style={{ marginTop: 8 }}>
              {booking ? 'Booking...' : user ? 'Confirm Booking' : 'Sign in to Book'}
            </button>
          </div>
        )}

        {/* INFO TAB */}
        {tab === 'info' && (
          <div className="fade-up">
            {shop.description && <p style={{ color: 'var(--text-2)', lineHeight: 1.7, marginBottom: 24, fontSize: 15 }}>{shop.description}</p>}
            <p className="section-label" style={{ marginBottom: 14 }}>Opening Hours</p>
            {DAYS.map((day, i) => {
              const h = hours.find(h => h.day_of_week === i);
              return (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--border)', fontSize: 14 }}>
                  <span style={{ fontWeight: 600 }}>{day}</span>
                  <span style={{ color: h?.is_closed ? 'var(--brand)' : '#00C864', fontWeight: 600 }}>
                    {h ? (h.is_closed ? 'Closed' : `${toAmPm(h.open_time)} – ${toAmPm(h.close_time)}`) : '—'}
                  </span>
                </div>
              );
            })}

            {/* All images */}
            {imgs.length > 0 && (
              <>
                <p className="section-label" style={{ marginTop: 24, marginBottom: 14 }}>Photos</p>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                  {imgs.map((url, i) => (
                    <img key={i} src={url} alt="" style={{ width: '100%', height: 120, objectFit: 'cover', borderRadius: 14 }} />
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* REVIEWS TAB */}
        {tab === 'reviews' && (
          <div className="fade-up">
            {avgRating && (
              <div style={{ textAlign: 'center', padding: '20px 0 24px' }}>
                <div style={{ fontSize: 52, fontWeight: 800, fontFamily: 'Outfit, sans-serif', color: 'var(--brand)' }}>{avgRating}</div>
                <div style={{ color: 'var(--accent)', fontSize: 22, letterSpacing: 2 }}>{'★'.repeat(Math.round(avgRating))}{'☆'.repeat(5 - Math.round(avgRating))}</div>
                <div style={{ color: 'var(--text-3)', fontSize: 13, marginTop: 4 }}>{reviews.length} reviews</div>
              </div>
            )}
            {reviews.length === 0 && <p style={{ color: 'var(--text-3)', textAlign: 'center', padding: 40 }}>No reviews yet.</p>}
            {reviews.map(rev => (
              <div key={rev.id} className="card" style={{ padding: 16, marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontWeight: 700 }}>{rev.profiles?.full_name || 'Customer'}</span>
                  <span style={{ color: 'var(--accent)', fontSize: 14 }}>{'★'.repeat(rev.rating)}</span>
                </div>
                {rev.comment && <p style={{ color: 'var(--text-2)', fontSize: 14, lineHeight: 1.5 }}>{rev.comment}</p>}
                <p style={{ color: 'var(--text-3)', fontSize: 12, marginTop: 8 }}>{new Date(rev.created_at).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
