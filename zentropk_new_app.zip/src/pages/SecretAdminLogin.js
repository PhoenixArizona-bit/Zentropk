import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

// ── SHA-256 hashing (no external lib needed — uses Web Crypto API) ────────────
async function sha256(message) {
  if (!crypto?.subtle) {
    let h = 5381;
    for (let i = 0; i < message.length; i++) h = ((h << 5) + h) ^ message.charCodeAt(i);
    return (h >>> 0).toString(16).padStart(8, '0').repeat(8);
  }
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Pattern grid: 3x3, nodes 1-9
//  1 2 3
//  4 5 6
//  7 8 9
const NODE_POSITIONS = [
  { id: 1, row: 0, col: 0 }, { id: 2, row: 0, col: 1 }, { id: 3, row: 0, col: 2 },
  { id: 4, row: 1, col: 0 }, { id: 5, row: 1, col: 1 }, { id: 6, row: 1, col: 2 },
  { id: 7, row: 2, col: 0 }, { id: 8, row: 2, col: 1 }, { id: 9, row: 2, col: 2 },
];

const GRID_SIZE = 240;
const NODE_RADIUS = 18;
const DOT_RADIUS = 5;
const CELL = GRID_SIZE / 3;

function getNodeCenter(node) {
  return {
    x: node.col * CELL + CELL / 2,
    y: node.row * CELL + CELL / 2,
  };
}

function PatternLock({ onPatternComplete, disabled, error }) {
  const svgRef = useRef(null);
  const [pattern, setPattern] = useState([]);
  const [currentPos, setCurrentPos] = useState(null);
  const [drawing, setDrawing] = useState(false);
  const [flash, setFlash] = useState(null); // 'success' | 'error' | null

  const reset = () => { setPattern([]); setCurrentPos(null); setDrawing(false); };

  useEffect(() => {
    if (error) {
      setFlash('error');
      setTimeout(() => { setFlash(null); reset(); }, 600);
    }
  }, [error]);

  const getSVGPos = (e) => {
    const svg = svgRef.current;
    if (!svg) return null;
    const rect = svg.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    const scaleX = GRID_SIZE / rect.width;
    const scaleY = GRID_SIZE / rect.height;
    return { x: (clientX - rect.left) * scaleX, y: (clientY - rect.top) * scaleY };
  };

  const getNodeAt = (pos) => {
    return NODE_POSITIONS.find(n => {
      const c = getNodeCenter(n);
      return Math.hypot(pos.x - c.x, pos.y - c.y) < NODE_RADIUS + 6;
    });
  };

  const startDraw = (e) => {
    if (disabled) return;
    e.preventDefault();
    const pos = getSVGPos(e);
    if (!pos) return;
    const node = getNodeAt(pos);
    if (node) { setDrawing(true); setPattern([node.id]); setCurrentPos(pos); }
  };

  const moveDraw = (e) => {
    if (!drawing || disabled) return;
    e.preventDefault();
    const pos = getSVGPos(e);
    if (!pos) return;
    setCurrentPos(pos);
    const node = getNodeAt(pos);
    if (node && !pattern.includes(node.id)) {
      setPattern(prev => [...prev, node.id]);
    }
  };

  const endDraw = (e) => {
    if (!drawing || disabled) return;
    e.preventDefault();
    setDrawing(false);
    setCurrentPos(null);
    if (pattern.length >= 3) {
      onPatternComplete(pattern);
    } else {
      reset();
    }
  };

  const lineColor = flash === 'error' ? '#FF3D00' : flash === 'success' ? '#22c55e' : '#FF3D00';
  const nodeColor = flash === 'error' ? '#FF3D00' : '#FF3D00';

  // Build lines between connected nodes
  const lines = [];
  for (let i = 0; i < pattern.length - 1; i++) {
    const a = getNodeCenter(NODE_POSITIONS.find(n => n.id === pattern[i]));
    const b = getNodeCenter(NODE_POSITIONS.find(n => n.id === pattern[i + 1]));
    lines.push({ x1: a.x, y1: a.y, x2: b.x, y2: b.y, key: `${i}` });
  }
  // Line to current finger position
  if (drawing && currentPos && pattern.length > 0) {
    const last = getNodeCenter(NODE_POSITIONS.find(n => n.id === pattern[pattern.length - 1]));
    lines.push({ x1: last.x, y1: last.y, x2: currentPos.x, y2: currentPos.y, key: 'cur', dashed: true });
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 1 }}>
        Draw Pattern
      </div>
      <svg
        ref={svgRef}
        viewBox={`0 0 ${GRID_SIZE} ${GRID_SIZE}`}
        style={{
          width: GRID_SIZE, height: GRID_SIZE,
          touchAction: 'none', userSelect: 'none',
          borderRadius: 20,
          background: 'var(--bg-input)',
          border: `1.5px solid ${flash === 'error' ? '#FF3D00' : 'var(--border)'}`,
          transition: 'border-color 0.2s',
          opacity: disabled ? 0.5 : 1,
        }}
        onMouseDown={startDraw} onMouseMove={moveDraw} onMouseUp={endDraw} onMouseLeave={endDraw}
        onTouchStart={startDraw} onTouchMove={moveDraw} onTouchEnd={endDraw}
      >
        {/* Lines */}
        {lines.map(l => (
          <line
            key={l.key}
            x1={l.x1} y1={l.y1} x2={l.x2} y2={l.y2}
            stroke={lineColor} strokeWidth={2.5} strokeOpacity={0.7}
            strokeDasharray={l.dashed ? '4 4' : undefined}
          />
        ))}
        {/* Nodes */}
        {NODE_POSITIONS.map(node => {
          const { x, y } = getNodeCenter(node);
          const active = pattern.includes(node.id);
          return (
            <g key={node.id}>
              {/* Outer ring */}
              <circle cx={x} cy={y} r={NODE_RADIUS}
                fill="none"
                stroke={active ? nodeColor : 'var(--border)'}
                strokeWidth={active ? 2 : 1.5}
                opacity={active ? 1 : 0.5}
              />
              {/* Inner dot */}
              <circle cx={x} cy={y} r={DOT_RADIUS}
                fill={active ? nodeColor : 'var(--text-3)'}
                opacity={active ? 1 : 0.4}
              />
              {/* Order number */}
              {active && (
                <text x={x} y={y - NODE_RADIUS - 4}
                  textAnchor="middle" fontSize={9}
                  fill={nodeColor} fontWeight="bold" opacity={0.8}
                >
                  {pattern.indexOf(node.id) + 1}
                </text>
              )}
            </g>
          );
        })}
      </svg>
      {/* Pattern dots preview */}
      <div style={{ display: 'flex', gap: 4, minHeight: 12 }}>
        {pattern.map((_, i) => (
          <div key={i} style={{
            width: 8, height: 8, borderRadius: '50%',
            background: flash === 'error' ? '#FF3D00' : 'var(--brand)',
          }} />
        ))}
      </div>
    </div>
  );
}

// ── Main login page ───────────────────────────────────────────────────────────
const MAX_ATTEMPTS = 4;
const LOCK_SECONDS = 45;
const DEFAULT_PASS  = 'zentro@admin2025';
const DEFAULT_PATTERN = '1-2-3-6-9'; // default pattern: top row then right column

export default function SecretAdminLogin() {
  const navigate = useNavigate();
  const [step, setStep]           = useState('password'); // 'password' | 'pattern'
  const [password, setPassword]   = useState('');
  const [showPass, setShowPass]   = useState(false);
  const [patternError, setPatternError] = useState(0); // increment to trigger flash
  const [error, setError]         = useState('');
  const [loading, setLoading]     = useState(false);
  const [attempts, setAttempts]   = useState(0);      // password step attempts
  const [patternAttempts, setPatternAttempts] = useState(0); // pattern step attempts
  const [locked, setLocked]       = useState(false);
  const [lockTimer, setLockTimer] = useState(0);

  // Lockout countdown
  useEffect(() => {
    if (!locked) return;
    const interval = setInterval(() => {
      setLockTimer(t => {
        if (t <= 1) { setLocked(false); clearInterval(interval); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [locked]);

  const lockout = (msg) => {
    setLocked(true);
    setLockTimer(LOCK_SECONDS);
    setError(msg || `Too many attempts. Locked for ${LOCK_SECONDS}s.`);
  };

  const handlePasswordSubmit = async () => {
    if (locked) return;
    if (!password.trim()) { setError('Enter your password.'); return; }
    setLoading(true);
    setError('');

    let storedHash = await sha256(DEFAULT_PASS);
    try {
      const { data } = await supabase
        .from('app_settings').select('value').eq('key', 'admin_password_hash').maybeSingle();
      if (data?.value) storedHash = data.value;
    } catch (_) {}

    const inputHash = await sha256(password);
    setLoading(false);

    if (inputHash === storedHash) {
      setError('');
      setPatternAttempts(0); // reset pattern counter when moving to pattern step
      setStep('pattern');
    } else {
      const next = attempts + 1;
      setAttempts(next);
      if (next >= MAX_ATTEMPTS) {
        lockout();
      } else {
        setError(`Wrong password — ${MAX_ATTEMPTS - next} attempt${MAX_ATTEMPTS - next === 1 ? '' : 's'} left.`);
      }
      setPassword('');
    }
  };

  const handlePatternComplete = async (drawnPattern) => {
    if (locked) return;
    const drawnStr = drawnPattern.join('-');
    setLoading(true);

    let storedHash = await sha256(DEFAULT_PATTERN);
    try {
      const { data } = await supabase
        .from('app_settings').select('value').eq('key', 'admin_pattern_hash').maybeSingle();
      if (data?.value) storedHash = data.value;
    } catch (_) {}

    const inputHash = await sha256(drawnStr);
    setLoading(false);

    if (inputHash === storedHash) {
      sessionStorage.setItem('zentro_admin_secret', Date.now().toString());
      navigate('/account');
    } else {
      const next = patternAttempts + 1;
      setPatternAttempts(next);
      setPatternError(e => e + 1); // triggers flash in PatternLock
      if (next >= MAX_ATTEMPTS) {
        lockout();
        setStep('password');
      } else {
        setError(`Wrong pattern — ${MAX_ATTEMPTS - next} attempt${MAX_ATTEMPTS - next === 1 ? '' : 's'} left.`);
      }
    }
  };

  return (
    <div className="page fade-up" style={{
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      minHeight: '100vh', padding: '0 32px',
    }}>
      {/* Icon */}
      <div style={{
        width: 72, height: 72, borderRadius: 22,
        background: 'linear-gradient(135deg, #FF3D00, #c62800)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 32, marginBottom: 20,
        boxShadow: '0 8px 28px rgba(255,61,0,0.35)',
      }}>🔐</div>

      <h2 style={{ fontFamily: 'Outfit', fontWeight: 800, fontSize: 22, marginBottom: 6 }}>
        {step === 'password' ? 'Admin Access' : 'Draw Your Pattern'}
      </h2>
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 28, textAlign: 'center' }}>
        {step === 'password'
          ? 'Step 1 of 2 — Enter your secret password'
          : 'Step 2 of 2 — Draw your unlock pattern'}
      </p>

      {/* Step indicator */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 28 }}>
        {[1, 2].map(s => (
          <div key={s} style={{
            width: s === (step === 'password' ? 1 : 2) ? 24 : 8,
            height: 8, borderRadius: 4,
            background: s <= (step === 'password' ? 1 : 2) ? 'var(--brand)' : 'var(--border)',
            transition: 'all 0.3s',
          }} />
        ))}
      </div>

      {/* Password step */}
      {step === 'password' && (
        <div style={{ width: '100%' }}>
          <div style={{ position: 'relative', marginBottom: 20 }}>
            <input
              type={showPass ? 'text' : 'password'}
              value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handlePasswordSubmit()}
              placeholder="Secret password"
              disabled={locked}
              autoComplete="off"
              style={{
                width: '100%', padding: '14px 48px 14px 16px',
                background: 'var(--bg-input)', border: '1.5px solid var(--border)',
                borderRadius: 14, color: 'var(--text)', fontSize: 15,
                fontFamily: 'inherit', boxSizing: 'border-box',
                opacity: locked ? 0.5 : 1,
              }}
            />
            <button onClick={() => setShowPass(s => !s)} style={{
              position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)',
              background: 'none', border: 'none', cursor: 'pointer', fontSize: 18, color: 'var(--text-3)',
            }}>{showPass ? '🙈' : '👁️'}</button>
          </div>
          <button
            onClick={handlePasswordSubmit}
            disabled={loading || locked}
            style={{
              width: '100%', padding: '15px', borderRadius: 14,
              background: locked ? 'var(--bg-input)' : 'var(--brand)',
              border: 'none', color: locked ? 'var(--text-3)' : '#fff',
              fontFamily: 'Outfit', fontWeight: 800, fontSize: 16,
              cursor: locked ? 'not-allowed' : 'pointer',
            }}
          >
            {loading ? 'Checking...' : locked ? `🔒 ${lockTimer}s` : 'Next →'}
          </button>
        </div>
      )}

      {/* Pattern step */}
      {step === 'pattern' && (
        <PatternLock
          onPatternComplete={handlePatternComplete}
          disabled={locked || loading}
          error={patternError}
        />
      )}

      {/* Error */}
      {(error || locked) && (
        <div style={{
          width: '100%', padding: '12px 16px', borderRadius: 12,
          marginTop: 16,
          background: 'rgba(255,61,0,0.12)', border: '1px solid rgba(255,61,0,0.3)',
          color: '#FF3D00', fontSize: 13, fontWeight: 600, textAlign: 'center',
        }}>
          {locked ? `🔒 Too many attempts — wait ${lockTimer}s` : `⚠️ ${error}`}
        </div>
      )}

      {/* Back */}
      <button
        onClick={() => step === 'pattern' ? setStep('password') : navigate(-1)}
        style={{
          marginTop: 24, background: 'none', border: 'none',
          color: 'var(--text-3)', fontSize: 13, cursor: 'pointer',
        }}
      >{step === 'pattern' ? '← Back to password' : '← Go back'}</button>
    </div>
  );
}
