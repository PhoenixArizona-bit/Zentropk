import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { signOut, supabase } from '../lib/supabase';
import AdminPortal from './AdminPortal';

export default function Account() {
  const { user, profile, authReady } = useAuth();
  const navigate = useNavigate();
  const [showAdmin, setShowAdmin] = React.useState(false);
  const [signingOut, setSigningOut] = React.useState(false);

  const handleSignOut = async () => {
    setSigningOut(true);
    // Clear local storage immediately so stale profile isn't read on re-mount
    Object.keys(localStorage).filter(k => k.startsWith('sb-')).forEach(k => localStorage.removeItem(k));
    localStorage.removeItem('zentro_profile');
    sessionStorage.clear();
    // Force sign out after 2s even if Supabase hangs
    const timeout = setTimeout(() => {
      window.location.replace('/account');
    }, 2000);
    try {
      await supabase.auth.signOut({ scope: 'global' });
    } catch (_) {}
    clearTimeout(timeout);
    // Full page reload so React re-mounts with clean auth state — no stale user/profile
    window.location.replace('/account');
  };

  // ── Show spinner until auth resolves to prevent role flash
  if (!authReady) return (
    <div className="loading-screen">
      <div className="loading-logo">Zen<span>tro</span></div>
      <div className="spinner" />
    </div>
  );

  // ── Admin portal inline ───────────────────────────────────────────────────
  if (showAdmin) {
    return (
      <div className="page fade-up">
        <div style={{ padding: '12px 20px 4px' }}>
          <button
            onClick={() => setShowAdmin(false)}
            style={{
              background: 'none', border: '1px solid var(--border)',
              borderRadius: 10, padding: '6px 16px', cursor: 'pointer',
              color: 'var(--text-2)', fontSize: 14,
              display: 'inline-flex', alignItems: 'center', gap: 6,
            }}
          >← Back</button>
        </div>
        <AdminPortal />
      </div>
    );
  }

  // ── Not logged in ─────────────────────────────────────────────────────────
  if (!user) {
    return (
      <div className="page fade-up" style={{ padding: '0 20px' }}>
        <div className="top-header" style={{ padding: '16px 0 12px' }}>
          <span className="logo-text" style={{ userSelect: 'none' }}>Zen<span>tro</span></span>
        </div>

        <div style={{ textAlign: 'center', padding: '40px 0 32px' }}>
          <div style={{
            width: 80, height: 80, borderRadius: 24,
            background: 'var(--brand)', margin: '0 auto 20px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 36, boxShadow: '0 8px 24px var(--brand-glow)',
          }}>✂</div>
          <h1 style={{ fontSize: 28, marginBottom: 10 }}>Join Zentro</h1>
          <p style={{ color: 'var(--text-2)', fontSize: 15, lineHeight: 1.6 }}>
            Book barbers near you or list your barbershop
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginBottom: 28 }}>
          <div
            className="card pop"
            style={{ padding: 20, cursor: 'pointer', borderColor: 'transparent',
              background: 'linear-gradient(135deg, #FF3D00 0%, #FF6B35 100%)' }}
            onClick={() => navigate('/register?role=customer')}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{ fontSize: 36 }}>👤</div>
              <div>
                <div style={{ fontFamily: 'Outfit', fontWeight: 800, fontSize: 18, color: '#fff', marginBottom: 4 }}>
                  I'm a Customer
                </div>
                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)', lineHeight: 1.5 }}>
                  Find & book barbers near you instantly
                </div>
              </div>
              <div style={{ marginLeft: 'auto', color: '#fff', fontSize: 20 }}>→</div>
            </div>
          </div>

          <div
            className="card pop"
            style={{ padding: 20, cursor: 'pointer', animationDelay: '0.08s' }}
            onClick={() => navigate('/register?role=barber')}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{ fontSize: 36 }}>💈</div>
              <div>
                <div style={{ fontFamily: 'Outfit', fontWeight: 800, fontSize: 18, marginBottom: 4 }}>
                  I'm a Barber
                </div>
                <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>
                  List your shop & manage bookings
                </div>
              </div>
              <div style={{ marginLeft: 'auto', color: 'var(--text-3)', fontSize: 20 }}>→</div>
            </div>
          </div>
        </div>

        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <span style={{ color: 'var(--text-2)', fontSize: 14 }}>Already have an account? </span>
          <button
            onClick={() => navigate('/login')}
            style={{ background: 'none', border: 'none', color: 'var(--brand)', fontWeight: 700, fontSize: 14, cursor: 'pointer' }}
          >Sign in</button>
        </div>

        <div className="divider" />
        <div style={{ marginBottom: 32 }}>
          <div className="section-label" style={{ marginBottom: 16 }}>Why Zentro</div>
          {[
            { icon: '🗺️', title: 'Map-based discovery', desc: 'See all barbers near you on an interactive map' },
            { icon: '⚡', title: 'Instant booking', desc: 'Pick a slot and confirm in seconds' },
            { icon: '📱', title: 'JazzCash & EasyPaisa', desc: 'No card needed — pay how you like' },
          ].map((f, i) => (
            <div key={i} style={{ display: 'flex', gap: 14, padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ fontSize: 24, width: 40, textAlign: 'center' }}>{f.icon}</div>
              <div>
                <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 3 }}>{f.title}</div>
                <div style={{ fontSize: 13, color: 'var(--text-2)' }}>{f.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ── Logged in ─────────────────────────────────────────────────────────────
  const isAdmin  = profile?.role === 'admin';
  const isBarber = profile?.role === 'barber';

  const menuItems = [
    isAdmin
      ? { icon: '📊', label: 'Admin Panel',   action: () => setShowAdmin(true) }
      : isBarber
        ? { icon: '📊', label: 'My Dashboard', action: () => navigate('/barber/dashboard') }
        : { icon: '📅', label: 'My Bookings',  action: () => navigate('/bookings') },
    ...(isBarber ? [
      { icon: '⚙️', label: 'Shop Setup',   action: () => navigate('/barber/setup') },
      { icon: '🕐', label: 'Manage Slots', action: () => navigate('/barber/slots') },
      { icon: '💳', label: 'Payment',      action: () => navigate('/barber/payment') },
    ] : []),
  ];

  return (
    <div className="page fade-up" style={{ padding: '0 20px' }}>
      <div className="top-header" style={{ padding: '16px 0 12px' }}>
        <span className="logo-text" style={{ userSelect: 'none' }}>Zen<span>tro</span></span>
      </div>

      {/* Profile card */}
      <div className="card" style={{ padding: 20, marginBottom: 20 }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <div style={{
            width: 56, height: 56, borderRadius: 18,
            background: 'var(--brand)', display: 'flex',
            alignItems: 'center', justifyContent: 'center',
            fontSize: 24, fontWeight: 800, color: '#fff', fontFamily: 'Outfit',
          }}>
            {profile?.full_name?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase() || '?'}
          </div>
          <div>
            <div style={{ fontFamily: 'Outfit', fontWeight: 800, fontSize: 18 }}>
              {profile?.full_name || 'User'}
            </div>
            <div style={{ fontSize: 13, color: 'var(--text-2)', marginTop: 2 }}>{user.email}</div>
            <div className="pill pill-brand" style={{ marginTop: 6, fontSize: 11 }}>
              {isBarber ? '💈 Barber' : isAdmin ? '🔑 Admin' : '👤 Customer'}
            </div>
          </div>
        </div>
      </div>

      {/* Menu */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 24 }}>
        {menuItems.map(({ icon, label, action }) => (
          <button
            key={label}
            onClick={action}
            style={{
              display: 'flex', alignItems: 'center', gap: 14,
              padding: '16px 20px', background: 'var(--bg-card)',
              border: '1px solid var(--border)', borderRadius: 16,
              cursor: 'pointer', textAlign: 'left',
            }}
          >
            <span style={{ fontSize: 22 }}>{icon}</span>
            <span style={{ fontWeight: 600, fontSize: 15, color: 'var(--text)' }}>{label}</span>
            <span style={{ marginLeft: 'auto', color: 'var(--text-3)' }}>›</span>
          </button>
        ))}
      </div>

      {/* Sign out */}
      <button
        onClick={handleSignOut}
        disabled={signingOut}
        style={{
          width: '100%', padding: '15px', borderRadius: 16,
          border: '1.5px solid var(--border)', background: 'transparent',
          color: signingOut ? 'var(--text-3)' : '#FF3D00',
          fontWeight: 700, fontSize: 15, cursor: signingOut ? 'not-allowed' : 'pointer',
          fontFamily: 'Plus Jakarta Sans, sans-serif',
        }}
      >
        {signingOut ? 'Signing out...' : '↩ Sign Out'}
      </button>
    </div>
  );
}
