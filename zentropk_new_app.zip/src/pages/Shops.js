import React, { useEffect, useState, useCallback, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { useNavigate } from 'react-router-dom';
import L from 'leaflet';
import { supabase, cachedQuery } from '../lib/supabase';
import AdminPortal from './AdminPortal';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const brandIcon = new L.DivIcon({
  className: '',
  html: `<div style="
    width:36px;height:36px;border-radius:50% 50% 50% 0;
    background:#FF3D00;transform:rotate(-45deg);
    border:3px solid #fff;box-shadow:0 2px 8px rgba(255,61,0,0.5);
    display:flex;align-items:center;justify-content:center;
  "><span style="transform:rotate(45deg);font-size:14px;line-height:1">✂</span></div>`,
  iconSize: [36, 36],
  iconAnchor: [18, 36],
  popupAnchor: [0, -38],
});

function LocateButton() {
  const map = useMap();
  return (
    <button onClick={() => map.locate({ setView: true, maxZoom: 14 })} style={{
      position: 'absolute', bottom: 16, right: 16, zIndex: 800,
      width: 44, height: 44, borderRadius: 14,
      background: 'var(--bg-card)', border: '1px solid var(--border)',
      boxShadow: 'var(--shadow)', fontSize: 20, cursor: 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>📍</button>
  );
}

function ShopSkeleton() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      {[1, 2, 3].map(i => (
        <div key={i} className="card" style={{ overflow: 'hidden' }}>
          <div style={{
            height: 160,
            background: 'var(--bg-input)',
            borderRadius: '20px 20px 0 0',
            animation: 'pulse 1.4s ease-in-out infinite',
          }} />
          <div style={{ padding: '14px 16px' }}>
            <div style={{ height: 18, width: '60%', borderRadius: 8, background: 'var(--bg-input)', marginBottom: 10, animation: 'pulse 1.4s ease-in-out infinite' }} />
            <div style={{ height: 13, width: '80%', borderRadius: 8, background: 'var(--bg-input)', animation: 'pulse 1.4s ease-in-out infinite' }} />
          </div>
        </div>
      ))}
    </div>
  );
}

const DEFAULT_KEYWORD = 'zentro@admin';

// ── QR Scanner Modal ─────────────────────────────────────────────────────────
function QRScannerModal({ onClose, onResult }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [error, setError] = useState('');
  const [scanning, setScanning] = useState(true);

  useEffect(() => {
    let animFrame;
    let stopped = false;

    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          scanFrame();
        }
      } catch (e) {
        setError('Camera access denied or unavailable. Please allow camera permission.');
        setScanning(false);
      }
    };

    const scanFrame = () => {
      if (stopped || !videoRef.current) return;
      const video = videoRef.current;
      if (video.readyState === video.HAVE_ENOUGH_DATA) {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0);
        try {
          // Use BarcodeDetector if available (Chrome/Android)
          if (typeof window.BarcodeDetector !== 'undefined') {
            const detector = new window.BarcodeDetector({ formats: ['qr_code'] });
            detector.detect(canvas).then(codes => {
              if (codes.length > 0 && !stopped) {
                stopped = true;
                onResult(codes[0].rawValue);
              } else if (!stopped) {
                animFrame = requestAnimationFrame(scanFrame);
              }
            }).catch(() => { if (!stopped) animFrame = requestAnimationFrame(scanFrame); });
          } else {
            // Fallback: prompt user to open camera app
            setError('QR scanning not supported on this browser. Try Chrome on Android.');
            setScanning(false);
          }
        } catch (_) {
          if (!stopped) animFrame = requestAnimationFrame(scanFrame);
        }
      } else {
        animFrame = requestAnimationFrame(scanFrame);
      }
    };

    startCamera();

    return () => {
      stopped = true;
      cancelAnimationFrame(animFrame);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
    };
  }, []); // eslint-disable-line

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.92)',
      zIndex: 9999, display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ position: 'relative', width: '90vw', maxWidth: 380 }}>
        <div style={{
          background: 'var(--bg-card)', borderRadius: 24, overflow: 'hidden',
          boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
        }}>
          {/* Header */}
          <div style={{ padding: '18px 20px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: 17 }}>📷 Scan Shop QR</div>
            <button onClick={onClose} style={{ background: 'var(--bg-input)', border: 'none', borderRadius: 10, width: 34, height: 34, fontSize: 18, cursor: 'pointer', color: 'var(--text-2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>×</button>
          </div>

          {/* Video */}
          <div style={{ position: 'relative', background: '#000', aspectRatio: '1/1', overflow: 'hidden' }}>
            <video
              ref={videoRef}
              playsInline
              muted
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
            {scanning && !error && (
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
                <div style={{ width: 200, height: 200, position: 'relative' }}>
                  {/* Corner markers */}
                  {[{top:0,left:0},{top:0,right:0},{bottom:0,left:0},{bottom:0,right:0}].map((pos, i) => (
                    <div key={i} style={{
                      position: 'absolute', width: 32, height: 32,
                      borderColor: '#FF3D00', borderStyle: 'solid', borderRadius: 4,
                      borderWidth: 0,
                      ...(pos.top !== undefined ? { borderTopWidth: 3 } : { borderBottomWidth: 3 }),
                      ...(pos.left !== undefined ? { borderLeftWidth: 3 } : { borderRightWidth: 3 }),
                      ...pos,
                    }} />
                  ))}
                  <div style={{
                    position: 'absolute', top: '50%', left: 0, right: 0, height: 2,
                    background: 'linear-gradient(90deg, transparent, #FF3D00, transparent)',
                    animation: 'scanLine 2s ease-in-out infinite',
                  }} />
                </div>
              </div>
            )}
          </div>

          {/* Status */}
          <div style={{ padding: '14px 20px 20px', textAlign: 'center' }}>
            {error
              ? <div style={{ fontSize: 13, color: 'var(--brand)', lineHeight: 1.5 }}>{error}</div>
              : <div style={{ fontSize: 13, color: 'var(--text-3)' }}>Point camera at a Zentro shop QR code</div>
            }
          </div>
        </div>
      </div>
      <style>{`@keyframes scanLine { 0%,100%{top:10%} 50%{top:85%} }`}</style>
    </div>
  );
}

// Haversine distance in km
function getDistance(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

export default function Shops() {
  const [shops, setShops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [view, setView] = useState('list');
  const [center] = useState([31.5204, 74.3587]);
  const [userLocation, setUserLocation] = useState(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => {} // silently fail if denied
      );
    }
  }, []);
  const [showAdmin, setShowAdmin] = useState(false);
  const [secretKeyword, setSecretKeyword] = useState(DEFAULT_KEYWORD);
  const [showScanner, setShowScanner] = useState(false);
  const navigate = useNavigate();

  const handleQRResult = useCallback((raw) => {
    setShowScanner(false);
    // Extract shop ID from URL like https://zentro.netlify.app/shops/UUID
    try {
      const url = new URL(raw);
      const match = url.pathname.match(/\/shops\/([a-zA-Z0-9-]+)/);
      if (match) { navigate(`/shops/${match[1]}`); return; }
    } catch (_) {}
    // Fallback: treat as raw shop ID
    if (/^[a-zA-Z0-9-]{8,}$/.test(raw.trim())) {
      navigate(`/shops/${raw.trim()}`);
    }
  }, [navigate]);

  useEffect(() => {
    (async () => {
      // Step 1: fetch lightweight fields + settings in parallel — shows cards immediately
      const [settingsResult, shopsBasic] = await Promise.all([
        supabase
          .from('app_settings')
          .select('value')
          .eq('key', 'admin_search_keyword')
          .maybeSingle()
          .catch(() => ({ data: null })),
        cachedQuery('shops:basic', 60_000, async () => {
          const { data } = await supabase
            .from('shops')
            .select('id, name, city, address, lat, lng, images, subscription_tier, custom_badge, custom_badge_color')
            .eq('is_active', true)
            .eq('subscription_status', 'active');
          return data || [];
        }),
      ]);

      if (settingsResult?.data?.value) setSecretKeyword(settingsResult.data.value);
      setShops(shopsBasic);
      setLoading(false); // show cards right away

      // Step 2: enrich with services + reviews in background (non-blocking)
      cachedQuery('shops:list', 60_000, async () => {
        const { data } = await supabase
          .from('shops')
          .select('id, services(id,name,price), reviews(rating)')
          .eq('is_active', true)
          .eq('subscription_status', 'active');
        return data || [];
      }).then(enriched => {
        if (!enriched?.length) return;
        const map = Object.fromEntries(enriched.map(s => [s.id, s]));
        setShops(prev => prev.map(s => ({
          ...s,
          services: map[s.id]?.services ?? s.services,
          reviews: map[s.id]?.reviews ?? s.reviews,
        })));
      }).catch(() => {});
    })();
  }, []);

  const handleSearchKey = (e) => {
    if (e.key === 'Enter') {
      if (search.trim() === secretKeyword) {
        setSearch('');
        setShowAdmin(true);
      }
    }
  };

  const avgRating = (reviews) => {
    if (!reviews?.length) return null;
    return (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1);
  };

  const filtered = shops
    .filter(s =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.city.toLowerCase().includes(search.toLowerCase())
    )
    .map(s => ({
      ...s,
      distance: userLocation && s.lat && s.lng
        ? getDistance(userLocation.lat, userLocation.lng, s.lat, s.lng)
        : null,
    }))
    .sort((a, b) => {
      // Premium always first, then Pro, then Basic
      const tierOrder = { premium: 0, pro: 1, basic: 2 };
      const tierDiff = (tierOrder[a.subscription_tier] ?? 2) - (tierOrder[b.subscription_tier] ?? 2);
      if (tierDiff !== 0) return tierDiff;
      // Within same tier, sort by distance if available
      if (a.distance !== null && b.distance !== null) return a.distance - b.distance;
      return 0;
    });

  // ── Admin portal inline ──────────────────────────────────────────────────
  if (showAdmin) {
    return (
      <div className="page fade-up">
        <div style={{ padding: '12px 20px 4px' }}>
          <button
            onClick={() => setShowAdmin(false)}
            style={{
              background: 'none', border: '1px solid var(--border)',
              borderRadius: 10, padding: '6px 16px', cursor: 'pointer',
              color: 'var(--text-2)', fontSize: 14,
              display: 'inline-flex', alignItems: 'center', gap: 6,
            }}
          >← Back</button>
        </div>
        <AdminPortal />
      </div>
    );
  }

  return (
    <div className="page" style={{ paddingBottom: 72 }}>
      {/* Header */}
      <div className="top-header">
        <span className="logo-text">Zen<span>tro</span></span>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            className="btn-ghost"
            style={{
              padding: '8px 16px', fontSize: 13,
              background: view === 'map' ? 'var(--brand)' : 'var(--bg-input)',
              color: view === 'map' ? '#fff' : 'var(--text)',
            }}
            onClick={() => setView('map')}
          >Map</button>
          <button
            className="btn-ghost"
            style={{
              padding: '8px 16px', fontSize: 13,
              background: view === 'list' ? 'var(--brand)' : 'var(--bg-input)',
              color: view === 'list' ? '#fff' : 'var(--text)',
            }}
            onClick={() => setView('list')}
          >List</button>
        </div>
      </div>

      {/* QR Scanner Modal */}
      {showScanner && <QRScannerModal onClose={() => setShowScanner(false)} onResult={handleQRResult} />}

      {/* Search bar */}
      <div style={{ padding: '0 16px 12px' }}>
        <div style={{ position: 'relative' }}>
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', fontSize: 16, pointerEvents: 'none' }}>🔍</span>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={handleSearchKey}
            placeholder="Search barbers or city..."
            style={{ paddingLeft: 40, paddingRight: 48 }}
          />
          <button
            onClick={() => setShowScanner(true)}
            title="Scan QR code to find a shop"
            style={{
              position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)',
              background: 'var(--brand)', border: 'none', borderRadius: 8,
              width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 15, cursor: 'pointer', color: '#fff',
            }}
          >📷</button>
        </div>
      </div>

      {/* Map view */}
      {view === 'map' && (
        <div style={{ padding: '0 16px 0', height: 420 }} className="fade-up">
          <div style={{ height: '100%', width: '100%', borderRadius: 20, overflow: 'hidden', position: 'relative' }}>
            <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }} zoomControl={false}>
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org">OSM</a>'
                url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
                maxZoom={19}
              />
              <LocateButton />
              {filtered.map(shop => (
                shop.lat && shop.lng ? (
                  <Marker key={shop.id} position={[shop.lat, shop.lng]} icon={brandIcon}>
                    <Popup>
                      <div style={{ padding: 4, minWidth: 160 }}>
                        <div style={{ fontFamily: 'Outfit', fontWeight: 700, fontSize: 15, marginBottom: 4 }}>{shop.name}</div>
                        <div style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: 8 }}>📍 {shop.city}</div>
                        {avgRating(shop.reviews) && <div style={{ fontSize: 12, marginBottom: 8 }}>⭐ {avgRating(shop.reviews)}</div>}
                        <button
                          onClick={() => navigate(`/shops/${shop.id}`)}
                          style={{ background: '#FF3D00', color: '#fff', border: 'none', borderRadius: 10, padding: '8px 16px', fontSize: 13, fontWeight: 700, cursor: 'pointer', width: '100%' }}
                        >Book Now →</button>
                      </div>
                    </Popup>
                  </Marker>
                ) : null
              ))}
            </MapContainer>
          </div>
          {!loading && filtered.length === 0 && (
            <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-3)' }}>No shops found nearby</div>
          )}
        </div>
      )}

      {/* List view */}
      {view === 'list' && (
        <div style={{ padding: '0 16px' }} className="fade-up">
          {loading && <ShopSkeleton />}
          {!loading && filtered.length === 0 && (
            <div style={{ textAlign: 'center', padding: 60, color: 'var(--text-3)' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>✂️</div>
              <div style={{ fontSize: 16, fontWeight: 600 }}>No shops found</div>
            </div>
          )}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {filtered.map((shop, i) => {
              const rating = avgRating(shop.reviews);
              const minPrice = shop.services?.length ? Math.min(...shop.services.map(s => s.price)) : null;
              return (
                <div
                  key={shop.id}
                  className="card fade-up"
                  style={{ animationDelay: `${i * 0.05}s`, cursor: 'pointer' }}
                  onClick={() => navigate(`/shops/${shop.id}`)}
                >
                  <div style={{ height: 160, background: 'var(--bg-input)', overflow: 'hidden', position: 'relative', borderRadius: '20px 20px 0 0' }}>
                    {shop.images?.[0]
                      ? <img src={shop.images[0]} alt={shop.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      : <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 52 }}>💈</div>
                    }
                    {rating && (
                      <div style={{
                        position: 'absolute', top: 10, right: 10,
                        background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(8px)',
                        borderRadius: 10, padding: '4px 10px', fontSize: 13, fontWeight: 700, color: '#FFB800'
                      }}>⭐ {rating}</div>
                    )}
                    {shop.subscription_tier === 'premium' && !shop.custom_badge && (
                      <div style={{
                        position: 'absolute', top: 10, left: 10,
                        background: 'linear-gradient(135deg, #FFB800, #FF6B00)',
                        borderRadius: 6, padding: '4px 10px',
                        fontSize: 10, fontWeight: 900, color: '#fff',
                        boxShadow: '0 2px 10px rgba(255,184,0,0.6)',
                        letterSpacing: 1.5, textTransform: 'uppercase',
                        backdropFilter: 'blur(4px)',
                      }}>PREMIUM</div>
                    )}
                    {shop.custom_badge && (
                      <div style={{
                        position: 'absolute', top: 10, left: 10,
                        background: shop.custom_badge_color
                          ? `linear-gradient(135deg, ${shop.custom_badge_color}dd, ${shop.custom_badge_color}99)`
                          : 'linear-gradient(135deg, #FF3D00, #c62800)',
                        borderRadius: 6, padding: '4px 10px',
                        fontSize: 10, fontWeight: 900, color: '#fff',
                        boxShadow: `0 2px 10px ${shop.custom_badge_color || '#FF3D00'}55`,
                        letterSpacing: 1.5, textTransform: 'uppercase',
                        backdropFilter: 'blur(4px)',
                      }}>{shop.custom_badge}</div>
                    )}

                  </div>
                  <div style={{ padding: '14px 16px' }}>
                    <div style={{ fontFamily: 'Outfit', fontWeight: 700, fontSize: 17, marginBottom: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{shop.name}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      📍 {shop.city} · {shop.address}
                    </div>
                    {shop.distance !== null && (
                      <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: -8, marginBottom: 8, fontWeight: 600 }}>
                        {shop.distance < 1 ? `${Math.round(shop.distance * 1000)}m away` : `${shop.distance.toFixed(1)}km away`}
                      </div>
                    )}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      {minPrice
                        ? <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--brand)' }}>From Rs. {minPrice}</span>
                        : <span />
                      }
                      <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-3)' }}>Book →</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
