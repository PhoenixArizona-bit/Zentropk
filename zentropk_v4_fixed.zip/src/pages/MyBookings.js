import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, cachedQuery, invalidateCache } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

function toAmPm(time) {
  if (!time) return '';
  const [h, m] = time.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 || 12;
  return `${hour}:${String(m).padStart(2, '0')} ${ampm}`;
}

export default function MyBookings() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviewing, setReviewing] = useState(null);
  const [review, setReview] = useState({ rating: 5, comment: '' });
  const [msg, setMsg] = useState({ type: '', text: '' });

  useEffect(() => {
    if (!authReady) return;
    if (user) fetchBookings();
  }, [user, authReady]); // eslint-disable-line

  const fetchBookings = async (bust = false) => {
    if (bust) invalidateCache(`bookings:${user.id}`);
    const data = await cachedQuery(`bookings:${user.id}`, 30_000, async () => {
      const { data: d } = await supabase
        .from('bookings')
        .select('*, shops(name, city, id), services(name, price), time_slots(slot_date, start_time), reviews(id)')
        .eq('customer_id', user.id)
        .order('created_at', { ascending: false });
      return d || [];
    });
    setBookings(data);
    setLoading(false);
  };

  const submitReview = async (bookingId, shopId) => {
    const { error } = await supabase.from('reviews').insert({ shop_id: shopId, customer_id: user.id, booking_id: bookingId, rating: review.rating, comment: review.comment });
    if (error) { setMsg({ type: 'error', text: 'Failed to submit review: ' + error.message }); setTimeout(() => setMsg({ type: '', text: '' }), 4000); return; }
    setReviewing(null);
    setMsg({ type: 'success', text: 'Review submitted!' });
    fetchBookings(true);
    setTimeout(() => setMsg({ type: '', text: '' }), 3000);
  };

  const statusColor = (s) => ({
    confirmed: { bg: 'rgba(0,200,100,0.12)', color: '#00C864' },
    pending: { bg: 'rgba(255,184,0,0.15)', color: '#FFB800' },
    cancelled: { bg: 'rgba(255,61,0,0.1)', color: 'var(--brand)' },
    completed: { bg: 'var(--bg-input)', color: 'var(--text-3)' },
  }[s] || { bg: 'var(--bg-input)', color: 'var(--text-3)' });



  if (loading) return (
    <div className="page fade-up" style={{ padding: '0 20px', paddingBottom: 100 }}>
      <div className="top-header">
        <div className="logo-text">📅 <span>Bookings</span></div>
      </div>
      {[1,2,3].map(i => (
        <div key={i} className="card" style={{ padding: 16, marginBottom: 12 }}>
          <div style={{ height: 16, width: '50%', borderRadius: 8, background: 'var(--bg-input)', marginBottom: 10, animation: 'pulse 1.4s ease-in-out infinite' }} />
          <div style={{ height: 13, width: '70%', borderRadius: 8, background: 'var(--bg-input)', animation: 'pulse 1.4s ease-in-out infinite' }} />
        </div>
      ))}
    </div>
  );

  return (
    <div className="page fade-up" style={{ padding: '0 20px', paddingBottom: 100 }}>
      <div className="top-header">
        <div className="logo-text">📅 <span>Bookings</span></div>
      </div>

      {msg.text && <div className={`alert alert-${msg.type}`}>{msg.text}</div>}

      {bookings.length === 0 && (
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <div style={{ fontSize: 56, marginBottom: 16 }}>📅</div>
          <h2 style={{ marginBottom: 10 }}>No bookings yet</h2>
          <p style={{ color: 'var(--text-2)', marginBottom: 24 }}>Find a barber and book your first appointment.</p>
          <button className="btn-primary" onClick={() => navigate('/shops')} style={{ maxWidth: 240 }}>Explore Barbers</button>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {bookings.map(bk => {
          const sc = statusColor(bk.status);
          return (
            <div key={bk.id} className="card" style={{ padding: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 16, fontFamily: 'Outfit, sans-serif' }}>{bk.shops?.name}</div>
                  <div style={{ color: 'var(--text-3)', fontSize: 13, marginTop: 2 }}>📍 {bk.shops?.city}</div>
                </div>
                <span style={{ padding: '4px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: sc.bg, color: sc.color }}>{bk.status}</span>
              </div>

              <div style={{ background: 'var(--bg-input)', borderRadius: 12, padding: '10px 14px', marginBottom: 10 }}>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{bk.services?.name}</div>
                <div style={{ color: 'var(--brand)', fontWeight: 800, fontSize: 15, fontFamily: 'Outfit, sans-serif', marginTop: 2 }}>Rs. {bk.services?.price}</div>
                <div style={{ color: 'var(--text-3)', fontSize: 13, marginTop: 4 }}>📅 {bk.time_slots?.slot_date} at {toAmPm(bk.time_slots?.start_time)}</div>
              </div>

              {bk.status === 'completed' && !bk.reviews?.length && (
                <button onClick={() => setReviewing(bk.id)} style={{ width: '100%', padding: '10px', borderRadius: 12, border: '2px solid var(--brand)', background: 'var(--brand-glow)', color: 'var(--brand)', fontWeight: 700, fontSize: 14, cursor: 'pointer', fontFamily: 'Plus Jakarta Sans, sans-serif' }}>
                  ★ Leave a Review
                </button>
              )}
              {bk.reviews?.length > 0 && (
                <div style={{ color: '#00C864', fontSize: 13, fontWeight: 600, textAlign: 'center' }}>✓ Reviewed</div>
              )}

              {reviewing === bk.id && (
                <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--border)' }}>
                  <p className="section-label" style={{ marginBottom: 12 }}>Your Rating</p>
                  <div style={{ display: 'flex', gap: 6, marginBottom: 16, justifyContent: 'center' }}>
                    {[1,2,3,4,5].map(n => (
                      <span key={n} onClick={() => setReview({...review, rating: n})} style={{ fontSize: 32, cursor: 'pointer', color: n <= review.rating ? 'var(--accent)' : 'var(--border)', transition: 'color 0.15s' }}>★</span>
                    ))}
                  </div>
                  <div className="form-group">
                    <label>Comment (optional)</label>
                    <textarea value={review.comment} onChange={e => setReview({...review, comment: e.target.value})} rows={3} placeholder="How was your experience?" style={{ borderRadius: 14, padding: 14, width: '100%', background: 'var(--bg-input)', border: '1.5px solid var(--border)', color: 'var(--text)', fontSize: 15, fontFamily: 'Plus Jakarta Sans, sans-serif', resize: 'none', outline: 'none' }} />
                  </div>
                  <div style={{ display: 'flex', gap: 10 }}>
                    <button className="btn-primary" onClick={() => submitReview(bk.id, bk.shops?.id)} style={{ flex: 1 }}>Submit</button>
                    <button onClick={() => setReviewing(null)} style={{ flex: 1, padding: '14px', borderRadius: 16, border: '2px solid var(--border)', background: 'transparent', color: 'var(--text-2)', fontWeight: 700, fontSize: 15, cursor: 'pointer' }}>Cancel</button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
