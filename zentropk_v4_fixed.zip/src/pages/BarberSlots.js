import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { format, addDays } from 'date-fns';

// Converts "14:30" or "14:30:00" → "2:30 PM"
function toAmPm(time) {
  if (!time) return '';
  const [h, m] = time.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 || 12;
  return `${hour}:${String(m).padStart(2, '0')} ${ampm}`;
}

// Converts "HH:MM" 24h to 12h for <input type="time"> display label
function formatTimeLabel(t) { return toAmPm(t); }

export default function BarberSlots() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [shopId, setShopId] = useState(null);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [slots, setSlots] = useState([]);
  const [generating, setGenerating] = useState(false);
  const [msg, setMsg] = useState('');
  const [genConfig, setGenConfig] = useState({ startTime: '09:00', endTime: '20:00', intervalMins: 30 });

  const next14Days = Array.from({ length: 14 }, (_, i) => {
    const d = addDays(new Date(), i);
    return { date: format(d, 'yyyy-MM-dd'), label: i === 0 ? 'Today' : format(d, 'EEE d') };
  });

  useEffect(() => { if (user) loadShop(); }, [user]);
  useEffect(() => { if (shopId) loadSlots(); }, [shopId, selectedDate]);

  const loadShop = async () => {
    const { data } = await supabase.from('shops').select('id').eq('owner_id', user.id).maybeSingle();
    if (data) setShopId(data.id);
  };

  const loadSlots = async () => {
    const { data } = await supabase.from('time_slots').select('*').eq('shop_id', shopId).eq('slot_date', selectedDate).order('start_time');
    setSlots(data || []);
  };

  const generateSlots = async () => {
    if (!shopId) return;
    setGenerating(true);
    const { startTime, endTime, intervalMins } = genConfig;
    const slotsToInsert = [];
    let current = new Date(`2000-01-01T${startTime}:00`);
    const end = new Date(`2000-01-01T${endTime}:00`);
    while (current < end) {
      const next = new Date(current.getTime() + intervalMins * 60000);
      if (next > end) break;
      slotsToInsert.push({ shop_id: shopId, slot_date: selectedDate, start_time: current.toTimeString().slice(0, 5), end_time: next.toTimeString().slice(0, 5) });
      current = next;
    }

    // Step 1: get slot IDs for this date so we can delete their bookings first
    const { data: existingSlots } = await supabase
      .from('time_slots').select('id').eq('shop_id', shopId).eq('slot_date', selectedDate);
    const slotIds = (existingSlots || []).map(s => s.id);

    // Step 2: delete bookings that reference those slots (fixes FK constraint)
    if (slotIds.length > 0) {
      await supabase.from('bookings').delete().in('slot_id', slotIds);
    }

    // Step 3: now safe to delete the slots
    const { error: delError } = await supabase.from('time_slots').delete().eq('shop_id', shopId).eq('slot_date', selectedDate);
    if (delError) { setMsg('Error clearing old slots: ' + delError.message); setGenerating(false); return; }
    if (slotsToInsert.length) {
      const { error: insError } = await supabase.from('time_slots').insert(slotsToInsert);
      if (insError) { setMsg('Error saving slots: ' + insError.message); setGenerating(false); return; }
    }
    setGenerating(false);
    setMsg(`Generated ${slotsToInsert.length} slots for ${selectedDate}`);
    setTimeout(() => setMsg(''), 3000);
    loadSlots();
  };

  const [busy, setBusy] = useState(null); // slot id being mutated

  const toggleSlot = async (id, isAvailable) => {
    if (busy) return;
    setBusy(id);
    const { error } = await supabase.from('time_slots').update({ is_available: !isAvailable }).eq('id', id);
    if (error) setMsg('Failed to toggle slot: ' + error.message);
    await loadSlots();
    setBusy(null);
  };

  const deleteSlot = async (id) => {
    if (busy) return;
    setBusy(id);
    const { error } = await supabase.from('time_slots').delete().eq('id', id);
    if (error) setMsg('Failed to delete slot: ' + error.message);
    await loadSlots();
    setBusy(null);
  };

  return (
    <div className="page fade-up" style={{ padding: '0 20px', paddingBottom: 100 }}>
      <div className="top-header">
        <button onClick={() => navigate(-1)} style={{ background: 'none', border: 'none', color: 'var(--text-2)', fontSize: 22, cursor: 'pointer' }}>←</button>
        <div className="logo-text">🕐 <span>Slots</span></div>
        <div style={{ width: 32 }} />
      </div>

      {msg && <div className="alert alert-success">{msg}</div>}

      {/* Date scroller */}
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 16, scrollbarWidth: 'none' }}>
        {next14Days.map(d => (
          <button key={d.date} onClick={() => setSelectedDate(d.date)} style={{
            flexShrink: 0, padding: '8px 14px', borderRadius: 12,
            border: selectedDate === d.date ? '2px solid var(--brand)' : '2px solid var(--border)',
            background: selectedDate === d.date ? 'var(--brand-glow)' : 'var(--bg-input)',
            color: selectedDate === d.date ? 'var(--brand)' : 'var(--text-2)',
            fontWeight: 700, fontSize: 13, cursor: 'pointer', fontFamily: 'Plus Jakarta Sans, sans-serif',
          }}>{d.label}</button>
        ))}
      </div>

      {/* Generator */}
      <div className="card" style={{ padding: 16, marginBottom: 20 }}>
        <p className="section-label" style={{ marginBottom: 14 }}>Auto-Generate for {selectedDate}</p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
          <div className="form-group" style={{ margin: 0 }}>
            <label>Start Time</label>
            <input type="time" value={genConfig.startTime} onChange={e => setGenConfig({...genConfig, startTime: e.target.value})} />
            <div style={{ fontSize: 11, color: 'var(--brand)', fontWeight: 700, marginTop: 4 }}>{formatTimeLabel(genConfig.startTime)}</div>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>End Time</label>
            <input type="time" value={genConfig.endTime} onChange={e => setGenConfig({...genConfig, endTime: e.target.value})} />
            <div style={{ fontSize: 11, color: 'var(--brand)', fontWeight: 700, marginTop: 4 }}>{formatTimeLabel(genConfig.endTime)}</div>
          </div>
        </div>
        <div className="form-group" style={{ marginBottom: 12 }}>
          <label>Slot Duration</label>
          <select value={genConfig.intervalMins} onChange={e => setGenConfig({...genConfig, intervalMins: parseInt(e.target.value)})}>
            <option value={15}>15 min</option>
            <option value={20}>20 min</option>
            <option value={30}>30 min</option>
            <option value={45}>45 min</option>
            <option value={60}>60 min</option>
          </select>
        </div>
        <div style={{ color: 'var(--text-3)', fontSize: 12, marginBottom: 12 }}>⚠️ This replaces all existing slots for the selected date.</div>
        <button className="btn-primary" onClick={generateSlots} disabled={generating}>{generating ? 'Generating...' : '⚡ Generate Slots'}</button>
      </div>

      {/* Slots grid */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <p className="section-label" style={{ margin: 0 }}>Slots ({slots.length})</p>
      </div>
      {slots.length === 0 && <p style={{ color: 'var(--text-3)', textAlign: 'center', padding: 40 }}>No slots yet. Use the generator above.</p>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
        {slots.map(slot => (
          <div key={slot.id} style={{
            borderRadius: 14, padding: '12px 10px', textAlign: 'center',
            background: slot.is_available ? 'rgba(0,200,100,0.08)' : 'rgba(255,61,0,0.06)',
            border: `1.5px solid ${slot.is_available ? 'rgba(0,200,100,0.25)' : 'rgba(255,61,0,0.2)'}`,
          }}>
            <div style={{ fontWeight: 700, fontSize: 15, fontFamily: 'Outfit, sans-serif' }}>{toAmPm(slot.start_time)}</div>
            <div style={{ fontSize: 10, fontWeight: 600, color: slot.is_available ? '#00C864' : 'var(--brand)', marginTop: 2 }}>
              {slot.is_available ? 'Available' : 'Booked'}
            </div>
            <div style={{ display: 'flex', gap: 4, marginTop: 8, justifyContent: 'center' }}>
              <button onClick={() => toggleSlot(slot.id, slot.is_available)} disabled={busy === slot.id} style={{ fontSize: 10, background: 'var(--bg-input)', border: 'none', color: 'var(--text-2)', padding: '3px 8px', borderRadius: 6, cursor: busy === slot.id ? 'not-allowed' : 'pointer', fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 600, opacity: busy === slot.id ? 0.5 : 1 }}>
                {slot.is_available ? 'Block' : 'Open'}
              </button>
              <button onClick={() => deleteSlot(slot.id)} disabled={busy === slot.id} style={{ fontSize: 10, background: 'rgba(255,61,0,0.1)', border: 'none', color: 'var(--brand)', padding: '3px 8px', borderRadius: 6, cursor: busy === slot.id ? 'not-allowed' : 'pointer', fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 600, opacity: busy === slot.id ? 0.5 : 1 }}>Del</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
