/**
 * AdminShops.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Rendered ONLY at /admin. Visually identical to Shops.js but this is the
 * ONLY file in the entire codebase that imports AdminPortal. Normal users
 * loading /shops get Shops.js — which has zero reference to AdminPortal.
 *
 * Secret trigger: type the keyword into the search bar and press Enter.
 * The keyword is stored in Supabase app_settings (key: admin_search_keyword).
 * Default fallback: 'zentro@admin'
 */

import React, { useEffect, useState, useCallback, useRef, useMemo, lazy, Suspense } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, cachedQuery } from '../lib/supabase';

// AdminPortal — only fetched when showAdmin flips true (user typed keyword)
// Normal /shops users never trigger this import at all.
const AdminPortal = lazy(() => import('./AdminPortal'));
const LeafletMap  = lazy(() => import('../components/ShopsMap'));

const DEFAULT_KEYWORD = 'zentro@admin';

function ShopSkeleton() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      {[1, 2, 3].map(i => (
        <div key={i} className="card" style={{ overflow: 'hidden' }}>
          <div style={{ height: 160, background: 'var(--bg-input)', borderRadius: '20px 20px 0 0', animation: 'pulse 1.4s ease-in-out infinite' }} />
          <div style={{ padding: '14px 16px' }}>
            <div style={{ height: 18, width: '60%', borderRadius: 8, background: 'var(--bg-input)', marginBottom: 10, animation: 'pulse 1.4s ease-in-out infinite' }} />
            <div style={{ height: 13, width: '80%', borderRadius: 8, background: 'var(--bg-input)', animation: 'pulse 1.4s ease-in-out infinite' }} />
          </div>
        </div>
      ))}
    </div>
  );
}

// ── QR Scanner Modal ──────────────────────────────────────────────────────────
function QRScannerModal({ onClose, onResult }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [error, setError] = useState('');
  const [scanning, setScanning] = useState(true);

  useEffect(() => {
    let animFrame;
    let stopped = false;
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          scanFrame();
        }
      } catch {
        setError('Camera access denied or unavailable. Please allow camera permission.');
        setScanning(false);
      }
    };
    const scanFrame = () => {
      if (stopped || !videoRef.current) return;
      const video = videoRef.current;
      if (video.readyState === video.HAVE_ENOUGH_DATA) {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth; canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0);
        try {
          if (typeof window.BarcodeDetector !== 'undefined') {
            const detector = new window.BarcodeDetector({ formats: ['qr_code'] });
            detector.detect(canvas).then(codes => {
              if (codes.length > 0 && !stopped) { stopped = true; onResult(codes[0].rawValue); }
              else if (!stopped) animFrame = requestAnimationFrame(scanFrame);
            }).catch(() => { if (!stopped) animFrame = requestAnimationFrame(scanFrame); });
          } else {
            setError('QR scanning not supported on this browser. Try Chrome on Android.');
            setScanning(false);
          }
        } catch { if (!stopped) animFrame = requestAnimationFrame(scanFrame); }
      } else { animFrame = requestAnimationFrame(scanFrame); }
    };
    startCamera();
    return () => {
      stopped = true; cancelAnimationFrame(animFrame);
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    };
  }, []); // eslint-disable-line

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.92)', zIndex: 9999, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ position: 'relative', width: '90vw', maxWidth: 380 }}>
        <div style={{ background: 'var(--bg-card)', borderRadius: 24, overflow: 'hidden', boxShadow: '0 20px 60px rgba(0,0,0,0.5)' }}>
          <div style={{ padding: '18px 20px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: 17 }}>📷 Scan Shop QR</div>
            <button onClick={onClose} style={{ background: 'var(--bg-input)', border: 'none', borderRadius: 10, width: 34, height: 34, fontSize: 18, cursor: 'pointer', color: 'var(--text-2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>×</button>
          </div>
          <div style={{ position: 'relative', background: '#000', aspectRatio: '1/1', overflow: 'hidden' }}>
            <video ref={videoRef} playsInline muted style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            {scanning && !error && (
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
                <div style={{ width: 200, height: 200, position: 'relative' }}>
                  {[{top:0,left:0},{top:0,right:0},{bottom:0,left:0},{bottom:0,right:0}].map((pos, i) => (
                    <div key={i} style={{ position: 'absolute', width: 32, height: 32, borderColor: '#FF3D00', borderStyle: 'solid', borderRadius: 4, borderWidth: 0, ...(pos.top !== undefined ? { borderTopWidth: 3 } : { borderBottomWidth: 3 }), ...(pos.left !== undefined ? { borderLeftWidth: 3 } : { borderRightWidth: 3 }), ...pos }} />
                  ))}
                  <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: 2, background: 'linear-gradient(90deg, transparent, #FF3D00, transparent)', animation: 'scanLine 2s ease-in-out infinite' }} />
                </div>
              </div>
            )}
          </div>
          <div style={{ padding: '14px 20px 20px', textAlign: 'center' }}>
            {error
              ? <div style={{ fontSize: 13, color: 'var(--brand)', lineHeight: 1.5 }}>{error}</div>
              : <div style={{ fontSize: 13, color: 'var(--text-3)' }}>Point camera at a Zentro shop QR code</div>
            }
          </div>
        </div>
      </div>
      <style>{`@keyframes scanLine { 0%,100%{top:10%} 50%{top:85%} }`}</style>
    </div>
  );
}

function getDistance(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

export default function AdminShops() {
  const [shops, setShops] = useState(() => {
    try {
      const cached = localStorage.getItem('zc:shops:basic');
      if (cached) {
        const { data, ts } = JSON.parse(cached);
        if (data?.length && Date.now() - ts < 180_000) return data;
      }
    } catch {}
    return [];
  });
  const [loading, setLoading] = useState(() => {
    try {
      const cached = localStorage.getItem('zc:shops:basic');
      if (cached) {
        const { data, ts } = JSON.parse(cached);
        if (data?.length && Date.now() - ts < 180_000) return false;
      }
    } catch {}
    return true;
  });
  const [search, setSearch]         = useState('');
  const [view, setView]             = useState('list');
  const [center]                    = useState([31.5204, 74.3587]);
  const [userLocation, setUserLocation] = useState(null);
  const [showAdmin, setShowAdmin]   = useState(false);
  const [secretKeyword, setSecretKeyword] = useState(DEFAULT_KEYWORD);
  const [showScanner, setShowScanner] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => {}
      );
    }
  }, []);

  const handleQRResult = useCallback((raw) => {
    setShowScanner(false);
    try {
      const url = new URL(raw);
      const match = url.pathname.match(/\/shops\/([a-zA-Z0-9-]+)/);
      if (match) { navigate(`/shops/${match[1]}`); return; }
    } catch {}
    if (/^[a-zA-Z0-9-]{8,}$/.test(raw.trim())) navigate(`/shops/${raw.trim()}`);
  }, [navigate]);

  useEffect(() => {
    (async () => {
      const [settingsResult, shopsBasic] = await Promise.all([
        supabase.from('app_settings').select('value').eq('key', 'admin_search_keyword').maybeSingle().then(r => r).catch(() => ({ data: null })),
        cachedQuery('shops:basic', 180_000, async () => {
          const { data } = await supabase
            .from('shops')
            .select('id, name, city, address, lat, lng, images, subscription_tier, custom_badge, custom_badge_color')
            .eq('is_active', true).eq('subscription_status', 'active');
          return data || [];
        }),
      ]);

      if (settingsResult?.data?.value) setSecretKeyword(settingsResult.data.value);
      setShops(shopsBasic);
      setLoading(false);

      cachedQuery('shops:list', 180_000, async () => {
        const { data } = await supabase
          .from('shops').select('id, services(id,name,price), reviews(rating)')
          .eq('is_active', true).eq('subscription_status', 'active');
        return data || [];
      }).then(enriched => {
        if (!enriched?.length) return;
        const map = Object.fromEntries(enriched.map(s => [s.id, s]));
        setShops(prev => prev.map(s => ({
          ...s,
          services: map[s.id]?.services ?? s.services,
          reviews:  map[s.id]?.reviews  ?? s.reviews,
        })));
      }).catch(() => {});
    })();
  }, []);

  // ── Secret trigger — type keyword + Enter to reveal portal ───────────────────
  const handleSearchKey = (e) => {
    if (e.key === 'Enter' && search.trim() === secretKeyword) {
      setSearch('');
      setShowAdmin(true);
    }
  };

  const avgRating = (reviews) => {
    if (!reviews?.length) return null;
    return (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1);
  };

  const filtered = useMemo(() => shops
    .filter(s =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.city.toLowerCase().includes(search.toLowerCase())
    )
    .map(s => ({
      ...s,
      distance: userLocation && s.lat && s.lng
        ? getDistance(userLocation.lat, userLocation.lng, s.lat, s.lng)
        : null,
    }))
    .sort((a, b) => {
      const tierOrder = { premium: 0, pro: 1, basic: 2 };
      const tierDiff = (tierOrder[a.subscription_tier] ?? 2) - (tierOrder[b.subscription_tier] ?? 2);
      if (tierDiff !== 0) return tierDiff;
      if (a.distance !== null && b.distance !== null) return a.distance - b.distance;
      return 0;
    }), [shops, search, userLocation]);

  // ── Admin portal — only rendered after keyword is entered ────────────────────
  if (showAdmin) {
    return (
      <div className="page fade-up">
        <div style={{ padding: '12px 20px 4px' }}>
          <button
            onClick={() => setShowAdmin(false)}
            style={{
              background: 'none', border: '1px solid var(--border)',
              borderRadius: 10, padding: '6px 16px', cursor: 'pointer',
              color: 'var(--text-2)', fontSize: 14,
              display: 'inline-flex', alignItems: 'center', gap: 6,
            }}
          >← Back</button>
        </div>
        <Suspense fallback={<div className="spinner" style={{ margin: '40px auto' }} />}>
          <AdminPortal />
        </Suspense>
      </div>
    );
  }

  // ── Normal shops UI — identical to /shops ────────────────────────────────────
  return (
    <div className="page" style={{ paddingBottom: 72 }}>
      <div className="top-header">
        <span className="logo-text">Zen<span>tro</span></span>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn-ghost" style={{ padding: '8px 16px', fontSize: 13, background: view === 'map' ? 'var(--brand)' : 'var(--bg-input)', color: view === 'map' ? '#fff' : 'var(--text)' }} onClick={() => setView('map')}>Map</button>
          <button className="btn-ghost" style={{ padding: '8px 16px', fontSize: 13, background: view === 'list' ? 'var(--brand)' : 'var(--bg-input)', color: view === 'list' ? '#fff' : 'var(--text)' }} onClick={() => setView('list')}>List</button>
        </div>
      </div>

      {showScanner && <QRScannerModal onClose={() => setShowScanner(false)} onResult={handleQRResult} />}

      <div style={{ padding: '0 16px 12px' }}>
        <div style={{ position: 'relative' }}>
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', fontSize: 16, pointerEvents: 'none' }}>🔍</span>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={handleSearchKey}
            placeholder="Search barbers or city..."
            style={{ paddingLeft: 40, paddingRight: 48 }}
          />
          <button
            onClick={() => setShowScanner(true)}
            title="Scan QR code to find a shop"
            style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', background: 'var(--brand)', border: 'none', borderRadius: 8, width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, cursor: 'pointer', color: '#fff' }}
          >📷</button>
        </div>
      </div>

      {view === 'map' && (
        <Suspense fallback={<div style={{ height: 420, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-3)' }}>Loading map...</div>}>
          <LeafletMap shops={filtered} center={center} avgRating={avgRating} onShopClick={(id) => navigate(`/shops/${id}`)} />
        </Suspense>
      )}

      {view === 'list' && (
        <div style={{ padding: '0 16px' }} className="fade-up">
          {loading && <ShopSkeleton />}
          {!loading && filtered.length === 0 && (
            <div style={{ textAlign: 'center', padding: 60, color: 'var(--text-3)' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>✂️</div>
              <div style={{ fontSize: 16, fontWeight: 600 }}>No shops found</div>
            </div>
          )}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {filtered.map((shop, i) => {
              const rating = avgRating(shop.reviews);
              const minPrice = shop.services?.length ? Math.min(...shop.services.map(s => s.price)) : null;
              return (
                <div key={shop.id} className="card fade-up" style={{ animationDelay: `${i * 0.05}s`, cursor: 'pointer' }} onClick={() => navigate(`/shops/${shop.id}`)}>
                  <div style={{ height: 160, background: 'var(--bg-input)', overflow: 'hidden', position: 'relative', borderRadius: '20px 20px 0 0' }}>
                    {shop.images?.[0]
                      ? <img src={shop.images[0]} alt={shop.name} loading="lazy" decoding="async" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      : <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 52 }}>💈</div>
                    }
                    {rating && (
                      <div style={{ position: 'absolute', top: 10, right: 10, background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(8px)', borderRadius: 10, padding: '4px 10px', fontSize: 13, fontWeight: 700, color: '#FFB800' }}>⭐ {rating}</div>
                    )}
                    {shop.subscription_tier === 'premium' && !shop.custom_badge && (
                      <div style={{ position: 'absolute', top: 10, left: 10, background: 'linear-gradient(135deg, #FFB800, #FF6B00)', borderRadius: 6, padding: '4px 10px', fontSize: 10, fontWeight: 900, color: '#fff', boxShadow: '0 2px 10px rgba(255,184,0,0.6)', letterSpacing: 1.5, textTransform: 'uppercase', backdropFilter: 'blur(4px)' }}>PREMIUM</div>
                    )}
                    {shop.custom_badge && (
                      <div style={{ position: 'absolute', top: 10, left: 10, background: shop.custom_badge_color ? `linear-gradient(135deg, ${shop.custom_badge_color}dd, ${shop.custom_badge_color}99)` : 'linear-gradient(135deg, #FF3D00, #c62800)', borderRadius: 6, padding: '4px 10px', fontSize: 10, fontWeight: 900, color: '#fff', boxShadow: `0 2px 10px ${shop.custom_badge_color || '#FF3D00'}55`, letterSpacing: 1.5, textTransform: 'uppercase', backdropFilter: 'blur(4px)' }}>{shop.custom_badge}</div>
                    )}
                  </div>
                  <div style={{ padding: '14px 16px' }}>
                    <div style={{ fontFamily: 'Outfit', fontWeight: 700, fontSize: 17, marginBottom: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{shop.name}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>📍 {shop.city} · {shop.address}</div>
                    {shop.distance !== null && (
                      <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: -8, marginBottom: 8, fontWeight: 600 }}>
                        {shop.distance < 1 ? `${Math.round(shop.distance * 1000)}m away` : `${shop.distance.toFixed(1)}km away`}
                      </div>
                    )}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      {minPrice ? <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--brand)' }}>From Rs. {minPrice}</span> : <span />}
                      <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-3)' }}>Book →</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
