import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, cachedQuery, invalidateCache } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

function toAmPm(time) {
  if (!time) return '';
  const [h, m] = time.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 || 12;
  return `${hour}:${String(m).padStart(2, '0')} ${ampm}`;
}

export default function BarberDashboard() {
  const { user, profile, authReady } = useAuth();
  const navigate = useNavigate();
  const [shop, setShop] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [stats, setStats] = useState({ today: 0, pending: 0, total: 0 });
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState({ type: '', text: '' });
  const [qrEnabledTiers, setQrEnabledTiers] = useState({ basic: false, pro: true, premium: true });

  const showToast = (type, text) => {
    setToast({ type, text });
    setTimeout(() => setToast({ type: '', text: '' }), 3000);
  };

  useEffect(() => {
    if (!authReady) return;
    if (!profile || !profile.role) return;
    if (profile.role !== 'barber') { navigate('/'); return; }
    if (user) {
      const t = setTimeout(() => setLoading(false), 8000);
      fetchData().finally(() => clearTimeout(t));
    }
  }, [user, profile, authReady, navigate]); // eslint-disable-line

  const fetchData = async () => {
    setLoading(true);
    try {
      // Show cached shop instantly
      const lsCached = (() => { try { const r = localStorage.getItem('zc:barber-shop:' + user.id); if (r) { const { data, ts } = JSON.parse(r); if (data && Date.now() - ts < 300_000) return data; } } catch {} return null; })();
      if (lsCached) setShop(lsCached);

      // Cache shop row for 5 min
      const shopData = await cachedQuery(`barber-shop:${user.id}`, 300_000, async () => {
        const { data } = await supabase
          .from('shops')
          .select('id, name, address, city, is_active, subscription_status, subscription_expires_at, owner_id, subscription_tier')
          .eq('owner_id', user.id)
          .maybeSingle();
        return data;
      });
      setShop(shopData);

      if (shopData) {
        const today = new Date().toISOString().split('T')[0];
        const [bkRes, notifRes, settingsRes] = await Promise.all([
          supabase
            .from('bookings')
            .select('id, status, created_at, notes, slot_id, profiles(full_name, phone), services(name, price)')
            .eq('shop_id', shopData.id)
            .order('created_at', { ascending: false })
            .limit(20),
          supabase
            .from('notifications')
            .select('*')
            .eq('owner_id', user.id)
            .eq('is_read', false)
            .order('created_at', { ascending: false })
            .limit(10),
          supabase
            .from('app_settings')
            .select('key, value')
            .in('key', ['tier_basic_qr_enabled', 'tier_pro_qr_enabled', 'tier_premium_qr_enabled']),
        ]);

        const bk = bkRes.data || [];
        setBookings(bk);
        setStats({
          today:   bk.filter(b => b.created_at?.startsWith(today)).length,
          pending: bk.filter(b => b.status === 'pending').length,
          total:   bk.length,
        });

        setNotifications(notifRes.data || []);

        if (settingsRes.data && settingsRes.data.length > 0) {
          const qrMap = { basic: false, pro: true, premium: true };
          settingsRes.data.forEach(s => {
            if (s.key === 'tier_basic_qr_enabled')   qrMap.basic   = s.value === 'true';
            if (s.key === 'tier_pro_qr_enabled')      qrMap.pro     = s.value === 'true';
            if (s.key === 'tier_premium_qr_enabled')  qrMap.premium = s.value === 'true';
          });
          setQrEnabledTiers(qrMap);
        }

        checkAndExpireLocally(shopData);
      }
    } catch (err) {
      console.error('BarberDashboard fetchData error:', err);
      showToast('error', 'Failed to load dashboard: ' + (err?.message || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  // Client-side expiry check as fallback
  const checkAndExpireLocally = async (shopData) => {
    if (
      shopData.subscription_status === 'active' &&
      shopData.subscription_expires_at &&
      new Date(shopData.subscription_expires_at) < new Date()
    ) {
      await supabase
        .from('shops')
        .update({ subscription_status: 'expired', is_active: false })
        .eq('id', shopData.id);
      setShop(prev => ({ ...prev, subscription_status: 'expired', is_active: false }));
    }
  };

  const dismissNotification = async (notifId) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', notifId);
    setNotifications(prev => prev.filter(n => n.id !== notifId));
  };

  const dismissAll = async () => {
    const ids = notifications.map(n => n.id);
    await supabase.from('notifications').update({ is_read: true }).in('id', ids);
    setNotifications([]);
  };

  const updateStatus = async (bookingId, status) => {
    const { error } = await supabase.from('bookings').update({ status }).eq('id', bookingId);
    if (error) { showToast('error', 'Failed to update booking: ' + error.message); return; }
    showToast('success', `Booking ${status} ✓`);
    fetchData();
  };

  const deleteBooking = async (bookingId) => {
    if (!window.confirm('Delete this booking? This cannot be undone.')) return;
    const { error } = await supabase.from('bookings').delete().eq('id', bookingId);
    if (error) { showToast('error', 'Failed to delete booking: ' + error.message); return; }
    showToast('success', 'Booking deleted');
    fetchData();
  };

  if (loading) return (
    <div className="loading-screen">
      <div className="loading-logo">✂ Zentro</div>
      <div className="spinner" />
    </div>
  );

  if (!shop) return (
    <div className="page fade-up" style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '80vh' }}>
      <div style={{ fontSize: 56, marginBottom: 20 }}>💈</div>
      <h2 style={{ marginBottom: 10, textAlign: 'center' }}>No shop set up yet</h2>
      <p style={{ color: 'var(--text-2)', marginBottom: 28, textAlign: 'center', fontSize: 14 }}>Set up your shop to start receiving bookings.</p>
      <button className="btn-primary" onClick={() => navigate('/barber/setup')} style={{ maxWidth: 280 }}>Set Up My Shop</button>
    </div>
  );

  const subActive  = shop.subscription_status === 'active';
  const subExpired = shop.subscription_status === 'expired';
  const subColor   = subActive ? '#00C864' : subExpired ? 'var(--brand)' : 'var(--accent)';

  // Days left calculation
  const daysLeft = shop.subscription_expires_at
    ? Math.ceil((new Date(shop.subscription_expires_at) - new Date()) / (1000 * 60 * 60 * 24))
    : null;
  const expiryWarning = subActive && daysLeft !== null && daysLeft <= 7 && daysLeft > 0;

  return (
    <div className="page fade-up" style={{ padding: '0 20px', paddingBottom: 100 }}>
      {/* Toast */}
      {toast.text && <div className={`alert alert-${toast.type}`} style={{ marginBottom: 16 }}>{toast.text}</div>}

      {/* Header */}
      <div className="top-header">
        <div className="logo-text">✂ <span>Dashboard</span></div>
        <button
          onClick={() => navigate('/barber/setup')}
          style={{ background: 'var(--bg-input)', border: 'none', color: 'var(--text-2)', borderRadius: 12, padding: '8px 14px', fontWeight: 600, fontSize: 13, cursor: 'pointer' }}
        >Edit Shop</button>
      </div>

      {/* ── NOTIFICATIONS ── */}
      {notifications.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: 0.5 }}>
              🔔 Notifications ({notifications.length})
            </span>
            <button onClick={dismissAll} style={{ background: 'none', border: 'none', color: 'var(--text-3)', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}>
              Clear all
            </button>
          </div>
          {notifications.map(n => (
            <NotificationCard key={n.id} notif={n} onDismiss={dismissNotification} onPay={() => navigate('/barber/payment')} />
          ))}
        </div>
      )}

      {/* ── SUBSCRIPTION EXPIRY WARNING (inline, even if no DB notif yet) ── */}
      {expiryWarning && notifications.every(n => n.type !== 'expiry_warning') && (
        <div
          style={{
            background: daysLeft <= 2 ? 'rgba(255,61,0,0.1)' : 'rgba(255,184,0,0.1)',
            border: `1.5px solid ${daysLeft <= 2 ? 'var(--brand)' : '#FFB800'}`,
            borderRadius: 14, padding: '12px 16px', marginBottom: 14,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
            cursor: 'pointer',
          }}
          onClick={() => navigate('/barber/payment')}
        >
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: daysLeft <= 2 ? 'var(--brand)' : '#FFB800' }}>
              {daysLeft <= 1 ? '🚨 Subscription expires TOMORROW!' : `⏰ Subscription expires in ${daysLeft} days`}
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>
              Renew now to keep your shop visible to customers
            </div>
          </div>
          <span style={{ fontSize: 12, fontWeight: 700, color: daysLeft <= 2 ? 'var(--brand)' : '#FFB800', whiteSpace: 'nowrap' }}>
            Renew →
          </span>
        </div>
      )}

      {/* ── EXPIRED / NOT ACTIVE WARNING ── */}
      {!subActive && notifications.every(n => n.type !== 'expired') && (
        <div
          className="alert alert-error"
          style={{ cursor: 'pointer', fontSize: 13, lineHeight: 1.5, marginBottom: 14 }}
          onClick={() => navigate('/barber/payment')}
        >
          ⚠️ Subscription <strong>{shop.subscription_status}</strong> — your shop won't appear to customers until you pay. <span style={{ textDecoration: 'underline' }}>Pay Now →</span>
        </div>
      )}

      {/* Shop card */}
      <div className="card" style={{ padding: 16, marginBottom: 12 }}>
        <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: 18, marginBottom: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{shop.name}</div>
        <div style={{ color: 'var(--text-3)', fontSize: 12, marginBottom: 10, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>📍 {shop.address}, {shop.city}</div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
          <span style={{ padding: '3px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: shop.is_active ? 'rgba(0,200,100,0.12)' : 'rgba(255,184,0,0.15)', color: shop.is_active ? '#00C864' : 'var(--accent)' }}>
            {shop.is_active ? '● Live' : '● Awaiting Approval'}
          </span>
        </div>
        {subActive && shop.subscription_expires_at && (
          <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 8 }}>
            Renews: {new Date(shop.subscription_expires_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })}
          </div>
        )}
      </div>

      {/* ── MY SHOP LINK & QR CODE ── */}
      <ShopQRCard shopId={shop.id} shopName={shop.name} tier={shop.subscription_tier || 'basic'} qrEnabledTiers={qrEnabledTiers} />

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 16 }}>
        {[
          { label: "Today's Appts",        value: stats.today   },
          { label: 'Pending Confirmations', value: stats.pending },
          { label: 'Total Bookings',        value: stats.total   },
        ].map((s, i) => (
          <div key={i} className="card" style={{ padding: '14px 8px', textAlign: 'center' }}>
            <div style={{ fontSize: 26, fontWeight: 800, fontFamily: 'Outfit, sans-serif', color: 'var(--brand)', lineHeight: 1 }}>{s.value}</div>
            <div style={{ color: 'var(--text-3)', fontSize: 10, fontWeight: 700, marginTop: 6, lineHeight: 1.3, textTransform: 'uppercase', letterSpacing: '0.4px' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 24 }}>
        <button onClick={() => navigate('/barber/slots')} style={{ padding: '12px 8px', borderRadius: 14, border: 'none', background: 'var(--bg-input)', color: 'var(--text)', fontWeight: 700, fontSize: 12, cursor: 'pointer', lineHeight: 1.4 }}>🕐{'\n'}Slots</button>
        <button onClick={() => navigate('/barber/setup')} style={{ padding: '12px 8px', borderRadius: 14, border: 'none', background: 'var(--bg-input)', color: 'var(--text)', fontWeight: 700, fontSize: 12, cursor: 'pointer', lineHeight: 1.4 }}>⚙️{'\n'}Edit Shop</button>
        <button
          onClick={() => navigate('/barber/payment')}
          style={{ padding: '12px 8px', borderRadius: 14, border: 'none', background: (subExpired || expiryWarning) ? 'var(--brand)' : 'var(--bg-input)', color: (subExpired || expiryWarning) ? '#fff' : 'var(--text)', fontWeight: 700, fontSize: 12, cursor: 'pointer', lineHeight: 1.4 }}
        >💳{'\n'}Pay Sub</button>
      </div>

      {/* Bookings */}
      <p className="section-label" style={{ marginBottom: 12 }}>Recent Bookings</p>
      {bookings.length === 0 && (
        <p style={{ color: 'var(--text-3)', textAlign: 'center', padding: 40, fontSize: 14 }}>No bookings yet.</p>
      )}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {bookings.map(bk => (
          <div key={bk.id} className="card" style={{ padding: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8, gap: 8 }}>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 14, fontFamily: 'Outfit, sans-serif', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{bk.profiles?.full_name || 'Customer'}</div>
                {bk.profiles?.phone && <div style={{ color: 'var(--text-3)', fontSize: 12, marginTop: 1 }}>{bk.profiles.phone}</div>}
              </div>
              <StatusBadge status={bk.status} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontSize: 13, color: 'var(--text-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{bk.services?.name}</div>
                <div style={{ fontSize: 12, color: 'var(--brand)', fontWeight: 700, marginTop: 2 }}>
                  Rs. {bk.services?.price} · {bk.time_slots?.slot_date} {toAmPm(bk.time_slots?.start_time)}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                {bk.status === 'pending' && (
                  <>
                    <button onClick={() => updateStatus(bk.id, 'confirmed')} style={{ padding: '6px 12px', borderRadius: 10, border: 'none', background: 'rgba(0,200,100,0.12)', color: '#00C864', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>✓</button>
                    <button onClick={() => updateStatus(bk.id, 'cancelled')} style={{ padding: '6px 12px', borderRadius: 10, border: 'none', background: 'rgba(255,61,0,0.1)', color: 'var(--brand)', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>✗</button>
                  </>
                )}
                {bk.status === 'confirmed' && (
                  <button onClick={() => updateStatus(bk.id, 'completed')} style={{ padding: '6px 10px', borderRadius: 10, border: 'none', background: 'var(--bg-input)', color: 'var(--text-2)', fontWeight: 700, fontSize: 12, cursor: 'pointer' }}>Done</button>
                )}
                <button onClick={() => deleteBooking(bk.id)} style={{ padding: '6px 10px', borderRadius: 10, border: 'none', background: 'rgba(255,61,0,0.08)', color: 'var(--brand)', fontWeight: 700, fontSize: 12, cursor: 'pointer' }} title="Delete booking">🗑</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Notification Card ──
function NotificationCard({ notif, onDismiss, onPay }) {
  const colors = {
    expiry_warning: { bg: 'rgba(255,184,0,0.1)',   border: '#FFB800', color: '#FFB800' },
    expired:        { bg: 'rgba(255,61,0,0.1)',    border: 'var(--brand)', color: 'var(--brand)' },
    payment_approved: { bg: 'rgba(0,200,100,0.1)', border: '#00C864', color: '#00C864' },
    payment_rejected: { bg: 'rgba(255,61,0,0.1)',  border: 'var(--brand)', color: 'var(--brand)' },
  };
  const c = colors[notif.type] || colors.expiry_warning;
  const needsPay = notif.type === 'expiry_warning' || notif.type === 'expired' || notif.type === 'payment_rejected';

  return (
    <div style={{
      background: c.bg, border: `1.5px solid ${c.border}`,
      borderRadius: 14, padding: '12px 14px', marginBottom: 8,
      display: 'flex', alignItems: 'flex-start', gap: 10,
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 700, fontSize: 13, color: c.color, marginBottom: 3 }}>{notif.title}</div>
        <div style={{ fontSize: 12, color: 'var(--text-2)', lineHeight: 1.5 }}>{notif.message}</div>
        <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 4 }}>
          {new Date(notif.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
        </div>
        {needsPay && (
          <button onClick={onPay} style={{ marginTop: 8, padding: '5px 14px', borderRadius: 10, border: 'none', background: c.border, color: '#fff', fontWeight: 700, fontSize: 12, cursor: 'pointer' }}>
            Pay Now →
          </button>
        )}
      </div>
      <button onClick={() => onDismiss(notif.id)} style={{ background: 'none', border: 'none', color: 'var(--text-3)', fontSize: 18, cursor: 'pointer', lineHeight: 1, padding: '0 2px', flexShrink: 0 }}>×</button>
    </div>
  );
}

function StatusBadge({ status }) {
  const map = {
    confirmed: { bg: 'rgba(0,200,100,0.12)', color: '#00C864' },
    pending:   { bg: 'rgba(255,184,0,0.15)', color: '#FFB800' },
    cancelled: { bg: 'rgba(255,61,0,0.1)',   color: 'var(--brand)' },
    completed: { bg: 'var(--bg-input)',       color: 'var(--text-3)' },
  };
  const c = map[status] || map.pending;
  return (
    <span style={{ padding: '3px 9px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: c.bg, color: c.color, whiteSpace: 'nowrap', flexShrink: 0 }}>
      {status}
    </span>
  );
}

// ── Shop QR Code Card ────────────────────────────────────────────────────────
function ShopQRCard({ shopId, shopName, tier, qrEnabledTiers }) {
  const [showQR, setShowQR] = useState(false);
  const [canvasReady, setCanvasReady] = useState(false);
  const canvasRef = React.useRef(null);
  const shopLink = `${window.location.origin}/shops/${shopId}`;

  // Check if this shop's tier has QR enabled
  const qrAllowed = qrEnabledTiers ? (qrEnabledTiers[tier] !== false) : true;

  // Raw QR image URL (no branding) — we composite the Zentro logo on canvas
  const rawQrSrc = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(shopLink)}&color=FF3D00&bgcolor=1A1A2E&margin=3&ecc=H`;

  // Draw branded QR on canvas once modal opens
  const drawBrandedQR = React.useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setCanvasReady(false);
    const ctx = canvas.getContext('2d');
    const size = 280;
    canvas.width = size;
    canvas.height = size;

    const qrImg = new Image();
    qrImg.crossOrigin = 'anonymous';
    qrImg.onload = () => {
      // Draw QR
      ctx.drawImage(qrImg, 0, 0, size, size);

      // Draw white circle in centre for logo overlay
      const cx = size / 2;
      const cy = size / 2;
      const r = 38;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fillStyle = '#1A1A2E';
      ctx.fill();

      // Zentro brand circle border
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = '#FF3D00';
      ctx.lineWidth = 3;
      ctx.stroke();

      // "Z" letter
      ctx.fillStyle = '#FF3D00';
      ctx.font = 'bold 28px Outfit, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('Z', cx, cy - 4);

      // "zentro" small text below Z
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 8px Outfit, sans-serif';
      ctx.letterSpacing = '1px';
      ctx.fillText('ZENTRO', cx, cy + 17);

      setCanvasReady(true);
    };
    qrImg.onerror = () => setCanvasReady(true); // fallback still shows
    qrImg.src = rawQrSrc;
  }, [rawQrSrc]);

  React.useEffect(() => {
    if (showQR) {
      // slight delay to let the canvas element mount
      setTimeout(drawBrandedQR, 80);
    }
  }, [showQR, drawBrandedQR]);

  const downloadQR = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.href = canvas.toDataURL('image/png');
    link.download = `${shopName.replace(/[^a-z0-9]/gi, '_')}_Zentro_QR.png`;
    link.click();
  };

  return (
    <>
      <div className="card" style={{ padding: '14px 16px', marginBottom: 12 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 13, fontFamily: 'Outfit, sans-serif', marginBottom: 2 }}>📲 Branded QR Code</div>
            <div style={{ fontSize: 11, color: 'var(--text-3)' }}>
              {qrAllowed ? 'Let customers scan to book instantly' : `QR codes require a higher plan (current: ${tier})`}
            </div>
          </div>
          <button
            onClick={() => qrAllowed && setShowQR(true)}
            style={{
              background: qrAllowed ? 'var(--brand)' : 'var(--bg-input)',
              border: 'none', borderRadius: 10, padding: '7px 12px',
              color: qrAllowed ? '#fff' : 'var(--text-3)',
              fontWeight: 700, fontSize: 12,
              cursor: qrAllowed ? 'pointer' : 'not-allowed',
              flexShrink: 0,
            }}
          >{qrAllowed ? 'Show QR' : '🔒 Locked'}</button>
        </div>
      </div>

      {/* QR Modal */}
      {showQR && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.9)',
          zIndex: 9998, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setShowQR(false)}>
          <div
            style={{ background: 'var(--bg-card)', borderRadius: 24, padding: 24, maxWidth: 320, width: '92%', textAlign: 'center' }}
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: 18, marginBottom: 2 }}>📲 Scan to Book</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 18 }}>{shopName}</div>

            {/* Branded canvas QR */}
            <div style={{
              background: '#1A1A2E', borderRadius: 20, padding: 16,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              marginBottom: 20, position: 'relative',
            }}>
              <canvas
                ref={canvasRef}
                style={{ width: 240, height: 240, borderRadius: 10, display: 'block' }}
              />
              {!canvasReady && (
                <div style={{
                  position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: 'var(--text-3)', fontSize: 12,
                }}>Loading…</div>
              )}
            </div>

            {/* Zentro branding line */}
            <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 18, letterSpacing: 1 }}>
              Powered by <span style={{ color: '#FF3D00', fontWeight: 700 }}>ZENTRO</span>
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                onClick={downloadQR}
                disabled={!canvasReady}
                style={{ flex: 1, padding: '11px', borderRadius: 12, border: 'none', background: 'rgba(0,200,100,0.12)', color: '#00C864', fontWeight: 700, fontSize: 13, cursor: canvasReady ? 'pointer' : 'not-allowed', opacity: canvasReady ? 1 : 0.5 }}
              >⬇ Save QR</button>
              <button
                onClick={() => setShowQR(false)}
                style={{ flex: 1, padding: '11px', borderRadius: 12, border: 'none', background: 'var(--brand)', color: '#fff', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}
              >Done</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

