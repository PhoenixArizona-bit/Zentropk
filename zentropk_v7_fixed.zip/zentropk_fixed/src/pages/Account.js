import { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { format, addDays } from 'date-fns';
import { uploadShopImage, deleteImage, uploadPaymentProof } from '../lib/imageUpload';

// ══════════════════════════════════════════════════════════════════════════════
// QR CODE — Zen white + tro blue branding
// ══════════════════════════════════════════════════════════════════════════════
function ZentroQR({ shopId, shopName, size = 260 }) {
  const canvasRef = useRef(null);
  const [qrReady, setQrReady] = useState(false);

  useEffect(() => {
    if (!shopId) return;
    const url = `${window.location.origin}/shop/${shopId}`;
    drawBrandedQR(url);
  }, [shopId]); // eslint-disable-line

  const drawBrandedQR = (text) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const s = size;
    canvas.width = s;
    canvas.height = s;

    const qrColor = '060E1E';
    const qrBg    = 'F0F6FF';
    const apiUrl  = `https://api.qrserver.com/v1/create-qr-code/?size=${s}x${s}&data=${encodeURIComponent(text)}&margin=1&color=${qrColor}&bgcolor=${qrBg}&ecc=H`;

    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      ctx.drawImage(img, 0, 0, s, s);

      const cx = s / 2;
      const cy = s / 2;
      const r  = s * 0.16;

      // White ring border
      ctx.beginPath();
      ctx.arc(cx, cy, r + 5, 0, Math.PI * 2);
      ctx.fillStyle = '#F0F6FF';
      ctx.fill();

      // Dark circle
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fillStyle = '#060E1E';
      ctx.fill();

      // Blue accent ring
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = '#0080FF';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // "Zen" — white, top half of circle
      const lineH = Math.round(r * 0.38);
      const topY  = cy - Math.round(r * 0.1);
      ctx.font = `900 ${lineH}px Sora, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'alphabetic';

      // Measure to position "Zen" + "tro" side-by-side
      const zenW = ctx.measureText('Zen').width;
      const troSize = Math.round(r * 0.36);
      ctx.font = `900 ${troSize}px Sora, sans-serif`;
      const troW = ctx.measureText('tro').width;
      const totalW = zenW + troW;
      const startX = cx - totalW / 2;

      // Draw "Zen" in white
      ctx.font = `900 ${lineH}px Sora, sans-serif`;
      ctx.fillStyle = '#FFFFFF';
      ctx.textAlign = 'left';
      ctx.fillText('Zen', startX, topY);

      // Draw "tro" in brand blue
      ctx.font = `900 ${troSize}px Sora, sans-serif`;
      ctx.fillStyle = '#0080FF';
      ctx.fillText('tro', startX + zenW, topY);

      // "PK" small below
      const pkSize = Math.round(r * 0.25);
      ctx.font = `700 ${pkSize}px Sora, sans-serif`;
      ctx.fillStyle = '#0080FF';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.fillText('PK', cx, topY + 3);

      setQrReady(true);
    };

    img.onerror = () => {
      ctx.fillStyle = '#F0F6FF';
      ctx.fillRect(0, 0, s, s);
      ctx.fillStyle = '#0080FF';
      ctx.font = `700 13px Sora, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('QR unavailable', s / 2, s / 2);
      setQrReady(true);
    };

    img.src = apiUrl;
  };

  const download = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `zentropk-qr-${shopName?.replace(/\s+/g, '-').toLowerCase()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
      <div style={{
        padding: 12, background: '#fff', borderRadius: 16,
        border: '1.5px solid var(--border-brand)', boxShadow: 'var(--shadow-brand)',
        position: 'relative',
      }}>
        <canvas ref={canvasRef} style={{ display: 'block', borderRadius: 8 }} />
        {!qrReady && (
          <div style={{ position: 'absolute', inset: 12, borderRadius: 8, background: 'var(--bg-input)',
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div className="spinner" />
          </div>
        )}
      </div>
      <p style={{ fontSize: 12, color: 'var(--text-2)', textAlign: 'center', lineHeight: 1.5 }}>
        Customers scan to book at <strong style={{ color: 'var(--brand)' }}>{shopName}</strong>
      </p>
      {qrReady && (
        <button className="btn btn-secondary btn-sm" onClick={download} style={{ width: 'auto', paddingLeft: 20, paddingRight: 20 }}>
          ⬇ Download QR
        </button>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// BARBER DASHBOARD TAB
// ══════════════════════════════════════════════════════════════════════════════
function DashboardTab({ user, showToast }) {
  const [shop, setShop]         = useState(null);
  const [bookings, setBookings] = useState([]);
  const [stats, setStats]       = useState({ today: 0, total: 0, earnings: 0 });
  const [loading, setLoading]   = useState(true);

  useEffect(() => { fetchData(); }, []); // eslint-disable-line

  const fetchData = async () => {
    const { data: shopData } = await supabase.from('shops').select('*').eq('owner_id', user.id).maybeSingle();
    setShop(shopData);
    if (!shopData) { setLoading(false); return; }

    const { data: bData } = await supabase
      .from('bookings')
      .select('*, profiles(full_name), services(name, price), time_slots(slot_date, start_time)')
      .eq('shop_id', shopData.id)
      .order('created_at', { ascending: false })
      .limit(50);

    const bs = bData || [];
    setBookings(bs);

    const today = format(new Date(), 'yyyy-MM-dd');
    const todayBs = bs.filter(b => b.time_slots?.slot_date === today && b.status !== 'cancelled');
    const earnings = bs.filter(b => b.status === 'completed').reduce((s, b) => s + (b.services?.price || 0), 0);
    setStats({ today: todayBs.length, total: bs.length, earnings });
    setLoading(false);
  };

  const updateStatus = async (bookingId, status, slotId) => {
    await supabase.from('bookings').update({ status }).eq('id', bookingId);
    if (status === 'cancelled') await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
    showToast('success', `Booking ${status}`);
    fetchData();
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  if (!shop) return (
    <div className="empty-state" style={{ padding: '40px 0' }}>
      <div className="empty-icon">✂️</div>
      <div className="empty-title">No shop yet</div>
      <div className="empty-sub">Set up your shop in the Setup tab</div>
    </div>
  );

  const today = format(new Date(), 'yyyy-MM-dd');
  const todayBs    = bookings.filter(b => b.time_slots?.slot_date === today);
  const upcomingBs = bookings.filter(b => b.time_slots?.slot_date > today && b.status !== 'cancelled');

  return (
    <div>
      {/* Status */}
      {!shop.is_active && (
        <div style={{ background: 'rgba(255,149,0,0.1)', border: '1px solid rgba(255,149,0,0.25)',
          borderRadius: 'var(--radius-sm)', padding: '10px 14px', marginBottom: 16,
          display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--warning)' }}>
          ⏳ <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>Pending admin approval</span>
        </div>
      )}

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 20 }}>
        {[
          { label: "Today", value: stats.today, icon: '📅' },
          { label: 'Total',  value: stats.total, icon: '📊' },
          { label: 'Earned', value: `Rs ${stats.earnings}`, icon: '💰' },
        ].map(s => (
          <div key={s.label} className="card" style={{ textAlign: 'center', padding: '14px 8px' }}>
            <div style={{ fontSize: 20, marginBottom: 4 }}>{s.icon}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, color: 'var(--brand)' }}>{s.value}</div>
            <div style={{ fontSize: 10, color: 'var(--text-2)', fontWeight: 600, textTransform: 'uppercase' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Today's bookings */}
      <p className="section-label" style={{ fontSize: 15 }}>Today's Bookings</p>
      {todayBs.length === 0 ? (
        <p style={{ color: 'var(--text-3)', fontSize: 13, marginBottom: 20, fontFamily: 'var(--font-display)' }}>No bookings today</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
          {todayBs.map(b => <BookingRowDB key={b.id} booking={b} onUpdate={updateStatus} />)}
        </div>
      )}

      {upcomingBs.length > 0 && (
        <>
          <p className="section-label" style={{ fontSize: 15 }}>Upcoming</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {upcomingBs.slice(0, 5).map(b => <BookingRowDB key={b.id} booking={b} onUpdate={updateStatus} />)}
          </div>
        </>
      )}

      {/* QR Code */}
      <div style={{ marginTop: 24, borderTop: '1px solid var(--border)', paddingTop: 20 }}>
        <p className="section-label" style={{ fontSize: 15, marginBottom: 16 }}>My Shop QR Code</p>
        <ZentroQR shopId={shop.id} shopName={shop.name} size={220} />
      </div>
    </div>
  );
}

function BookingRowDB({ booking: b, onUpdate }) {
  const sc = { pending: 'var(--warning)', confirmed: 'var(--success)', cancelled: 'var(--text-3)', completed: 'var(--brand)' };
  return (
    <div className="card" style={{ padding: '14px 16px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>{b.profiles?.full_name || 'Customer'}</div>
        <span style={{ fontSize: 11, fontWeight: 700, color: sc[b.status], fontFamily: 'var(--font-display)' }}>{b.status?.toUpperCase()}</span>
      </div>
      <p style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: 3 }}>✂️ {b.services?.name} — Rs {b.services?.price}</p>
      <p style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: b.status === 'pending' || b.status === 'confirmed' ? 10 : 0 }}>
        🕐 {b.time_slots?.start_time?.slice(0, 5)}
      </p>
      {b.status === 'pending' && (
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => onUpdate(b.id, 'confirmed', b.time_slot_id)}>Confirm</button>
          <button className="btn btn-danger btn-sm" style={{ flex: 1 }} onClick={() => onUpdate(b.id, 'cancelled', b.time_slot_id)}>Cancel</button>
        </div>
      )}
      {b.status === 'confirmed' && (
        <button className="btn btn-primary btn-sm" onClick={() => onUpdate(b.id, 'completed', b.time_slot_id)}>✓ Mark Complete</button>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SHOP SETUP TAB (inline)
// ══════════════════════════════════════════════════════════════════════════════
function SetupTab({ user, showToast }) {
  const [shopId, setShopId]         = useState(null);
  const [loading, setLoading]       = useState(true);
  const [saving, setSaving]         = useState(false);
  const [uploadingImg, setUpImg]    = useState(false);
  const [services, setServices]     = useState([]);
  const [newSrv, setNewSrv]         = useState({ name: '', price: '', duration_minutes: 30 });
  const [form, setForm] = useState({ name: '', city: '', address: '', description: '', phone: '', images: [] });

  useEffect(() => { loadExisting(); }, []); // eslint-disable-line

  const loadExisting = async () => {
    const { data: s } = await supabase.from('shops').select('*').eq('owner_id', user.id).maybeSingle();
    if (s) {
      setShopId(s.id);
      setForm({ name: s.name||'', city: s.city||'', address: s.address||'', description: s.description||'', phone: s.phone||'', images: s.images||[] });
      const { data: srv } = await supabase.from('services').select('*').eq('shop_id', s.id);
      setServices(srv || []);
    }
    setLoading(false);
  };

  const uploadImage = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!shopId) return showToast('error', 'Save shop details first');
    if (form.images.length >= 10) return showToast('error', 'Max 10 images');
    setUpImg(true);
    try {
      const url = await uploadShopImage(file, shopId);
      const newImages = [...form.images, url];
      setForm(p => ({ ...p, images: newImages }));
      await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
      showToast('success', 'Image uploaded');
    } catch (err) { showToast('error', 'Upload failed: ' + err.message); }
    setUpImg(false);
  };

  const removeImage = async (url) => {
    const newImages = form.images.filter(i => i !== url);
    setForm(p => ({ ...p, images: newImages }));
    await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
    await deleteImage(url);
    showToast('success', 'Image removed');
  };

  const save = async () => {
    if (!form.name || !form.city || !form.address) return showToast('error', 'Name, city and address required');
    setSaving(true);
    const payload = { ...form, owner_id: user.id, is_active: false, subscription_status: 'pending', subscription_tier: 'basic' };
    if (shopId) {
      const { error } = await supabase.from('shops').update(payload).eq('id', shopId);
      if (error) { setSaving(false); return showToast('error', error.message); }
      showToast('success', 'Shop updated!');
    } else {
      const { data, error } = await supabase.from('shops').insert(payload).select().maybeSingle();
      if (error) { setSaving(false); return showToast('error', error.message); }
      if (data) setShopId(data.id);
      showToast('success', 'Shop created! Awaiting admin approval.');
    }
    setSaving(false);
  };

  const addService = async () => {
    if (!shopId) return showToast('error', 'Save shop details first');
    if (!newSrv.name || !newSrv.price) return showToast('error', 'Name and price required');
    const { data, error } = await supabase.from('services')
      .insert({ ...newSrv, shop_id: shopId, price: parseFloat(newSrv.price), is_active: true })
      .select().maybeSingle();
    if (error) return showToast('error', error.message);
    if (data) setServices(prev => [...prev, data]);
    setNewSrv({ name: '', price: '', duration_minutes: 30 });
    showToast('success', 'Service added');
  };

  const removeService = async (id) => {
    await supabase.from('services').delete().eq('id', id);
    setServices(prev => prev.filter(s => s.id !== id));
    showToast('success', 'Service removed');
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  return (
    <div>
      {/* Basic Info */}
      <div className="card" style={{ marginBottom: 16 }}>
        <p className="section-label" style={{ fontSize: 15, marginBottom: 14 }}>Basic Info</p>
        {[
          { label: 'Shop Name *', key: 'name', placeholder: 'e.g. Cuts & Glory' },
          { label: 'City *',      key: 'city', placeholder: 'e.g. Lahore' },
          { label: 'Address *',   key: 'address', placeholder: 'Full address' },
          { label: 'Phone',       key: 'phone', placeholder: '+92 300 0000000' },
        ].map(f => (
          <div key={f.key} className="input-group">
            <label className="input-label">{f.label}</label>
            <input className="input" placeholder={f.placeholder} value={form[f.key]}
              onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} />
          </div>
        ))}
        <div className="input-group">
          <label className="input-label">Description</label>
          <textarea className="input" placeholder="Tell customers about your shop..."
            value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
        </div>
        {shopId && (
          <div className="input-group">
            <label className="input-label">Shop Photos ({form.images.length}/10)</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 8 }}>
              {form.images.map(url => (
                <div key={url} style={{ position: 'relative', width: 76, height: 76 }}>
                  <img src={url} alt="" style={{ width: 76, height: 76, objectFit: 'cover', borderRadius: 10 }} />
                  <button onClick={() => removeImage(url)} style={{
                    position: 'absolute', top: -5, right: -5, width: 20, height: 20, borderRadius: '50%',
                    background: 'var(--error)', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 12, lineHeight: 1
                  }}>✕</button>
                </div>
              ))}
              {form.images.length < 10 && (
                <label style={{ width: 76, height: 76, borderRadius: 10, border: '2px dashed var(--border)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                  color: 'var(--text-3)', fontSize: 22, background: 'var(--bg-input)' }}>
                  {uploadingImg ? <span className="spinner spinner-sm" /> : '+'}
                  <input type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadImage} disabled={uploadingImg} />
                </label>
              )}
            </div>
          </div>
        )}
        <button className="btn btn-primary" onClick={save} disabled={saving}>
          {saving ? <span className="spinner spinner-sm" /> : shopId ? 'Update Shop' : 'Create Shop'}
        </button>
      </div>

      {/* Services */}
      <div className="card">
        <p className="section-label" style={{ fontSize: 15, marginBottom: 14 }}>Services</p>
        {services.map(s => (
          <div key={s.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
            <div>
              <div style={{ fontWeight: 600, fontFamily: 'var(--font-display)', fontSize: 13 }}>{s.name}</div>
              <div style={{ fontSize: 12, color: 'var(--text-2)' }}>Rs {s.price} · {s.duration_minutes} min</div>
            </div>
            <button className="btn btn-danger btn-sm" onClick={() => removeService(s.id)}>Remove</button>
          </div>
        ))}
        <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ display: 'flex', gap: 10 }}>
            <input className="input" placeholder="Service name" style={{ flex: 2 }}
              value={newSrv.name} onChange={e => setNewSrv(p => ({ ...p, name: e.target.value }))} />
            <input className="input" placeholder="Price" type="number" style={{ flex: 1 }}
              value={newSrv.price} onChange={e => setNewSrv(p => ({ ...p, price: e.target.value }))} />
          </div>
          <select className="input" value={newSrv.duration_minutes}
            onChange={e => setNewSrv(p => ({ ...p, duration_minutes: parseInt(e.target.value) }))}>
            {[15, 20, 30, 45, 60, 90].map(d => <option key={d} value={d}>{d} minutes</option>)}
          </select>
          <button className="btn btn-secondary" onClick={addService}>+ Add Service</button>
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SLOTS TAB (inline)
// ══════════════════════════════════════════════════════════════════════════════
function SlotsTab({ user, showToast }) {
  const [shopId, setShopId]           = useState(null);
  const [loading, setLoading]         = useState(true);
  const [slots, setSlots]             = useState([]);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [generating, setGenerating]   = useState(false);
  const [genForm, setGenForm] = useState({ start: '09:00', end: '18:00', interval: 30, daysAhead: 7 });

  useEffect(() => { loadShop(); }, []); // eslint-disable-line
  useEffect(() => { if (shopId) loadSlots(); }, [shopId, selectedDate]); // eslint-disable-line

  const loadShop = async () => {
    const { data } = await supabase.from('shops').select('id').eq('owner_id', user.id).maybeSingle();
    if (data) setShopId(data.id);
    else showToast('error', 'Set up your shop first');
    setLoading(false);
  };

  const loadSlots = useCallback(async () => {
    const { data } = await supabase.from('time_slots').select('*').eq('shop_id', shopId).eq('slot_date', selectedDate).order('start_time');
    setSlots(data || []);
  }, [shopId, selectedDate]);

  const generateSlots = async () => {
    if (!shopId) return;
    setGenerating(true);
    const dates = Array.from({ length: genForm.daysAhead }, (_, i) => format(addDays(new Date(), i), 'yyyy-MM-dd'));
    const toInsert = [];
    for (const date of dates) {
      const [sh, sm] = genForm.start.split(':').map(Number);
      const [eh, em] = genForm.end.split(':').map(Number);
      let cur = sh * 60 + sm;
      const end = eh * 60 + em;
      while (cur + genForm.interval <= end) {
        const hh = String(Math.floor(cur / 60)).padStart(2, '0');
        const mm = String(cur % 60).padStart(2, '0');
        const nh = String(Math.floor((cur + genForm.interval) / 60)).padStart(2, '0');
        const nm = String((cur + genForm.interval) % 60).padStart(2, '0');
        toInsert.push({ shop_id: shopId, slot_date: date, start_time: `${hh}:${mm}:00`, end_time: `${nh}:${nm}:00`, is_booked: false });
        cur += genForm.interval;
      }
    }
    const { error } = await supabase.from('time_slots').upsert(toInsert, { onConflict: 'shop_id,slot_date,start_time', ignoreDuplicates: true });
    setGenerating(false);
    if (error) return showToast('error', error.message);
    showToast('success', `Generated slots for ${genForm.daysAhead} days`);
    loadSlots();
  };

  const deleteSlot = async (id) => {
    await supabase.from('time_slots').delete().eq('id', id);
    setSlots(prev => prev.filter(s => s.id !== id));
  };

  const deleteAllForDate = async () => {
    await supabase.from('time_slots').delete().eq('shop_id', shopId).eq('slot_date', selectedDate).eq('is_booked', false);
    showToast('success', 'Cleared all free slots');
    loadSlots();
  };

  const dates = Array.from({ length: 14 }, (_, i) => {
    const d = addDays(new Date(), i);
    return { value: format(d, 'yyyy-MM-dd'), label: format(d, 'EEE'), day: format(d, 'd') };
  });

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  return (
    <div>
      <div className="card" style={{ marginBottom: 16 }}>
        <p className="section-label" style={{ fontSize: 15, marginBottom: 14 }}>Generate Slots</p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">Start</label>
            <input className="input" type="time" value={genForm.start} onChange={e => setGenForm(p => ({ ...p, start: e.target.value }))} />
          </div>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">End</label>
            <input className="input" type="time" value={genForm.end} onChange={e => setGenForm(p => ({ ...p, end: e.target.value }))} />
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">Interval</label>
            <select className="input" value={genForm.interval} onChange={e => setGenForm(p => ({ ...p, interval: parseInt(e.target.value) }))}>
              {[15, 20, 30, 45, 60].map(v => <option key={v} value={v}>{v} min</option>)}
            </select>
          </div>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">Days Ahead</label>
            <select className="input" value={genForm.daysAhead} onChange={e => setGenForm(p => ({ ...p, daysAhead: parseInt(e.target.value) }))}>
              {[1, 3, 7, 14, 30].map(v => <option key={v} value={v}>{v} days</option>)}
            </select>
          </div>
        </div>
        <button className="btn btn-primary" onClick={generateSlots} disabled={generating || !shopId}>
          {generating ? <span className="spinner spinner-sm" /> : '⚡ Generate Slots'}
        </button>
      </div>

      <p className="section-label" style={{ fontSize: 15 }}>Manage Slots</p>
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 12, marginBottom: 14 }}>
        {dates.map(d => (
          <button key={d.value} onClick={() => setSelectedDate(d.value)} style={{
            flexShrink: 0, width: 48, padding: '7px 0', borderRadius: 'var(--radius-sm)',
            border: `1.5px solid ${selectedDate === d.value ? 'var(--brand)' : 'var(--border)'}`,
            background: selectedDate === d.value ? 'var(--brand-glow)' : 'var(--bg-input)',
            color: selectedDate === d.value ? 'var(--brand)' : 'var(--text-2)',
            fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
          }}>
            <span style={{ fontSize: 9, textTransform: 'uppercase' }}>{d.label}</span>
            <span style={{ fontSize: 16 }}>{d.day}</span>
          </button>
        ))}
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <span style={{ fontSize: 13, color: 'var(--text-2)' }}>{slots.length} slots on {selectedDate}</span>
        {slots.some(s => !s.is_booked) && (
          <button className="btn btn-danger btn-sm" onClick={deleteAllForDate}>Clear Free</button>
        )}
      </div>

      {slots.length === 0 ? (
        <p style={{ color: 'var(--text-3)', fontSize: 13, fontFamily: 'var(--font-display)', textAlign: 'center', padding: '20px 0' }}>
          No slots for this date. Generate above.
        </p>
      ) : (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {slots.map(s => (
            <div key={s.id} style={{
              padding: '7px 12px', borderRadius: 'var(--radius-sm)',
              border: `1.5px solid ${s.is_booked ? 'var(--error)' : 'var(--success)'}`,
              background: s.is_booked ? 'rgba(255,59,48,0.08)' : 'rgba(0,200,100,0.08)',
              display: 'flex', alignItems: 'center', gap: 7,
            }}>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12,
                color: s.is_booked ? 'var(--error)' : 'var(--success)' }}>
                {s.start_time.slice(0, 5)}
              </span>
              {!s.is_booked && (
                <button onClick={() => deleteSlot(s.id)}
                  style={{ background: 'none', border: 'none', color: 'var(--text-3)', cursor: 'pointer', fontSize: 13, lineHeight: 1 }}>✕</button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// PAYMENT TAB (inline)
// ══════════════════════════════════════════════════════════════════════════════
function PaymentTab({ user, showToast }) {
  const [shop, setShop]             = useState(null);
  const [payments, setPayments]     = useState([]);
  const [settings, setSettings]     = useState({});
  const [loading, setLoading]       = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingProof, setUpProof] = useState(false);
  const [form, setForm] = useState({ amount: '', txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });

  useEffect(() => { loadData(); }, []); // eslint-disable-line

  const loadData = async () => {
    const [{ data: s }, { data: pays }, { data: cfg }] = await Promise.all([
      supabase.from('shops').select('id, name, subscription_tier, subscription_status').eq('owner_id', user.id).maybeSingle(),
      supabase.from('payment_submissions').select('*').eq('owner_id', user.id).order('submitted_at', { ascending: false }),
      supabase.from('app_settings').select('key, value').in('key', ['jazzcash_number', 'easypaisa_number', 'jazzcash_name', 'easypaisa_name']),
    ]);
    setShop(s);
    setPayments(pays || []);
    const map = {};
    (cfg || []).forEach(r => { map[r.key] = r.value; });
    setSettings(map);
    setLoading(false);
  };

  const uploadProof = async (e) => {
    const file = e.target.files[0];
    if (!file || !user) return;
    setUpProof(true);
    try {
      const url = await uploadPaymentProof(file, user.id);
      setForm(p => ({ ...p, screenshot_url: url }));
      showToast('success', 'Screenshot uploaded');
    } catch (err) { showToast('error', 'Upload failed: ' + err.message); }
    setUpProof(false);
  };

  const submit = async () => {
    if (!shop) return showToast('error', 'No shop found');
    if (!form.amount || !form.txn_id) return showToast('error', 'Amount and transaction ID required');
    setSubmitting(true);
    const { error } = await supabase.from('payment_submissions').insert({
      shop_id: shop.id, owner_id: user.id, amount: parseFloat(form.amount),
      txn_id: form.txn_id, screenshot_url: form.screenshot_url,
      payment_method: form.payment_method, status: 'pending', submitted_at: new Date().toISOString(),
    });
    setSubmitting(false);
    if (error) return showToast('error', error.message);
    showToast('success', 'Payment submitted! Admin will review soon.');
    setForm({ amount: '', txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });
    loadData();
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  const accountNumber = form.payment_method === 'jazzcash' ? settings.jazzcash_number : settings.easypaisa_number;
  const accountName   = form.payment_method === 'jazzcash' ? settings.jazzcash_name   : settings.easypaisa_name;

  return (
    <div>
      {shop && (
        <div className="card" style={{ marginBottom: 14 }}>
          <p style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: 3 }}>Current Plan</p>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, textTransform: 'capitalize' }}>
              {shop.subscription_tier || 'Basic'}
            </span>
            <span className={`badge ${shop.subscription_status === 'active' ? 'badge-success' : 'badge-warning'}`}>
              {shop.subscription_status || 'Pending'}
            </span>
          </div>
        </div>
      )}

      {(accountNumber || accountName) && (
        <div className="card" style={{ marginBottom: 14 }}>
          <p className="section-label" style={{ fontSize: 15, marginBottom: 10 }}>Send Payment To</p>
          <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
            {['jazzcash', 'easypaisa'].map(m => (
              <button key={m} onClick={() => setForm(p => ({ ...p, payment_method: m }))}
                className={`btn ${form.payment_method === m ? 'btn-primary' : 'btn-secondary'} btn-sm`}
                style={{ flex: 1, textTransform: 'capitalize' }}>{m}</button>
            ))}
          </div>
          {accountNumber && (
            <div style={{ background: 'var(--bg-input)', borderRadius: 'var(--radius-sm)', padding: '12px 14px' }}>
              {accountName && <p style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: 3 }}>Account Name: <strong style={{ color: 'var(--text-1)' }}>{accountName}</strong></p>}
              <p style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: 'var(--brand)' }}>{accountNumber}</p>
            </div>
          )}
        </div>
      )}

      <div className="card" style={{ marginBottom: 14 }}>
        <p className="section-label" style={{ fontSize: 15, marginBottom: 14 }}>Submit Payment Proof</p>
        <div className="input-group">
          <label className="input-label">Amount Paid (Rs)</label>
          <input className="input" type="number" placeholder="e.g. 1000" value={form.amount}
            onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} />
        </div>
        <div className="input-group">
          <label className="input-label">Transaction ID</label>
          <input className="input" placeholder="TXN ID from receipt" value={form.txn_id}
            onChange={e => setForm(p => ({ ...p, txn_id: e.target.value }))} />
        </div>
        <div className="input-group">
          <label className="input-label">Payment Screenshot</label>
          {form.screenshot_url ? (
            <div style={{ position: 'relative', marginBottom: 8 }}>
              <img src={form.screenshot_url} alt="proof" style={{ width: '100%', borderRadius: 12, maxHeight: 180, objectFit: 'cover' }} />
              <button onClick={() => setForm(p => ({ ...p, screenshot_url: '' }))}
                style={{ position: 'absolute', top: 8, right: 8, background: 'var(--error)', color: '#fff',
                  border: 'none', borderRadius: 8, padding: '4px 10px', cursor: 'pointer', fontSize: 11 }}>Remove</button>
            </div>
          ) : (
            <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              padding: '14px', border: '2px dashed var(--border)', borderRadius: 'var(--radius-sm)',
              background: 'var(--bg-input)', cursor: 'pointer', color: 'var(--text-2)', fontSize: 13 }}>
              {uploadingProof ? <span className="spinner spinner-sm" /> : '📎 Upload Screenshot'}
              <input type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadProof} disabled={uploadingProof} />
            </label>
          )}
        </div>
        <button className="btn btn-primary" onClick={submit} disabled={submitting}>
          {submitting ? <span className="spinner spinner-sm" /> : 'Submit Payment'}
        </button>
      </div>

      {payments.length > 0 && (
        <div>
          <p className="section-label" style={{ fontSize: 15 }}>Payment History</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {payments.map(p => (
              <div key={p.id} className="card card-sm">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>Rs {p.amount}</span>
                  <span className={`badge ${p.status === 'approved' ? 'badge-success' : p.status === 'rejected' ? 'badge-error' : 'badge-warning'}`}>{p.status}</span>
                </div>
                <p style={{ fontSize: 11, color: 'var(--text-2)' }}>TXN: {p.txn_id} · {p.payment_method}</p>
                <p style={{ fontSize: 11, color: 'var(--text-3)' }}>{new Date(p.submitted_at).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// BOOKING CARD (customer)
// ══════════════════════════════════════════════════════════════════════════════
function BookingCard({ booking: b, onCancel }) {
  const sc = { pending: 'var(--warning)', confirmed: 'var(--success)', cancelled: 'var(--text-3)', completed: 'var(--brand)' };
  return (
    <div className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>{b.shops?.name}</div>
        <span style={{ fontSize: 10, fontWeight: 700, color: sc[b.status], textTransform: 'uppercase',
          fontFamily: 'var(--font-display)', background: `${sc[b.status]}18`, padding: '3px 9px',
          borderRadius: 20, border: `1px solid ${sc[b.status]}30` }}>{b.status}</span>
      </div>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 4 }}>
        ✂️ {b.services?.name} — <span style={{ color: 'var(--brand)', fontWeight: 700 }}>Rs {b.services?.price}</span>
      </p>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: b.status === 'pending' ? 14 : 0 }}>
        📅 {b.time_slots?.slot_date} at {b.time_slots?.start_time?.slice(0, 5)}
      </p>
      {b.status === 'pending' && (
        <button className="btn btn-danger btn-sm" onClick={onCancel}>Cancel Booking</button>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// MAIN ACCOUNT PAGE
// ══════════════════════════════════════════════════════════════════════════════
export default function Account() {
  const { user, profile, signOut, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [bookings, setBookings] = useState([]);
  const [bTab, setBTab]         = useState('upcoming');
  const [bLoading, setBLoading] = useState(true);
  const [barberTab, setBarberTab] = useState('dashboard'); // dashboard | setup | slots | payment

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    if (profile?.role !== 'barber') fetchBookings();
  }, [user, authReady, profile]); // eslint-disable-line

  const fetchBookings = async () => {
    const { data } = await supabase
      .from('bookings')
      .select('*, shops(name, address), services(name, price), time_slots(slot_date, start_time)')
      .eq('customer_id', user.id)
      .order('created_at', { ascending: false });
    setBookings(data || []);
    setBLoading(false);
  };

  const cancel = async (id, slotId) => {
    const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', id);
    if (!error) {
      await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
      showToast('success', 'Booking cancelled');
      fetchBookings();
    } else {
      showToast('error', 'Failed to cancel');
    }
  };

  const handleSignOut = async () => { await signOut(); navigate('/'); };

  if (!authReady) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) return null;

  const today    = format(new Date(), 'yyyy-MM-dd');
  const upcoming = bookings.filter(b => b.time_slots?.slot_date >= today && b.status !== 'cancelled');
  const past     = bookings.filter(b => b.time_slots?.slot_date < today  || b.status === 'cancelled');
  const list     = bTab === 'upcoming' ? upcoming : past;

  const isBarber = profile?.role === 'barber';

  const barberTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'setup',     label: 'Setup',     icon: '✂️' },
    { id: 'slots',     label: 'Slots',     icon: '🕐' },
    { id: 'payment',   label: 'Payment',   icon: '💳' },
  ];

  return (
    <div className="page">
      {ToastEl}
      <div className="topnav">
        <div className="topnav-logo">Zen<span style={{ color: 'var(--brand)' }}>tro</span><span style={{ color: 'var(--brand)', fontSize: 16 }}>PK</span></div>
        <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Account</span>
      </div>

      <div style={{ padding: '20px 20px 0' }}>

        {/* ── Profile Hero ── */}
        <div className="fade-up" style={{ marginBottom: 18 }}>
          <div style={{
            background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
            borderRadius: 20, padding: '18px 20px', color: '#fff',
            display: 'flex', alignItems: 'center', gap: 14,
            boxShadow: 'var(--shadow-brand)',
          }}>
            <div style={{
              width: 52, height: 52, borderRadius: '50%',
              background: 'rgba(255,255,255,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22,
              flexShrink: 0, border: '2px solid rgba(255,255,255,0.4)',
            }}>
              {profile?.full_name?.[0]?.toUpperCase() || '?'}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 17, marginBottom: 2 }}>
                {profile?.full_name}
              </div>
              <div style={{ fontSize: 12, opacity: 0.85, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 5 }}>
                {user.email}
              </div>
              <span style={{ background: 'rgba(255,255,255,0.2)', borderRadius: 100, padding: '2px 10px', fontSize: 10, fontWeight: 700, fontFamily: 'var(--font-display)', textTransform: 'capitalize' }}>
                {profile?.role}
              </span>
            </div>
            <button onClick={handleSignOut}
              style={{ background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.3)',
                borderRadius: 10, padding: '8px 12px', color: '#fff', cursor: 'pointer',
                fontSize: 11, fontFamily: 'var(--font-display)', fontWeight: 700, flexShrink: 0 }}>
              Sign Out
            </button>
          </div>
        </div>

        {/* ── BARBER: Full tab bar ── */}
        {isBarber && (
          <>
            {/* Tab bar */}
            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)',
              gap: 6, marginBottom: 20,
              background: 'var(--bg-input)', borderRadius: 'var(--radius)',
              padding: 4,
            }}>
              {barberTabs.map(t => (
                <button key={t.id} onClick={() => setBarberTab(t.id)} style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
                  padding: '10px 0', borderRadius: 12,
                  border: 'none', cursor: 'pointer', transition: 'all 0.18s',
                  background: barberTab === t.id ? 'var(--bg-card)' : 'transparent',
                  boxShadow: barberTab === t.id ? 'var(--shadow-card)' : 'none',
                  color: barberTab === t.id ? 'var(--brand)' : 'var(--text-2)',
                }}>
                  <span style={{ fontSize: 18 }}>{t.icon}</span>
                  <span style={{ fontSize: 10, fontFamily: 'var(--font-display)', fontWeight: 700 }}>{t.label}</span>
                </button>
              ))}
            </div>

            {/* Tab content */}
            <div className="fade-in">
              {barberTab === 'dashboard' && <DashboardTab user={user} showToast={showToast} />}
              {barberTab === 'setup'     && <SetupTab     user={user} showToast={showToast} />}
              {barberTab === 'slots'     && <SlotsTab     user={user} showToast={showToast} />}
              {barberTab === 'payment'   && <PaymentTab   user={user} showToast={showToast} />}
            </div>
          </>
        )}

        {/* ── CUSTOMER: Bookings ── */}
        {!isBarber && (
          <>
            <p className="section-label" style={{ marginBottom: 4 }}>My Bookings</p>
            <div className="accent-line" />
            <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
              {['upcoming', 'past'].map(t => (
                <button key={t} onClick={() => setBTab(t)}
                  className={`chip${bTab === t ? ' active' : ''}`}
                  style={{ textTransform: 'capitalize' }}>
                  {t} ({t === 'upcoming' ? upcoming.length : past.length})
                </button>
              ))}
            </div>
            {bLoading ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {[1, 2].map(i => <div key={i} className="skeleton" style={{ height: 130, borderRadius: 'var(--radius)' }} />)}
              </div>
            ) : list.length === 0 ? (
              <div className="empty-state" style={{ padding: '40px 0' }}>
                <div className="empty-icon">📅</div>
                <div className="empty-title">No bookings yet</div>
                <div className="empty-sub">Browse shops and book your next cut</div>
                <button className="btn btn-primary btn-sm" onClick={() => navigate('/')} style={{ marginTop: 16 }}>Explore Shops</button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {list.map((b, i) => (
                  <div key={b.id} className="fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
                    <BookingCard booking={b} onCancel={() => cancel(b.id, b.time_slot_id)} />
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
