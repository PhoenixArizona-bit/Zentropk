import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';

// Fix leaflet default icon paths broken by webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Custom brand pin for barber shops
function makeBrandPin(active = false) {
  return L.divIcon({
    className: '',
    iconSize:  [36, 44],
    iconAnchor:[18, 44],
    popupAnchor:[0, -44],
    html: `<svg width="36" height="44" viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg">
      <filter id="s" x="-50%" y="-50%" width="200%" height="200%">
        <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="${active ? '#0080FF' : '#0050C8'}" flood-opacity="0.45"/>
      </filter>
      <path d="M18 2C9.16 2 2 9.16 2 18c0 12 16 24 16 24S34 30 34 18C34 9.16 26.84 2 18 2z"
        fill="${active ? '#00B4FF' : '#0080FF'}" filter="url(#s)"/>
      <circle cx="18" cy="18" r="8" fill="white" opacity="0.95"/>
      <text x="18" y="22" text-anchor="middle" font-family="Sora,sans-serif" font-weight="900" font-size="11" fill="${active ? '#00B4FF' : '#0080FF'}">✂</text>
    </svg>`,
  });
}

// Map recenter helper
function MapRecenter({ center }) {
  const map = useMap();
  useEffect(() => { if (center) map.flyTo(center, 14, { duration: 1.2 }); }, [center, map]);
  return null;
}

export default function Explore() {
  const navigate    = useNavigate();
  const [shops, setShops]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState('');
  const [view, setView]         = useState('list'); // 'list' | 'map'
  const [activeShop, setActive] = useState(null);
  const [mapCenter, setCenter]  = useState([30.3753, 69.3451]); // Pakistan center
  const listRef = useRef(null);

  useEffect(() => {
    supabase
      .from('shops')
      .select('id, name, city, address, images, subscription_tier, rating, lat, lng')
      .eq('is_active', true)
      .then(({ data }) => { setShops(data || []); setLoading(false); });
  }, []);

  const tierWeight = t => t === 'premium' ? 0 : t === 'pro' ? 1 : 2;

  const filtered = shops
    .filter(s =>
      !search ||
      s.name?.toLowerCase().includes(search.toLowerCase()) ||
      s.city?.toLowerCase().includes(search.toLowerCase()) ||
      s.address?.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => tierWeight(a.subscription_tier) - tierWeight(b.subscription_tier));

  const mapShops = filtered.filter(s => s.lat && s.lng);

  const focusShop = (shop) => {
    setActive(shop.id);
    if (shop.lat && shop.lng) setCenter([shop.lat, shop.lng]);
    if (view === 'list') {
      // switch to map
      setView('map');
    }
  };

  const selectFromMap = (shop) => {
    setActive(shop.id);
    // scroll list item into view when in split mode
    const el = listRef.current?.querySelector(`[data-shopid="${shop.id}"]`);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  };

  return (
    <div className="page" style={{ paddingBottom: 0 }}>
      {/* ── Top bar ── */}
      <div className="topnav">
        <div className="topnav-logo">Zen<span style={{ color: 'var(--brand)' }}>tro</span><span style={{ color: 'var(--brand)', fontSize: 16 }}>PK</span></div>
        <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Explore</span>
      </div>

      {/* ── Search + toggle ── */}
      <div style={{ padding: '14px 16px 0', background: 'var(--bg-nav)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 60, zIndex: 90 }}>
        <div style={{ position: 'relative', marginBottom: 12 }}>
          <svg style={{ position: 'absolute', left: 13, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}
            width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            className="input"
            placeholder="Search by name or city..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ paddingLeft: 40, marginBottom: 0, paddingRight: search ? 38 : 14 }}
          />
          {search && (
            <button onClick={() => setSearch('')}
              style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
                background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-3)', fontSize: 18, lineHeight: 1 }}>
              ×
            </button>
          )}
        </div>

        {/* View toggle */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
          {[
            { id: 'list', label: 'List', icon: (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/>
                <circle cx="3" cy="6" r="1.5" fill="currentColor"/><circle cx="3" cy="12" r="1.5" fill="currentColor"/><circle cx="3" cy="18" r="1.5" fill="currentColor"/>
              </svg>
            )},
            { id: 'map', label: 'Map', icon: (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/>
                <line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/>
              </svg>
            )},
            { id: 'split', label: 'Split', icon: (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <rect x="3" y="3" width="7" height="18" rx="1"/><rect x="14" y="3" width="7" height="18" rx="1"/>
              </svg>
            )},
          ].map(v => (
            <button key={v.id} onClick={() => setView(v.id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '7px 14px', borderRadius: 100,
                border: `1.5px solid ${view === v.id ? 'var(--brand)' : 'var(--border)'}`,
                background: view === v.id ? 'var(--brand-glow)' : 'var(--bg-input)',
                color: view === v.id ? 'var(--brand)' : 'var(--text-2)',
                fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12,
                cursor: 'pointer', transition: 'all 0.18s',
                flex: 1, justifyContent: 'center',
              }}>
              {v.icon} {v.label}
            </button>
          ))}
        </div>

        <p style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 10, fontFamily: 'var(--font-display)' }}>
          {loading ? 'Loading...' : `${filtered.length} shop${filtered.length !== 1 ? 's' : ''}${search ? ` for "${search}"` : ''}`}
        </p>
      </div>

      {/* ── Content area ── */}
      {loading ? (
        <div style={{ padding: '20px 16px' }}>
          {[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: 76, borderRadius: 'var(--radius)', marginBottom: 10 }} />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🗺️</div>
          <div className="empty-title">No shops found</div>
          <div className="empty-sub">Try a different search term</div>
        </div>
      ) : (
        <>
          {/* LIST ONLY */}
          {view === 'list' && (
            <div style={{ padding: '12px 16px', paddingBottom: 'calc(var(--bottom-h) + 24px)' }}>
              {filtered.map((s, i) => (
                <ShopRow key={s.id} shop={s} active={activeShop === s.id}
                  onClick={() => navigate(`/shop/${s.id}`)}
                  onMapPin={s.lat && s.lng ? () => focusShop(s) : null}
                  animDelay={i * 0.04} />
              ))}
            </div>
          )}

          {/* MAP ONLY */}
          {view === 'map' && (
            <div style={{ height: 'calc(100dvh - 190px)', position: 'relative' }}>
              <ExploreMap
                shops={mapShops} allShops={filtered}
                center={mapCenter} activeShop={activeShop}
                onSelect={s => { setActive(s.id); navigate(`/shop/${s.id}`); }}
              />
              {mapShops.length < filtered.length && (
                <div style={{
                  position: 'absolute', bottom: 16, left: '50%', transform: 'translateX(-50%)',
                  background: 'rgba(6,14,30,0.78)', backdropFilter: 'blur(8px)',
                  color: '#fff', fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700,
                  padding: '8px 16px', borderRadius: 100,
                  border: '1px solid rgba(255,255,255,0.15)',
                }}>
                  {filtered.length - mapShops.length} shop{filtered.length - mapShops.length !== 1 ? 's' : ''} have no location — switch to List
                </div>
              )}
            </div>
          )}

          {/* SPLIT */}
          {view === 'split' && (
            <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100dvh - 190px)' }}>
              {/* Map top half */}
              <div style={{ flex: '0 0 42%', position: 'relative' }}>
                <ExploreMap
                  shops={mapShops} allShops={filtered}
                  center={mapCenter} activeShop={activeShop}
                  onSelect={s => selectFromMap(s)}
                />
              </div>

              {/* List bottom half */}
              <div ref={listRef} style={{
                flex: 1, overflowY: 'auto', padding: '10px 16px',
                paddingBottom: 'calc(var(--bottom-h) + 16px)',
                borderTop: '1px solid var(--border)',
                background: 'var(--bg)',
              }}>
                {filtered.map((s, i) => (
                  <ShopRow key={s.id} shop={s} active={activeShop === s.id}
                    onClick={() => navigate(`/shop/${s.id}`)}
                    onMapPin={s.lat && s.lng ? () => { setActive(s.id); setCenter([s.lat, s.lng]); } : null}
                    animDelay={i * 0.03}
                    data-shopid={s.id}
                  />
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

const TIER_STYLE = {
  premium: { border: 'rgba(255,184,0,0.50)', dot: '#FFB800', label: 'Premium' },
  pro:     { border: 'rgba(0,128,255,0.28)', dot: '#0080FF', label: 'Pro' },
  basic:   { border: null, dot: null, label: null },
};

// ── Shop row card ──────────────────────────────────────────────────────────────
function ShopRow({ shop: s, active, onClick, onMapPin, animDelay, ...rest }) {
  const tier = TIER_STYLE[s.subscription_tier] || TIER_STYLE.basic;
  return (
    <div
      {...rest}
      data-shopid={s.id}
      className="fade-up"
      style={{
        display: 'flex', gap: 12, alignItems: 'center',
        padding: '12px 14px', marginBottom: 8,
        background: active ? 'var(--brand-glow2)' : 'var(--bg-card)',
        border: `1.5px solid ${active ? 'var(--border-brand)' : (tier.border || 'var(--border)')}`,
        borderRadius: 'var(--radius)',
        cursor: 'pointer', transition: 'all 0.18s',
        boxShadow: active ? 'var(--shadow-brand)' : 'var(--shadow-card)',
        animationDelay: `${animDelay}s`,
      }}
      onClick={onClick}
    >
      {/* Thumbnail */}
      <div style={{
        width: 52, height: 52, borderRadius: 12, flexShrink: 0,
        background: 'var(--bg-input)', overflow: 'hidden',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 22, border: '1px solid var(--border)',
      }}>
        {s.images?.[0]
          ? <img src={s.images[0]} alt={s.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          : '✂️'}
      </div>

      {/* Info */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, marginBottom: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {s.name}
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-2)', display: 'flex', gap: 8, alignItems: 'center' }}>
          <span>📍 {s.city || s.address}</span>
          {s.rating && <span>⭐ {s.rating.toFixed(1)}</span>}
        </div>
      </div>

      {/* Right side */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6, flexShrink: 0 }}>
        {tier.label && (
          <span style={{
            fontSize: 10, fontWeight: 800, fontFamily: 'var(--font-display)',
            padding: '2px 7px', borderRadius: 20,
            background: s.subscription_tier === 'premium' ? 'rgba(255,184,0,0.12)' : 'var(--brand-glow)',
            color: tier.dot,
            border: `1px solid ${s.subscription_tier === 'premium' ? 'rgba(255,184,0,0.35)' : 'var(--border-brand)'}`,
            display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <span style={{ width: 5, height: 5, borderRadius: '50%', background: tier.dot, display: 'inline-block' }} />
            {tier.label}
          </span>
        )}
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {onMapPin && (
            <button
              onClick={e => { e.stopPropagation(); onMapPin(); }}
              style={{
                background: 'var(--brand-glow)', border: '1px solid var(--border-brand)',
                borderRadius: 8, padding: '4px 8px', cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 4,
                fontSize: 11, fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--brand)',
              }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/>
              </svg>
              Map
            </button>
          )}
          <span style={{ color: 'var(--text-3)', fontSize: 16 }}>›</span>
        </div>
      </div>
    </div>
  );
}

// ── Leaflet Map component ──────────────────────────────────────────────────────
function ExploreMap({ shops, center, activeShop, onSelect }) {
  return (
    <MapContainer
      center={center}
      zoom={12}
      style={{ width: '100%', height: '100%' }}
      zoomControl={false}
      attributionControl={false}
    >
      <TileLayer
        url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
        attribution='&copy; <a href="https://carto.com/">CartoDB</a>'
      />
      <MapRecenter center={center} />
      {shops.map(s => (
        <Marker
          key={s.id}
          position={[s.lat, s.lng]}
          icon={makeBrandPin(activeShop === s.id)}
          eventHandlers={{ click: () => onSelect(s) }}
        >
          <Popup>
            <div style={{ fontFamily: 'Sora, sans-serif', minWidth: 140 }}>
              <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 3 }}>{s.name}</div>
              <div style={{ fontSize: 11, color: '#4A5C7A', marginBottom: 6 }}>📍 {s.city || s.address}</div>
              {s.rating && <div style={{ fontSize: 11, color: '#0080FF', fontWeight: 700 }}>⭐ {s.rating.toFixed(1)}</div>}
              <button
                onClick={() => onSelect(s)}
                style={{ marginTop: 8, width: '100%', padding: '6px 12px',
                  background: 'linear-gradient(135deg, #0080FF, #00B4FF)',
                  color: '#fff', border: 'none', borderRadius: 8,
                  fontFamily: 'Sora, sans-serif', fontWeight: 700, fontSize: 12, cursor: 'pointer' }}>
                View Shop
              </button>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
