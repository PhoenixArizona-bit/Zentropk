-- ============================================================
-- ZentroPK — Fresh Database Schema
-- Run this in Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ── Profiles ──────────────────────────────────────────────────────────────────
create table if not exists profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null,
  email       text,
  role        text not null default 'customer' check (role in ('customer', 'barber', 'admin')),
  created_at  timestamptz default now()
);

-- ── Shops ─────────────────────────────────────────────────────────────────────
create table if not exists shops (
  id                  uuid primary key default uuid_generate_v4(),
  owner_id            uuid references profiles(id) on delete cascade,
  name                text not null,
  city                text,
  address             text,
  description         text,
  phone               text,
  images              text[] default '{}',
  lat                 float,
  lng                 float,
  rating              float default 0,
  is_active           boolean default false,
  subscription_tier   text default 'basic' check (subscription_tier in ('basic', 'pro', 'premium')),
  subscription_status text default 'pending' check (subscription_status in ('pending', 'active', 'expired')),
  created_at          timestamptz default now()
);

-- ── Services ──────────────────────────────────────────────────────────────────
create table if not exists services (
  id                uuid primary key default uuid_generate_v4(),
  shop_id           uuid references shops(id) on delete cascade,
  name              text not null,
  price             numeric not null,
  duration_minutes  int default 30,
  is_active         boolean default true,
  created_at        timestamptz default now()
);

-- ── Time Slots ────────────────────────────────────────────────────────────────
create table if not exists time_slots (
  id          uuid primary key default uuid_generate_v4(),
  shop_id     uuid references shops(id) on delete cascade,
  slot_date   date not null,
  start_time  time not null,
  end_time    time not null,
  is_booked   boolean default false,
  created_at  timestamptz default now(),
  unique (shop_id, slot_date, start_time)
);

-- ── Bookings ──────────────────────────────────────────────────────────────────
create table if not exists bookings (
  id            uuid primary key default uuid_generate_v4(),
  shop_id       uuid references shops(id) on delete cascade,
  customer_id   uuid references profiles(id) on delete cascade,
  time_slot_id  uuid references time_slots(id) on delete set null,
  service_id    uuid references services(id) on delete set null,
  status        text default 'pending' check (status in ('pending', 'confirmed', 'completed', 'cancelled')),
  created_at    timestamptz default now()
);

-- ── Reviews ───────────────────────────────────────────────────────────────────
create table if not exists reviews (
  id          uuid primary key default uuid_generate_v4(),
  shop_id     uuid references shops(id) on delete cascade,
  booking_id  uuid references bookings(id) on delete cascade,
  customer_id uuid references profiles(id) on delete cascade,
  rating      int not null check (rating between 1 and 5),
  comment     text,
  created_at  timestamptz default now()
);

-- ── Payment Submissions ───────────────────────────────────────────────────────
create table if not exists payment_submissions (
  id              uuid primary key default uuid_generate_v4(),
  shop_id         uuid references shops(id) on delete cascade,
  owner_id        uuid references profiles(id) on delete cascade,
  amount          numeric not null,
  txn_id          text not null,
  screenshot_url  text,
  payment_method  text default 'jazzcash' check (payment_method in ('jazzcash', 'easypaisa')),
  status          text default 'pending' check (status in ('pending', 'approved', 'rejected')),
  submitted_at    timestamptz default now(),
  reviewed_at     timestamptz
);

-- ── App Settings ──────────────────────────────────────────────────────────────
create table if not exists app_settings (
  key    text primary key,
  value  text
);

-- Insert default settings (edit these in admin portal later)
insert into app_settings (key, value) values
  ('jazzcash_number',     '03001234567'),
  ('jazzcash_name',       'Zentro PK'),
  ('easypaisa_number',    '03001234567'),
  ('easypaisa_name',      'Zentro PK'),
  ('admin_search_keyword','zentro@admin'),
  ('admin_password_hash', ''),
  ('admin_pattern_hash',  '')
on conflict (key) do nothing;

-- ── Disable RLS on all tables (admin portal is password-protected) ─────────────
alter table profiles           disable row level security;
alter table shops              disable row level security;
alter table services           disable row level security;
alter table time_slots         disable row level security;
alter table bookings           disable row level security;
alter table reviews            disable row level security;
alter table payment_submissions disable row level security;
alter table app_settings       disable row level security;

-- ── Indexes for performance ────────────────────────────────────────────────────
create index if not exists idx_shops_owner      on shops(owner_id);
create index if not exists idx_shops_active     on shops(is_active);
create index if not exists idx_slots_shop_date  on time_slots(shop_id, slot_date);
create index if not exists idx_bookings_shop    on bookings(shop_id);
create index if not exists idx_bookings_customer on bookings(customer_id);
create index if not exists idx_services_shop    on services(shop_id);
create index if not exists idx_payments_owner   on payment_submissions(owner_id);

-- ── Subscription expiry ────────────────────────────────────────────────────────
-- Add expires_at column to shops
alter table shops add column if not exists subscription_expires_at timestamptz;

-- Function: auto-expire shops where subscription_expires_at has passed
create or replace function expire_subscriptions()
returns void language plpgsql as $$
begin
  update shops
  set subscription_status = 'expired', is_active = false
  where subscription_status = 'active'
    and subscription_expires_at is not null
    and subscription_expires_at < now();
end;
$$;

-- Run expiry check every hour via pg_cron (enable pg_cron extension in Supabase dashboard first)
-- select cron.schedule('expire-subscriptions', '0 * * * *', 'select expire_subscriptions()');

-- ── Subscription approved_at (run this if upgrading from v6) ──────────────────
alter table shops add column if not exists subscription_approved_at timestamptz;
